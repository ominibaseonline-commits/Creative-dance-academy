# Server (Cloud Sync) — Setup Guide

Is project me ab "dist-server-version" wala Server feature built-in hai.
Jab tak server config nahi milta, app bilkul pehle jaisa offline (IndexedDB) chalta hai.

## Naye files / changes
| File | Kaam |
|---|---|
| `src/app/lib/serverSync.ts` | Poora sync engine (queue, push, pull, connect) |
| `src/app/lib/serverSchema.ts` + `supabase/schema.sql` | Supabase ka SQL (ek baar run karna hai) |
| `src/app/components/ServerSettings.tsx` | Settings > **Server** tab |
| `src/app/App.tsx` | Startup par `initServerSync()` (purana Supabase sync hata diya) |
| `src/app/components/Settings.tsx` | Server tab (sirf tab dikhta hai jab config mila ho) |
| `public/config.json` | Web build ke liye server URL + anon key |
| `scripts/postbuild.cjs` | Build ke baad `dist/404.html` + `dist/.nojekyll` banata hai |

## Client ke liye dist banana (web / GitHub Pages / Netlify)
1. `npm install`
2. `npm run build`  → `dist/` ban jata hai
3. `dist/config.json` kholkar us client ke Supabase project ki values bharein
   (rebuild ki zaroorat nahi, sirf is file ko edit karke upload karna hai):
   ```json
   { "supabaseUrl": "https://xxxx.supabase.co", "supabaseAnonKey": "eyJ..." }
   ```
4. `dist/` ko host karein.

## Supabase side (har client ke liye ek baar)
1. Naya Supabase project banayein.
2. SQL Editor -> New query -> `supabase/schema.sql` paste -> Run.
3. App kholein, license key daalein -> Settings > Server > **Connect Server**.
   Us device ka data server par chala jata hai aur server us license key se lock ho jata hai.
4. Kisi bhi naye device par wahi link + wahi license key = data apne aap aa jata hai.

## Server config kahan se uthta hai (is order me)
1. `config.json` (web build)
2. localStorage (pichli baar ka save kiya hua)
3. License data (Google Sheet / Apps Script response me `supabase_url` aur `supabase_anon_key`)
4. Build-time env: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`

**Windows .exe (Electron)** `file://` se chalta hai, wahan `config.json` fetch normally nahi hota.
Isliye exe ke liye option 3 (license response) ya option 4 (build env) use karein.

## Dhyan rakhne wali baatein
- License key hi us server ka password hai. Ye key kisi ko na dein.
- Naye device par jo data pehle se local hai, agar wahi keys server par bhi hain
  to **server ka data jeet jata hai** (pehli baar link karte waqt).
- `licenseKey` wali setting kabhi sync nahi hoti (har device ki apni rehti hai).
