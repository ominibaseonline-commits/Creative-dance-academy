# 🔐 License Key System - Setup Guide

## Overview
Yeh system aapke application ko protect karta hai unique license keys se. Har user ko ek unique license key milega jo expire hone par system lock ho jayega.

---

## 📋 Complete Setup Process

### **Step 1: Pehli Baar Setup (First Time Setup)**

Jab aap application pehli baar kholeinge:

1. **License Activation Screen** dikhega
2. Yahan do options hain:
   - **Option A**: License Key INPUT karna (recommended for users)
   - **Option B**: Admin Settings se generate karna

---

### **Option A: License Key Input Karna (For Users)**

#### 1️⃣ License Activation Page
- Application open karne par **"License Activation"** page dikhega
- Yahaan 2 fields honge:
  - **License Key** (Format: `MDA-XXXXXXXX-XXXXXXXX`)
  - **Expiry Date** (jab tak valid rahega)

#### 2️⃣ License Key Daalna
```
License Key: MDA-ABC12345-XYZ67890
Expiry Date: 2025-12-31
```

#### 3️⃣ Activate Button Click Karo
- "Activate License" button click karein
- System automatically reload hoga
- Login page khul jayega

✅ **Done!** Ab aap login kar sakte ho!

---

### **Option B: Admin Se Generate Karna (For Admins)**

Agar aap admin ho aur license key khud generate karna chahte ho:

#### 1️⃣ Temporarily Skip Activation
Pehle baar ke liye koi dummy license daal do:
```
License Key: MDA-TEMP1234-TEMP5678
Expiry Date: [3 months future date]
```

#### 2️⃣ Admin Login Karo
```
Email: mayuridancea@gmail.com
Password: kumarniteesh702
```

#### 3️⃣ Settings Mein Jao
- Dashboard khulne ke baad **"Settings & Management"** tab par jao
- **"Business Settings"** tab select karo

#### 4️⃣ License Key Generate Karo
- Scroll down karke **"License Key Management"** section dekho
- **"Generate New License Key"** section mein:
  - Expiry date select karo (jaise: 31-12-2025)
  - "Generate License Key" button click karo
- Ek unique key generate hogi: `MDA-XXXXXXXX-XXXXXXXX`

#### 5️⃣ License Key Copy Karo
- Generated license key copy kar lo
- Yeh key aap users ko doge

---

## 🔒 License Protection System

### User Protection (Normal Users)
Ek baar license activate hone ke baad:
- ❌ Users **license key change nahi kar sakte**
- ❌ Users **deactivate nahi kar sakte**
- ✅ Users sirf **license status dekh sakte hain**

### Admin Protection (Super Admin Only)
License modify karne ke liye:

1. **Settings → Business Settings** mein jao
2. License section mein **"Protected Actions"** dikhega
3. **Admin Secret Code** daaliye: `ADMIN2024`
4. "Unlock" button click karo
5. Ab aap:
   - License deactivate kar sakte ho
   - Naya license generate kar sakte ho

---

## 📱 How System Works

### ✅ Valid License (Active)
```
Login Page:
┌─────────────────────────┐
│ License Status          │
│ Expires: 31-Dec-2025    │
│ Days Remaining: 120 days│
└─────────────────────────┘
[Admin Login] [Student Login]
```
- System normally work karega
- Users login kar sakte hain
- Green color badge dikhega

### ⚠️ License Expiring Soon (7 days left)
```
Warning:
"License expiring soon! 5 days remaining."
```
- Orange color warning dikhega
- System abhi bhi work karega
- Admin ko renew karna hoga

### ❌ License Expired/Deactivated
```
🔒 System Locked
Access Denied
Your license key has expired

Contact administrator to renew
```
- **Login page lock ho jayega**
- Koi bhi login nahi kar sakta
- Sirf admin hi naya license activate kar sakta hai

---

## 🔑 Admin Secret Code

**Current Admin Code:** `ADMIN2024`

### Change Admin Code (Optional)
Agar aap code change karna chahte ho:

1. Open file: `src/app/components/Settings.tsx`
2. Line search karo: `const SECRET_CODE = 'ADMIN2024';`
3. Code change karo: `const SECRET_CODE = 'YOUR_NEW_CODE';`
4. Save karo

Example:
```typescript
// Old
const SECRET_CODE = 'ADMIN2024';

// New  
const SECRET_CODE = 'MYCOMPANY123';
```

---

## 📊 License Key Format

### Structure
```
MDA-[RANDOM8]-[TIMESTAMP]

Example: MDA-K7X2P9Q4-1ABCD2EF
         ^^^-^^^^^^^^-^^^^^^^^
         |   |        |
         |   |        +-- Timestamp-based unique ID
         |   +----------- 8-character random string
         +--------------- Prefix (Mayuri Dance Academy)
```

### Validation
- ✅ Format: `MDA-XXXXXXXX-XXXXXXXX`
- ✅ Case-insensitive (automatically uppercase)
- ✅ Hyphen (-) mandatory
- ❌ Spaces not allowed

---

## 🎯 Common Scenarios

### Scenario 1: New User Installation
```
1. Open app → License Activation page
2. Enter license key (provided by admin)
3. Set expiry date
4. Click "Activate License"
5. Login page opens
6. Login with credentials
```

### Scenario 2: License Renewal Before Expiry
```
1. Admin logs in
2. Goes to Settings → Business Settings
3. Sees: "Days Remaining: 5 days" (warning)
4. Enters admin code: ADMIN2024
5. Unlocks license management
6. Generates new license with future date
7. Old license replaced automatically
```

### Scenario 3: License Already Expired
```
1. User opens app → 🔒 System Locked screen
2. Contact admin for new license
3. Admin enters admin code in Settings
4. Generates new license key
5. Admin shares key with user
6. User must clear browser data and re-activate
   OR admin can update directly in Settings
```

### Scenario 4: Multiple Users / Locations
```
Each installation needs unique license:

Location 1: MDA-ABC12345-XYZ67890
Location 2: MDA-DEF12345-UVW67890  
Location 3: MDA-GHI12345-RST67890

Each license can have different expiry dates
```

---

## 🛠️ Troubleshooting

### Problem: License Activation Not Working
**Solution:**
- Check license key format: `MDA-XXXXXXXX-XXXXXXXX`
- Verify expiry date is in future
- Clear browser cache and retry

### Problem: "Invalid Admin Code" Error
**Solution:**
- Default code is: `ADMIN2024`
- Check if you changed it in code
- Case-sensitive (use UPPERCASE)

### Problem: System Locked But License Valid
**Solution:**
- Clear browser cache/IndexedDB
- Re-enter license activation page
- Activate license again

### Problem: Want to Remove License System
**Solution:**
Contact developer to remove license validation from code

---

## 📞 Support

**For Users:**
- Contact your system administrator for license key
- Share business name and installation details

**For Admins:**
- Use admin code: `ADMIN2024` to manage licenses
- Generate unique keys for each installation
- Keep track of expiry dates

---

## 🔐 Security Features

1. ✅ **Unique Keys**: Each license is unique
2. ✅ **Expiry Control**: Set custom expiry dates
3. ✅ **User Lock**: Users cannot modify license
4. ✅ **Admin Protection**: Secret code required for changes
5. ✅ **Automatic Lock**: System locks on expiry
6. ✅ **Visual Warnings**: 7-day expiry warnings

---

## 📝 Quick Reference Card

```
┌─────────────────────────────────────────┐
│  LICENSE SYSTEM - QUICK REFERENCE       │
├─────────────────────────────────────────┤
│ License Format:                         │
│   MDA-XXXXXXXX-XXXXXXXX                 │
│                                         │
│ Admin Login:                            │
│   Email: mayuridancea@gmail.com        │
│   Pass: kumarniteesh702                │
│                                         │
│ Admin Secret Code:                      │
│   ADMIN2024                             │
│                                         │
│ Activate License:                       │
│   1. Enter license key                  │
│   2. Set expiry date                    │
│   3. Click "Activate License"           │
│                                         │
│ Manage License (Admin):                 │
│   Settings → Business Settings →        │
│   License Management → Enter Code       │
└─────────────────────────────────────────┘
```

---

**Version:** 1.0  
**Last Updated:** June 2026  
**System:** Mayuri Dance & Fitness Academy POS
