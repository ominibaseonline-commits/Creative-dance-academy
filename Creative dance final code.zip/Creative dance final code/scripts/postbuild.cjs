// Runs automatically after `npm run build`.
// Static hosting (GitHub Pages etc.) ke liye: 404.html = index.html (SPA fallback) + .nojekyll
const fs = require('fs');
const path = require('path');
const dist = path.join(__dirname, '..', 'dist');
fs.copyFileSync(path.join(dist, 'index.html'), path.join(dist, '404.html'));
fs.writeFileSync(path.join(dist, '.nojekyll'), '');
console.log('postbuild: dist/404.html and dist/.nojekyll created');
