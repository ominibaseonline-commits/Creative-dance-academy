# Naya client add karne ka checklist (ek hi dist / ek hi link)

## 1) Client ka Supabase banayein (har client ka alag project)
1. supabase.com par naya project banayein.
2. SQL Editor -> New query -> `supabase/schema.sql` ka poora SQL paste karke Run.
3. Project Settings -> API se do cheezein copy karein:
   - **Project URL**  (https://xxxx.supabase.co)
   - **anon public key**  (eyJ...)  ->  `service_role` key kabhi mat copy karein / mat daalein.

## 2) Google Sheet mein client ki row (yahi sabse zaroori jagah hai)
Sheet mein ye columns hon (last ke 2 naye add karein):

| License Key | User Name | Business | Domain | Created At | Expiry Date | Status | Plan | Phone | Email | Supabase URL | Supabase Anon Key |

- **License Key** -> client ki nayi key (CMS-XXXX-XXXX)
- **Supabase URL** -> step 1 wala Project URL
- **Supabase Anon Key** -> step 1 wali anon public key

Apps Script (verify_license) ko in dono columns ko response mein bhejna hoga, in naamon se:
`supabase_url` aur `supabase_anon_key`
(app inhi naamon se padhta hai - `src/app/lib/googleSheetLicense.ts`).

## 3) dist mein config.json KHAALI rakhein
Ek hi link sab clients ke liye hai, isliye `dist/config.json` mein koi Supabase value mat daalein:
{ "supabaseUrl": "", "supabaseAnonKey": "" }
(config.json ko sabse pehle padha jata hai - agar usme value ho to sab clients usi Supabase par chale jayenge.)

## 4) Client ke device par
1. App kholo -> License key daalo -> Activate.
2. Settings -> Server (Cloud Sync) -> **Connect Server** (sirf pehli baar). Server us license key se lock ho jata hai.
3. Doosre devices par wahi link + wahi license key = data apne aap aa jata hai.

## Emergency: client ki license key badalni ho
1. Sabhi devices par sync poora ho jaye (pending 0).
2. Client ke Supabase SQL Editor mein:
   update public.app_meta set license_key = upper('NAYI-KEY') where id = 1;
3. Sheet mein naya key ki row banayein (wahi Supabase URL + anon key).
4. Client ke login page par "Emergency: License match nahi hua" box aayega ->
   "Naya License Key Add Karo (Admin Only)" -> admin unlock password -> naya key daalein.
   (Ye option normal din mein nahi dikhta - sirf jab server kisi dusri key ka ho,
   ya license expired / revoked / invalid ho.)
5. Sab devices badal jayein tab purani key ki row sheet se hata dein.
Emergency ke dauran naya data enter na karein, pehle key theek karein.
