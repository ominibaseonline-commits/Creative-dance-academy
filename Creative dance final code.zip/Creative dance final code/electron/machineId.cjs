// Generates a stable, unique ID for this Windows machine.
// Combines hardware-level identifiers so the ID stays the same across
// app reinstalls, but changes if the app is moved to a different PC.

const crypto = require('crypto');
const os = require('os');
const { machineIdSync } = require('node-machine-id');

let cachedId = null;

function getMachineId() {
  if (cachedId) return cachedId;

  try {
    // node-machine-id reads a stable OS-level GUID
    // (Windows: registry MachineGuid; macOS: IOPlatformUUID; Linux: /etc/machine-id)
    const rawId = machineIdSync(true); // true = already hashed by the library

    // Extra hash pass mixing in hostname, so two VMs cloned from the
    // same image (rare, but possible) are still less likely to collide.
    const combined = `${rawId}-${os.hostname()}`;
    cachedId = crypto.createHash('sha256').update(combined).digest('hex').substring(0, 32).toUpperCase();
  } catch (err) {
    // Fallback (should rarely trigger): hash whatever OS info we can get
    const fallbackSource = `${os.hostname()}-${os.platform()}-${os.arch()}-${os.cpus()?.[0]?.model || ''}`;
    cachedId = crypto.createHash('sha256').update(fallbackSource).digest('hex').substring(0, 32).toUpperCase();
  }

  return cachedId;
}

module.exports = { getMachineId };
