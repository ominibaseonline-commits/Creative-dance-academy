const { app, BrowserWindow, ipcMain, Menu, dialog, shell, screen, systemPreferences } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { autoUpdater } = require('electron-updater');
const log = require('electron-log');
const { getMachineId } = require('./machineId.cjs');
const googleDrive = require('./googleDrive.cjs');

// Windows/Linux: remove the default File/Edit/View/Window/Help menu bar so the
// app looks like a real standalone software instead of a browser window.
//
// macOS: Cmd+C / Cmd+V / Cmd+X / Cmd+A / Cmd+Z only work through the Edit menu,
// so removing the menu completely breaks copy/paste there. We keep a minimal
// menu (App + Edit + Window) on Mac so paste works in every input box.
if (process.platform === 'darwin') {
  Menu.setApplicationMenu(
    Menu.buildFromTemplate([
      {
        label: 'Ominibase CMS',
        submenu: [
          { role: 'about' },
          { type: 'separator' },
          { role: 'hide' },
          { role: 'hideOthers' },
          { role: 'unhide' },
          { type: 'separator' },
          { role: 'quit' },
        ],
      },
      {
        label: 'Edit',
        submenu: [
          { role: 'undo' },
          { role: 'redo' },
          { type: 'separator' },
          { role: 'cut' },
          { role: 'copy' },
          { role: 'paste' },
          { role: 'selectAll' },
        ],
      },
      {
        label: 'Window',
        submenu: [{ role: 'minimize' }, { role: 'close' }],
      },
    ])
  );
} else {
  Menu.setApplicationMenu(null);
}

// Auto-updater ki har activity (check/download/error) is log file mein likhi jayegi:
// Windows: C:\Users\<UserName>\AppData\Roaming\Ominibase CMS\logs\main.log
log.transports.file.level = 'info';
autoUpdater.logger = log;

// Update sirf tab download hoga jab user "Update" button dabayega (renderer se
// IPC 'update:download' aayega) — silent background download nahi karna.
autoUpdater.autoDownload = false;
autoUpdater.autoInstallOnAppQuit = false;

let mainWindow;

function createWindow() {
  // Fit the window to whatever screen this laptop actually has, instead of
  // a hardcoded 1280x800 that overflows small/low-res screens.
  const { width: screenWidth, height: screenHeight } = screen.getPrimaryDisplay().workAreaSize;

  mainWindow = new BrowserWindow({
    width: Math.min(1280, screenWidth),
    height: Math.min(800, screenHeight),
    minWidth: 1000,
    minHeight: 700,
    icon: path.join(__dirname, 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    show: false,
  });

  // Loads the built Vite/React app (dist/index.html)
  mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));

  mainWindow.once('ready-to-show', () => {
    // Always open maximized — fills the actual visible screen area on any
    // laptop size, so every dashboard section is visible without scrolling
    // the whole window. Individual tall forms (e.g. Admission Form) can
    // still scroll internally, which is expected.
    mainWindow.maximize();
    mainWindow.show();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(async () => {
  // macOS: camera ke liye system permission pehle se maangni padti hai (admission form ka Live Camera).
  // Ye call macOS ka "Allow camera" popup dikhata hai aur app ko System Settings > Privacy > Camera
  // list mein register karta hai. Bina iske "No camera found" aa sakta hai.
  if (process.platform === 'darwin') {
    try {
      const camStatus = systemPreferences.getMediaAccessStatus('camera');
      log.info('macOS camera access status:', camStatus);
      if (camStatus === 'not-determined') {
        const granted = await systemPreferences.askForMediaAccess('camera');
        log.info('macOS camera access granted:', granted);
      }
    } catch (err) {
      log.error('Camera permission request failed:', err);
    }
  }

  createWindow();
  log.info('App started, version:', app.getVersion());

  // Check for updates ~5 seconds after launch (gives the window time to render)
  setTimeout(() => {
    log.info('Checking for updates...');
    autoUpdater.checkForUpdates();
  }, 5000);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// Renderer (React app) asks for the machine ID through this IPC channel
ipcMain.handle('get-machine-id', async () => {
  return getMachineId();
});

// Renderer asks for the current app version (used for the "What's new" popup after restart)
// window.confirm / window.alert ka popup: title "mdfa-desktop-app" ki jagah "Ominibase CMS" dikhta hai.
// Synchronous hi rakha hai, taaki purana code (if (!confirm(...)) return;) bina badle chalta rahe.
const POPUP_TITLE = 'Ominibase CMS';
ipcMain.on('app-confirm', (event, message) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  const r = dialog.showMessageBoxSync(win || undefined, {
    type: 'question', title: POPUP_TITLE, message: String(message || ''),
    buttons: ['OK', 'Cancel'], defaultId: 0, cancelId: 1, noLink: true,
  });
  event.returnValue = r === 0;
});
ipcMain.on('app-alert', (event, message) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  dialog.showMessageBoxSync(win || undefined, { type: 'info', title: POPUP_TITLE, message: String(message || ''), buttons: ['OK'], noLink: true });
  event.returnValue = true;
});

ipcMain.handle('get-app-version', () => {
  return app.getVersion();
});

// Renderer sends receipt/report HTML + a suggested file name (e.g. student ka naam).
// Ye HTML ko ek hidden window mein render karke asli PDF banata hai, phir native
// "Save As" dialog kholta hai jisme file name pehle se bhara hua (pre-filled) hota hai —
// isliye user ko khud type nahi karna padta.
ipcMain.handle('print-pdf', async (event, { html, fileName, options }) => {
  const safeName = (fileName || 'Document').replace(/[\\/:*?"<>|]/g, '_');
  const fitOnePage = !!(options && options.fitOnePage);

  // A4 with 0.4in margins. Content area in CSS px (96 per inch):
  //   width  = (8.27 - 0.8)  * 96 ≈ 717px
  //   height = (11.69 - 0.8) * 96 ≈ 1045px
  const MARGIN_IN = 0.4;
  const PAGE_W_PX = Math.floor((8.27 - MARGIN_IN * 2) * 96);
  const PAGE_H_PX = Math.floor((11.69 - MARGIN_IN * 2) * 96);

  const pdfWindow = new BrowserWindow({
    show: false,
    // Window width = printable width, so the height we measure matches the real PDF layout
    width: fitOnePage ? PAGE_W_PX : 800,
    height: 1000,
    useContentSize: true,
    webPreferences: { offscreen: true },
  });

  // Photo wale receipts ka HTML bahut bada hota hai (base64 image), isliye data: URL
  // limit cross ho jati thi. Ab HTML ko temp file mein likh kar load karte hain.
  // IMPORTANT: file ke andar charset batana zaroori hai, warna ₹ jaisa symbol "â,¹" ban jata hai.
  let fullHtml = html;
  if (!/charset\s*=/i.test(fullHtml)) {
    fullHtml = /<head[^>]*>/i.test(fullHtml)
      ? fullHtml.replace(/<head[^>]*>/i, (m) => `${m}<meta charset="UTF-8">`)
      : `<meta charset="UTF-8">${fullHtml}`;
  }
  const tmpHtmlPath = path.join(os.tmpdir(), `print-${Date.now()}-${Math.random().toString(36).slice(2)}.html`);

  try {
    fs.writeFileSync(tmpHtmlPath, fullHtml, 'utf-8');
    await pdfWindow.loadFile(tmpHtmlPath);
    // Images ko decode hone ka time do
    await pdfWindow.webContents.executeJavaScript(
      `Promise.all(Array.from(document.images).map(i => i.complete ? Promise.resolve() : new Promise(r => { i.onload = i.onerror = r; })))`
    ).catch(() => {});

    const pdfOptions = { printBackground: true, pageSize: 'A4' };
    if (options && options.landscape) pdfOptions.landscape = true; // Events Record PDF

    if (fitOnePage) {
      // Content ki asli height naapo; agar ek A4 page se badi hai to scale kam karo
      // taaki poora receipt sirf 1 page me aaye. (Chhota content ko bada nahi karte.)
      const contentHeight = await pdfWindow.webContents.executeJavaScript(
        `Math.ceil(Math.max(document.documentElement.scrollHeight, document.body.scrollHeight))`
      );
      let scale = 1;
      if (contentHeight > PAGE_H_PX) {
        scale = Math.max(0.4, (PAGE_H_PX / contentHeight) * 0.96); // 4% safety margin
      }
      pdfOptions.scale = scale;
      pdfOptions.margins = { top: MARGIN_IN, bottom: MARGIN_IN, left: MARGIN_IN, right: MARGIN_IN };
      log.info(`print-pdf fit-one-page: contentHeight=${contentHeight}px, scale=${scale.toFixed(3)}`);
    } else {
      pdfOptions.margins = { marginType: 'default' };
    }

    const pdfBuffer = await pdfWindow.webContents.printToPDF(pdfOptions);

    const { canceled, filePath } = await dialog.showSaveDialog(mainWindow, {
      title: 'Save Print Output As',
      defaultPath: `${safeName}.pdf`,
      filters: [{ name: 'PDF Document', extensions: ['pdf'] }],
    });

    if (canceled || !filePath) {
      return { success: false, canceled: true };
    }

    fs.writeFileSync(filePath, pdfBuffer);
    shell.showItemInFolder(filePath);
    return { success: true, filePath };
  } catch (error) {
    log.error('print-pdf failed:', error);
    return { success: false, error: String(error) };
  } finally {
    pdfWindow.destroy();
    try { fs.unlinkSync(tmpHtmlPath); } catch (e) { /* ignore */ }
  }
});

// Renderer tells us the user clicked "Update" — start the actual download now
ipcMain.on('update:download', () => {
  log.info('User clicked Update — starting download...');
  autoUpdater.downloadUpdate();
});

// Renderer tells us the user clicked "Restart & Install"
ipcMain.on('update:install', () => {
  log.info('User clicked Restart — installing update...');
  autoUpdater.quitAndInstall();
});

// Auto-update event logging — writes to the log file set up above,
// and forwards each event to the renderer so the UI can show a banner.
autoUpdater.on('checking-for-update', () => {
  log.info('Checking for update...');
});
autoUpdater.on('update-available', (info) => {
  log.info('Update available:', info.version);
  if (mainWindow) {
    mainWindow.webContents.send('update:available', {
      version: info.version,
      releaseNotes: typeof info.releaseNotes === 'string' ? info.releaseNotes : '',
    });
  }
});
autoUpdater.on('update-not-available', (info) => {
  log.info('No update available. Current version is latest:', info.version);
});
autoUpdater.on('download-progress', (progress) => {
  log.info(`Download progress: ${Math.round(progress.percent)}%`);
  if (mainWindow) mainWindow.webContents.send('update:progress', progress.percent);
});
autoUpdater.on('update-downloaded', () => {
  log.info('Update downloaded — will install on restart.');
  if (mainWindow) mainWindow.webContents.send('update:downloaded');
});
autoUpdater.on('error', (err) => {
  log.error('Auto-updater error:', err);
});

// ---------------------------------------------------------------------------
// Google Drive Auto Backup
// ---------------------------------------------------------------------------

// Renderer clicks "Connect" on the Google Drive card — opens the system
// browser for Google login and waits for the redirect to come back.
ipcMain.handle('drive:connect', async () => {
  try {
    const result = await googleDrive.startOAuthLogin();
    // The user just finished signing in inside the system browser — bring
    // the app window back to the front automatically instead of leaving
    // them to alt-tab back to it themselves.
    if (result.success && mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
      // Windows sometimes needs a nudge to actually raise the window above
      // the browser it's returning from — a quick always-on-top toggle does it.
      mainWindow.setAlwaysOnTop(true);
      mainWindow.setAlwaysOnTop(false);
    }
    return result;
  } catch (error) {
    log.error('Drive connect failed:', error);
    return { success: false, error: error.message || String(error) };
  }
});

ipcMain.handle('drive:disconnect', async () => {
  try {
    return await googleDrive.disconnect();
  } catch (error) {
    log.error('Drive disconnect failed:', error);
    return { success: false, error: error.message || String(error) };
  }
});

ipcMain.handle('drive:get-status', async () => {
  try {
    return await googleDrive.getStatus();
  } catch (error) {
    log.error('Drive get-status failed:', error);
    return { connected: false, email: null, lastBackupTime: null };
  }
});

// "Refresh" button — re-checks Drive itself instead of just the local cache,
// so it actually reflects reality (e.g. a backup from another device).
ipcMain.handle('drive:refresh-status', async () => {
  try {
    return await googleDrive.refreshStatusFromDrive();
  } catch (error) {
    log.error('Drive refresh-status failed:', error);
    return await googleDrive.getStatus();
  }
});

// payload = { jsonString, hashPayload, fileName } — jsonString is the full
// exported dashboard data (renderer builds this via exportAllData(), same
// data used for the manual "Export JSON File" button), sent over IPC so the
// main process never needs renderer-only APIs like IndexedDB. hashPayload is
// the data-only string (no timestamp) used to detect "nothing changed".
ipcMain.handle('drive:backup-now', async (event, payload) => {
  try {
    return await googleDrive.backupNow(payload);
  } catch (error) {
    log.error('Drive backup failed:', error);
    const code = error.code === 'not_connected' ? 'not_connected' : undefined;
    return { success: false, error: error.message || String(error), code };
  }
});

ipcMain.handle('drive:list-backups', async () => {
  try {
    const files = await googleDrive.listBackupFiles();
    return { success: true, files };
  } catch (error) {
    log.error('Drive list-backups failed:', error);
    const code = error.code === 'not_connected' ? 'not_connected' : undefined;
    return { success: false, error: error.message || String(error), code };
  }
});

// "Restore" button — pulls the newest backup file from the "Ominibase CMS"
// Drive folder and hands its content back to the renderer to import.
ipcMain.handle('drive:restore-latest', async () => {
  try {
    const result = await googleDrive.restoreLatestBackup();
    return { success: true, ...result };
  } catch (error) {
    log.error('Drive restore failed:', error);
    const code = error.code === 'not_connected' || error.code === 'no_backups' ? error.code : undefined;
    return { success: false, error: error.message || String(error), code };
  }
});

// Daily 9 PM auto-backup check.
//
// Two situations this needs to handle:
//  1. Normal day — app is open at/after 9 PM → backs up right at that time.
//  2. PC/app was OFF through yesterday's 9 PM (missed entirely) → the very
//     next time the app is opened, it checks "was even yesterday backed up?"
//     and if not, runs the backup IMMEDIATELY (does not wait for 9 PM again).
//
// Runs once shortly after launch (to catch case 2 right away) and then every
// minute after that (to catch case 1 precisely at 9 PM).
function checkAndTriggerAutoBackup() {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const isNineOrLater = now.getHours() >= 21;
  const lastBackupDate = googleDrive.getLastAutoBackupDate(); // string 'YYYY-MM-DD' or null

  if (lastBackupDate === todayStr) return; // already backed up today — nothing to do

  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  // True when a whole earlier day's 9 PM window was missed completely
  // (never backed up before, or the last backup is from before yesterday) —
  // this is the "system was off" catch-up case, and it should run right
  // away regardless of what time it is right now.
  const missedAnEarlierDay = lastBackupDate === null || lastBackupDate < yesterdayStr;

  if (!isNineOrLater && !missedAnEarlierDay) return; // today's not due yet — wait for 9 PM tonight

  // Mark it now (before we even know the result) so a slow/failed backup
  // doesn't cause repeated retries every minute for the rest of the day.
  googleDrive.setLastAutoBackupDate(todayStr);
  log.info(
    isNineOrLater
      ? 'Triggering scheduled 9 PM Drive auto-backup...'
      : 'Catching up on a missed Drive auto-backup (PC/app was off at 9 PM)...'
  );
  if (mainWindow) {
    mainWindow.webContents.send('drive:auto-backup-requested');
  }
}

// A short delay on the first check gives the renderer time to finish
// mounting and register its 'drive:auto-backup-requested' listener (see
// App.tsx) before we might send the catch-up event.
setTimeout(checkAndTriggerAutoBackup, 15 * 1000);
setInterval(checkAndTriggerAutoBackup, 60 * 1000);
