const { contextBridge, ipcRenderer } = require('electron');

// Exposes a safe, minimal API to the React app (renderer process).
// The React code will call window.desktopApp.getMachineId() instead
// of trying to access Node/OS APIs directly (which browsers can't do).
contextBridge.exposeInMainWorld('desktopApp', {
  isElectron: true,
  getMachineId: () => ipcRenderer.invoke('get-machine-id'),
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),
  // confirm() / alert() ke native popup (title me app ka naam "Ominibase CMS" aata hai)
  confirmSync: (message) => ipcRenderer.sendSync('app-confirm', String(message)),
  alertSync: (message) => ipcRenderer.sendSync('app-alert', String(message)),
  // html = poora receipt/report ka HTML, fileName = suggested file name (bina .pdf ke)
  // e.g. student/teacher ka naam — Save dialog mein ye pehle se bhara hua aayega.
  // options.fitOnePage = true -> content ek A4 page me fit kar do
  printToPDF: (html, fileName, options) => ipcRenderer.invoke('print-pdf', { html, fileName, options }),
});

// Update-related events/actions, used to show the in-app update banner
// and "what's new" popup instead of relying on native OS notifications.
// Google Drive Auto Backup — renderer never touches OAuth tokens or the
// client secret directly; it only calls these methods and gets plain
// success/error results back.
contextBridge.exposeInMainWorld('driveBackup', {
  connect: () => ipcRenderer.invoke('drive:connect'),
  disconnect: () => ipcRenderer.invoke('drive:disconnect'),
  getStatus: () => ipcRenderer.invoke('drive:get-status'),
  // Re-checks Drive itself (not just the local cache) — used by "Refresh".
  refreshStatus: () => ipcRenderer.invoke('drive:refresh-status'),
  // payload = { jsonString, hashPayload, fileName }
  backupNow: (payload) => ipcRenderer.invoke('drive:backup-now', payload),
  listBackups: () => ipcRenderer.invoke('drive:list-backups'),
  restoreLatest: () => ipcRenderer.invoke('drive:restore-latest'),
  // Main process fires this at 9 PM daily; renderer should export fresh data
  // and call backupNow() with it.
  onAutoBackupRequested: (callback) => ipcRenderer.on('drive:auto-backup-requested', () => callback()),
});

contextBridge.exposeInMainWorld('updater', {
  onUpdateAvailable: (callback) => ipcRenderer.on('update:available', (_event, info) => callback(info)),
  onDownloadProgress: (callback) => ipcRenderer.on('update:progress', (_event, percent) => callback(percent)),
  onUpdateDownloaded: (callback) => ipcRenderer.on('update:downloaded', () => callback()),
  downloadUpdate: () => ipcRenderer.send('update:download'),
  installUpdate: () => ipcRenderer.send('update:install'),
});
