// Copy this file to "drive-config.cjs" (same folder) and fill in your real
// values from Google Cloud Console → APIs & Services → Credentials →
// your "Desktop app" OAuth client.
//
// drive-config.cjs is git-ignored on purpose — never commit real secrets.
// (The GitHub Actions build gets these instead from repo secrets
// GOOGLE_DRIVE_CLIENT_ID / GOOGLE_DRIVE_CLIENT_SECRET — see
// .github/workflows/build.yml)

module.exports = {
  CLIENT_ID: 'YOUR_CLIENT_ID.apps.googleusercontent.com',
  CLIENT_SECRET: 'YOUR_CLIENT_SECRET',
};
