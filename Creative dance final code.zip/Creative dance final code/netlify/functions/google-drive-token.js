// Netlify serverless function — the ONLY place the Web OAuth client secret
// is used for the web (Netlify) build. The browser never sees it.
//
// Why this exists: Google requires the client secret to exchange an
// authorization code (or a refresh token) for an access token, even when
// using PKCE, for "Web application" type OAuth clients. Doing that exchange
// in the browser would mean shipping the secret in the JS bundle — instead
// the browser calls this function, and this function calls Google.
//
// Called as POST /.netlify/functions/google-drive-token
// Body: { action: 'exchange', code, verifier, redirectUri }
//    or { action: 'refresh', refreshToken }

// Google Cloud Console > "Ominibase Forms Client" (Web application client)
const CLIENT_ID = '423726952026-2dehn302mj629g57fpqvd3v9svfull5p.apps.googleusercontent.com';
const CLIENT_SECRET = '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';

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method not allowed' };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  try {
    let form;
    if (payload.action === 'exchange') {
      form = new URLSearchParams({
        code: payload.code,
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        redirect_uri: payload.redirectUri,
        grant_type: 'authorization_code',
        code_verifier: payload.verifier,
      });
    } else if (payload.action === 'refresh') {
      form = new URLSearchParams({
        refresh_token: payload.refreshToken,
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        grant_type: 'refresh_token',
      });
    } else {
      return { statusCode: 400, body: JSON.stringify({ error: 'Unknown action' }) };
    }

    const res = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form.toString(),
    });
    const json = await res.json();

    if (!res.ok) {
      return { statusCode: res.status, body: JSON.stringify({ error: json.error_description || json.error || 'Token request failed' }) };
    }

    return { statusCode: 200, body: JSON.stringify(json) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: String(err.message || err) }) };
  }
};
