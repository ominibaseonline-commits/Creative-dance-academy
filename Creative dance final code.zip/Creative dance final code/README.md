
  # MDFA STUDIO MANAGEMENT

  This is a code bundle for MDFA STUDIO MANAGEMENT. The original project is available at https://www.figma.com/design/kBCeQ4WFfdR4MmqCUPq2u2/MDFA-STUDIO-MANAGEMENT.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  