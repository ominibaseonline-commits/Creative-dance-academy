# 🔐 Google Sheet License System - Complete Setup Guide

## ✅ **System Successfully Implemented!**

Aapka **Google Sheet-based License Management System** ab fully functional hai! 

---

## 📊 **System Overview**

```
Google Sheet (Your Master Database)
         ↓
   Google Apps Script API
         ↓
   User's CMS Application
         ↓
   Auto-validates every 30 minutes
```

---

## 🎯 **How It Works**

### **1. Google Sheet Structure**

Aapki sheet mein ye columns hone chahiye:

| License Key | User Name | Business | Domain | Created At | Expiry Date | Status | Plan | Phone | Email |
|-------------|-----------|----------|---------|------------|-------------|--------|------|-------|-------|

**Example Data:**
```
License Key: AMS-PZALUFX-C7ZN
User Name: Test Busniess
Business: Test Business
Domain: (leave empty for any domain)
Created At: 2025-01-12
Expiry Date: 2026-01-11
Status: active
Plan: Basic
Phone: -
Email: onlybasic.amit@gmail.com
```

### **2. Google Apps Script API**

✅ **Already Deployed:** 
```
https://script.google.com/macros/s/AKfycbzmqyeF0io_3tVYX0lEC6dTYYEZxPZplGLYiO9_l1n-l8yRvGOgiXj8F8PzOvxW_PI6yA/exec
```

**API Actions:**
- `?action=verify_license&key=XXX&domain=XXX` - License validate karta hai
- Returns: `{ success: true/false, code: "...", message: "...", ... }`

---

## 🚀 **User Flow (Customer Side)**

### **First Time Setup:**

1. **User app kholta hai**
   ```
   ┌─────────────────────────────┐
   │  Enter Your License Key     │
   │  [AMS-XXXX-XXXX-XXXX]      │
   │  [Activate License]         │
   └─────────────────────────────┘
   ```

2. **License key enter karta hai**
   - User apna license key type karta hai
   - Format: `AMS-XXXX-XXXX-XXXX`

3. **System validates**
   - Google Sheet se API call
   - License check hota hai (valid/expired/revoked)

4. **If Valid:**
   ```
   ✅ License activated successfully!
   Business: Test Business
   Valid until: 11-Jan-2026
   
   → Login page opens
   ```

5. **If Invalid/Expired:**
   ```
   ❌ License expired on 11-Jan-2025
   Please contact administrator
   
   → Shows error message
   ```

### **Returning User:**

1. **App opens automatically**
2. **License auto-validates** (every 30 min or on startup)
3. **If still valid:** Login page shows
4. **If expired:** System locks with message

---

## 👨‍💼 **Admin Flow (Aapka Side)**

### **New Customer Ko License Dena:**

**Step 1: Google Sheet mein entry add karo**
```
Row: 5
License Key: AMS-NEW1-CUST-2025
User Name: Customer Name
Business: ABC Dance Academy
Domain: (blank) or specific domain
Created At: 2025-06-03
Expiry Date: 2025-07-03 (1 month)
Status: active
Plan: Monthly - ₹500
Phone: 9876543210
Email: customer@example.com
```

**Step 2: Customer ko license key send karo**
```
WhatsApp/Email Template:

🎉 Welcome to [Your CMS Name]!

Your license details:
🔑 License Key: AMS-NEW1-CUST-2025
📅 Valid Until: 03-Jul-2025
💼 Business: ABC Dance Academy

Setup Instructions:
1. Open the app
2. Enter license key: AMS-NEW1-CUST-2025
3. Click "Activate License"
4. Start using the system!

Need help? Contact: [Your Number]
```

**Step 3: Customer activates**
- Customer apni app mein license key enter karega
- Automatically activate ho jayega
- ✅ Done! No manual visit needed

---

## 🔄 **Monthly Renewal Process**

### **Manual Renewal (Aapka Current Process):**

**Step 1: Payment receive karo**
```
Customer: ABC Dance Academy
Payment: ₹500 (Monthly)
Date: 03-Jul-2025
```

**Step 2: Google Sheet update karo**
```
Find row: AMS-NEW1-CUST-2025
Update: Expiry Date = 03-Aug-2025 (+30 days)
Status: active (keep as is)
```

**Step 3: Customer ka app auto-update hoga**
```
Next sync (max 30 min):
  ↓
App checks Google Sheet
  ↓
Sees new expiry: 03-Aug-2025
  ↓
License auto-extends
  ↓
✅ Customer continues working
```

**NO MANUAL VISIT NEEDED!** 🎉

---

## ⚠️ **Non-Payment Scenario**

### **Agar customer ne payment nahi kiya:**

**Before Expiry (Reminder):**
```
7 days before expiry:
  ↓
App shows warning: "License expiring in 7 days"
  ↓
Customer ko reminder call/message karo
```

**After Expiry:**
```
Expiry Date: 03-Jul-2025
Today: 04-Jul-2025
  ↓
Google Sheet: Status remains "active" but date expired
  ↓
App checks on next sync
  ↓
Shows: 🔒 System Locked - License Expired
  ↓
Customer can't login
```

**Payment Ke Baad:**
```
Customer pays ₹500
  ↓
Google Sheet update:
  Expiry Date = 04-Aug-2025 (from today +30 days)
  ↓
Customer app next sync (max 30 min)
  ↓
System auto-unlocks
  ↓
✅ Customer can login again
```

---

## 🛠️ **License Status Codes**

App ye codes return karta hai:

| Code | Meaning | Action |
|------|---------|--------|
| `SUCCESS` | License valid hai | ✅ Allow login |
| `EXPIRED` | License expire ho gaya | 🔒 Lock system |
| `REVOKED` | License suspend kiya gaya | 🔒 Lock system |
| `INVALID` | License key galat hai | ❌ Show error |
| `NOT_FOUND` | License sheet mein nahi mila | ❌ Show error |
| `DOMAIN_MISMATCH` | Wrong domain | ❌ Show error |
| `NETWORK_ERROR` | Internet issue | 📦 Use cached data (7 day grace) |

---

## 📱 **Offline Support (Grace Period)**

```
Internet Available:
  ↓
Check Google Sheet every 30 min
  ↓
Update local cache
  ↓
Work normally

Internet NOT Available:
  ↓
Use cached license data
  ↓
Grace period: 7 days offline
  ↓
After 7 days: Soft warning
  ↓
Internet connect hote hi validate
```

---

## 🔐 **Security Features**

### **1. License Key Format Validation**
```
Valid: AMS-XXXX-XXXX-XXXX
Valid: MDA-XXXX-XXXX
Invalid: ABC123 (rejected)
Invalid: AMS123 (rejected)
```

### **2. Domain Lock (Optional)**
```
Google Sheet:
  Domain: studio.example.com

If user opens on different domain:
  → Rejected (DOMAIN_MISMATCH)

Leave blank for any domain
```

### **3. Auto-Sync Protection**
```
Cache: 30 minutes
Auto-validates: On startup + every 30 min
Can't tamper: Data comes from Google Sheet
```

---

## 💰 **Pricing Plans Integration**

### **Google Sheet Columns:**

Add these columns for advanced tracking:

| License Key | Plan | Monthly Fee | Last Payment | Next Due | Auto-Renew |
|-------------|------|-------------|--------------|----------|------------|
| AMS-XXX... | Basic | ₹500 | 2025-06-03 | 2025-07-03 | No |
| AMS-YYY... | Pro | ₹1000 | 2025-06-03 | 2025-07-03 | Yes |

### **Plan Tiers Example:**

```
Basic Plan (₹500/month):
- 1 location
- 100 students max
- Basic reports

Pro Plan (₹1000/month):
- 3 locations
- Unlimited students
- Advanced reports
- WhatsApp integration

Enterprise (₹2000/month):
- Unlimited locations
- Unlimited students
- Priority support
- Custom features
```

---

## 📊 **Bulk Operations**

### **Extend All Licenses (Diwali Offer Example):**

**Google Sheets Formula:**
```
Agar sabko 15 days extra dena ho:

Old Expiry Date column: F
New formula in temporary column:
=F2+15

Then copy-paste values back to Expiry Date column
```

### **Suspend Multiple Licenses:**
```
Select multiple rows
Status column: Change to "revoked"
All affected users will be locked on next sync
```

---

## 🔧 **Technical Details**

### **Files Created:**

1. **`/src/app/lib/googleSheetLicense.ts`**
   - Google Sheet API integration
   - License validation logic
   - Cache management

2. **`/src/app/components/LicenseKeyInput.tsx`**
   - License key input screen
   - User-facing activation UI

3. **`/src/app/App.tsx`** (Modified)
   - License check on startup
   - Auto-sync logic

### **API Response Format:**

```json
{
  "success": true,
  "code": "SUCCESS",
  "message": "License valid",
  "license_key": "AMS-PZALUFX-C7ZN",
  "business_name": "Test Business",
  "user_name": "Test User",
  "expiry_date": "2026-01-11",
  "days_left": 222,
  "status": "active",
  "plan": "Basic",
  "email": "test@example.com",
  "phone": "9876543210"
}
```

### **Cache Strategy:**

```
LocalStorage Keys:
- user_license_key: Encrypted license key
- user_license_data: Full license info
- google_sheet_license_cache: Cached response
- google_sheet_license_cache_time: Timestamp

Cache Duration: 30 minutes
Grace Period (offline): 7 days
```

---

## 🎯 **Customer Support Templates**

### **License Activation Help:**
```
Hi [Customer],

To activate your license:

1. Open the app
2. You'll see "Enter License Key" screen
3. Type: [LICENSE-KEY]
4. Click "Activate License"
5. Done! Login and start using

Need help? Call/WhatsApp: [Your Number]
```

### **License Expired:**
```
Hi [Customer],

Your license expired on [DATE].

To renew:
1. Pay ₹500 via UPI/Cash
2. Send payment screenshot
3. We'll extend your license within 30 min
4. Your system will auto-unlock

Payment Details:
UPI: [Your UPI]
Bank: [Your Bank Details]
```

### **License Suspended:**
```
Hi [Customer],

Your license has been temporarily suspended.

Reason: [Payment pending / Policy violation / etc]

To resolve:
1. Contact us: [Number]
2. Clear pending dues
3. License will be reactivated immediately

Thank you!
```

---

## 📈 **Dashboard for You (Optional)**

Create a simple dashboard in Google Sheets:

```
===========================================
📊 LICENSE DASHBOARD
===========================================

Total Licenses: =COUNTA(A:A)-1
Active Licenses: =COUNTIF(G:G,"active")
Expired Licenses: =COUNTIF(G:G,"expired")
Revoked Licenses: =COUNTIF(G:G,"revoked")

This Month Revenue: =[Sum of payments received]
Expiring This Week: =[Count licenses expiring in 7 days]
Renewal Due: =[List of customers needing renewal]

===========================================
```

---

## 🚨 **Troubleshooting**

### **Problem: License Not Activating**

**Solution:**
```
1. Check license key format (AMS-XXXX-XXXX-XXXX)
2. Verify key exists in Google Sheet
3. Check Status = "active" in sheet
4. Verify Expiry Date is future date
5. Check internet connection
6. Try again after 30 seconds
```

### **Problem: System Locked But License Valid**

**Solution:**
```
1. Check Google Sheet expiry date
2. Verify status = "active"
3. Ask customer to:
   - Clear browser cache
   - Reload app (Ctrl+F5)
   - Re-enter license key if needed
```

### **Problem: Customer Can't Find License Key**

**Solution:**
```
1. Check your WhatsApp/Email sent to customer
2. Search Google Sheet by business name
3. Resend license key to customer
4. If lost, generate new key
```

---

## 🎉 **Benefits of This System**

✅ **Fully Remote Management**
- No need to visit customer location
- Update license from anywhere
- Google Sheet se control everything

✅ **Automatic Renewal**
- Customer pays → Update sheet → Auto-extends
- No manual intervention needed
- Works within 30 minutes

✅ **Scalable**
- Handle 100+ customers easily
- Bulk operations possible
- One Google Sheet manages all

✅ **Secure**
- License validated from server
- Can't be tampered locally
- Domain lock option available

✅ **Offline Support**
- 7-day grace period
- Works without constant internet
- Auto-syncs when online

---

## 📞 **Next Steps**

### **For You (Admin):**

1. ✅ Test with one customer first
2. ✅ Create license in Google Sheet
3. ✅ Send to customer
4. ✅ Verify activation works
5. ✅ Test expiry by setting past date
6. ✅ Test renewal by updating expiry

### **For Customers:**

1. Receive license key from you
2. Open app
3. Enter license key
4. Start using!

---

## 🎯 **Summary**

**Ab Aap Kya Kar Sakte Ho:**

1. ✅ Google Sheet mein license add karo
2. ✅ Customer ko key send karo (WhatsApp/Email)
3. ✅ Customer khud activate karega
4. ✅ Payment hone par sheet update karo
5. ✅ System automatically extend hoga
6. ✅ No manual visit needed!

**Billing Cycle Example:**

```
01-Jun: Customer pays ₹500
01-Jun: Sheet update → Expiry = 01-Jul
30-Jun: Reminder to customer
01-Jul: Customer pays ₹500
01-Jul: Sheet update → Expiry = 01-Aug
...repeat monthly
```

---

**System is LIVE and READY! 🚀**

Questions? Check troubleshooting section above!
