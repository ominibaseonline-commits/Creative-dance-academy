import { useState, useEffect, useRef } from 'react';
import { LoginPage } from './components/LoginPage';
import { AdminDashboard } from './components/AdminDashboard';
import { StudentDashboard } from './components/StudentDashboard';
import { LicenseKeyInput } from './components/LicenseKeyInput';
import { Toaster } from './components/ui/sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './components/ui/dialog';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { toast } from 'sonner';
import { initServerSync } from './lib/serverSync';
import { getAdminResetEpoch } from './lib/adminReset';
import { migrateFromLocalStorage } from './lib/indexedDB';
import { onAutoBackupRequested, backupToGoogleDrive } from './lib/driveBackup';
import { BusinessProvider } from './contexts/BusinessContext';
import { Lock, CheckCircle2, MessageCircle, Phone, Key, AlertTriangle, ShieldAlert, Lightbulb } from 'lucide-react';
import {
  getStoredLicenseKey,
  getStoredLicenseData,
  validateLicenseFromGoogleSheet,
  isGoogleSheetLicenseValid,
  formatExpiryDateDisplay,
  getDaysUntilExpiryFromDate,
  extractExpiryDate,
  shouldRevalidateLicense,
  GoogleSheetLicenseData
} from './lib/googleSheetLicense';

export default function App() {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [userType, setUserType] = useState<'admin' | 'student' | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [licenseValid, setLicenseValid] = useState<boolean | null>(null);
  const [licenseInfo, setLicenseInfo] = useState<GoogleSheetLicenseData | null>(null);
  const [showLicenseInput, setShowLicenseInput] = useState(false);
  const [showAdminUnlock, setShowAdminUnlock] = useState(false);
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  // Admin login ke waqt ka "reset epoch". Agar kisi device par password license key se reset hua,
  // to ye badal jata hai aur is device ka admin session apne aap logout ho jata hai.
  const adminEpochRef = useRef<string | null>(null);
  // Emergency: license valid hai par server kisi dusri license key ka hai -> login page par
  // "Naya License Key Add Karo" option dikhta hai.
  const [serverMismatch, setServerMismatch] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');

  // Password gate before letting anyone open the "Add New License Key" screen.
  // This is separate from the license key itself — it just protects the
  // button so an end customer can't stumble into re-activating the app
  // with a wrong key.
  // Hint (for you only): apna social media naam + DOB + "@" ke end mein
  const ADMIN_UNLOCK_PASSWORD = 'Mdevilal14022004@';

  const handleAdminUnlock = () => {
    setPasswordInput('');
    setShowPasswordPrompt(true);
  };

  const handlePasswordSubmit = () => {
    if (passwordInput === ADMIN_UNLOCK_PASSWORD) {
      setShowAdminUnlock(true);
      setShowPasswordPrompt(false);
      setPasswordInput('');
    } else {
      toast.error('Galat password! Sirf authorized admin hi naya license key add kar sakta hai.');
      setPasswordInput('');
    }
  };

  // Update banner (Update / Ignore → progress → Restart & Install) plus the
  // "what's new" popup shown right after a restart that installed an update.
  // Rendered via plain DOM (not JSX) so it overlays on top of whichever
  // screen is currently showing — loading, locked, login, or dashboard —
  // without needing changes to every return block below.
  useEffect(() => {
    const win: any = window;
    if (!win.updater) return; // not running inside Electron

    const removeBanner = () => {
      const existing = document.getElementById('app-update-banner');
      if (existing) existing.remove();
    };

    const showBanner = (message: string, opts: { showUpdateBtn?: boolean; showRestartBtn?: boolean } = {}) => {
      removeBanner();
      const banner = document.createElement('div');
      banner.id = 'app-update-banner';
      banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99999;background:#FF8C42;color:#fff;padding:10px 20px;display:flex;align-items:center;justify-content:space-between;font-family:sans-serif;font-size:14px;box-shadow:0 2px 8px rgba(0,0,0,0.15);';

      const text = document.createElement('span');
      text.textContent = message;
      banner.appendChild(text);

      const actions = document.createElement('div');
      actions.style.cssText = 'display:flex;gap:8px;';

      if (opts.showUpdateBtn) {
        const updateBtn = document.createElement('button');
        updateBtn.textContent = 'Update';
        updateBtn.style.cssText = 'background:#fff;color:#FF8C42;border:none;padding:6px 16px;border-radius:6px;font-weight:600;cursor:pointer;';
        updateBtn.onclick = () => {
          win.updater.downloadUpdate();
          showBanner('Downloading update... 0%');
        };
        const ignoreBtn = document.createElement('button');
        ignoreBtn.textContent = 'Ignore';
        ignoreBtn.style.cssText = 'background:transparent;color:#fff;border:1px solid #fff;padding:6px 16px;border-radius:6px;cursor:pointer;';
        ignoreBtn.onclick = () => removeBanner();
        actions.appendChild(updateBtn);
        actions.appendChild(ignoreBtn);
      }

      if (opts.showRestartBtn) {
        const restartBtn = document.createElement('button');
        restartBtn.textContent = 'Restart & Install';
        restartBtn.style.cssText = 'background:#fff;color:#FF8C42;border:none;padding:6px 16px;border-radius:6px;font-weight:600;cursor:pointer;';
        restartBtn.onclick = () => win.updater.installUpdate();
        actions.appendChild(restartBtn);
      }

      banner.appendChild(actions);
      document.body.appendChild(banner);
    };

    win.updater.onUpdateAvailable((info: any) => {
      try {
        localStorage.setItem('pendingChangelog', JSON.stringify({ version: info.version, notes: info.releaseNotes || '' }));
      } catch (e) {}
      showBanner(`New version v${info.version} available.`, { showUpdateBtn: true });
    });

    win.updater.onDownloadProgress((percent: number) => {
      showBanner(`Downloading update... ${Math.round(percent)}%`);
    });

    win.updater.onUpdateDownloaded(() => {
      showBanner('Update ready — restart to install.', { showRestartBtn: true });
    });

    // After a restart that installed a pending update, show what changed
    (async () => {
      try {
        const pending = localStorage.getItem('pendingChangelog');
        if (!pending) return;
        const { version, notes } = JSON.parse(pending);
        const currentVersion = await win.desktopApp?.getAppVersion?.();
        if (currentVersion && currentVersion === version) {
          const overlay = document.createElement('div');
          overlay.id = 'app-whats-new-overlay';
          overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:99998;display:flex;align-items:center;justify-content:center;';
          const box = document.createElement('div');
          box.style.cssText = 'background:#fff;border-radius:10px;padding:24px;max-width:420px;width:90%;font-family:sans-serif;box-shadow:0 10px 30px rgba(0,0,0,0.2);';
          const title = document.createElement('h2');
          title.textContent = `What's New (v${version})`;
          title.style.cssText = 'margin:0 0 12px 0;color:#FF8C42;font-size:18px;';
          const body = document.createElement('p');
          body.textContent = notes || 'App has been updated successfully.';
          body.style.cssText = 'margin:0 0 20px 0;color:#333;white-space:pre-wrap;font-size:14px;line-height:1.5;';
          const closeBtn = document.createElement('button');
          closeBtn.textContent = 'OK';
          closeBtn.style.cssText = 'background:#FF8C42;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-weight:600;cursor:pointer;';
          closeBtn.onclick = () => overlay.remove();
          box.appendChild(title);
          box.appendChild(body);
          box.appendChild(closeBtn);
          overlay.appendChild(box);
          document.body.appendChild(overlay);
        }
        localStorage.removeItem('pendingChangelog');
      } catch (e) {}
    })();

    // Google Drive Auto Backup — main process pings us once a day around
    // 9 PM (only while the app is open); we export fresh data and upload it.
    // Runs quietly: only surfaces a toast on failure, since a silent nightly
    // backup shouldn't interrupt whatever the user is doing.
    onAutoBackupRequested(async () => {
      try {
        const result = await backupToGoogleDrive();
        if (!result.success && result.code !== 'not_connected' && result.code !== 'empty_cms') {
          toast.error('Scheduled Google Drive backup failed. Aap "Backup Now" se manually try kar sakte hain.');
        }
      } catch (e) {
        console.error('Auto backup failed:', e);
      }
    });
  }, []);

  useEffect(() => {
    // Check for data import from URL
    const checkUrlImport = () => {
      const urlParams = new URLSearchParams(window.location.search);
      const importData = urlParams.get('import');
      
      if (importData) {
        try {
          // Decode and parse data
          const decodedData = decodeURIComponent(atob(importData));
          const parsedData = JSON.parse(decodedData);
          
          // Validate data
          if (parsedData.students && parsedData.version) {
            const shouldImport = window.confirm(
              `Data Import Detected!\n\n` +
              `Students: ${parsedData.students.length}\n` +
              `Payments: ${parsedData.payments?.length || 0}\n` +
              `Teachers: ${parsedData.teachers?.length || 0}\n` +
              `Export Date: ${new Date(parsedData.exportDate).toLocaleString()}\n\n` +
              `Do you want to import this data?\n\n` +
              `This will REPLACE your current data!`
            );
            
            if (shouldImport) {
              // Import data to IndexedDB
              const importData = async () => {
                const { importAllData } = await import('./lib/indexedDB');
                await importAllData(parsedData);
                
                // Remove import parameter from URL
                window.history.replaceState({}, document.title, window.location.pathname);
                
                toast.success('Data imported successfully! Reloading...');
                setTimeout(() => window.location.reload(), 1500);
              };
              
              importData();
              return true;
            } else {
              // Remove import parameter from URL
              window.history.replaceState({}, document.title, window.location.pathname);
            }
          }
        } catch (error) {
          console.error('Error importing data from URL:', error);
          toast.error('Failed to import data from URL');
          // Remove invalid import parameter
          window.history.replaceState({}, document.title, window.location.pathname);
        }
      }
      return false;
    };

    // App initialization (license check -> IndexedDB migration -> server sync)
    const initializeApp = async () => {
      // Check URL import first
      const importing = checkUrlImport();
      if (importing) return;

      setIsLoading(true);
      try {
        // ====================================
        // GOOGLE SHEET LICENSE CHECK
        // ====================================
        console.log('🔐 Checking Google Sheet license...');

        // Check if license key exists in storage
        const storedLicenseKey = getStoredLicenseKey();

        if (!storedLicenseKey) {
          // No license key found - show license input screen
          console.log('⚠️ No license key found - showing license input screen');
          setShowLicenseInput(true);
          setLicenseValid(false);
          setIsLoading(false);
          return;
        }

        console.log('🔑 License key found:', storedLicenseKey);

        // Check if we need to revalidate (cache expired)
        let licenseData: GoogleSheetLicenseData | null = null;

        if (shouldRevalidateLicense()) {
          console.log('🔄 Cache expired - revalidating license from Google Sheet...');
          licenseData = await validateLicenseFromGoogleSheet(storedLicenseKey, undefined, { useStoredOnError: true });
        } else {
          console.log('📦 Using cached license data');
          licenseData = getStoredLicenseData();

          // Validate in background for next time
          validateLicenseFromGoogleSheet(storedLicenseKey).catch(err => {
            console.log('Background validation failed:', err);
          });
        }

        setLicenseInfo(licenseData);

        // Check if license is valid
        const isValid = isGoogleSheetLicenseValid(licenseData);
        setLicenseValid(isValid);

        if (!isValid) {
          console.log('❌ License validation failed:', licenseData?.code);

          // Show appropriate error message
          if (licenseData?.code === 'EXPIRED') {
            toast.error(
              `License expired on ${formatExpiryDateDisplay(licenseData.expired_on || '')}! Please contact administrator.`,
              { duration: 10000 }
            );
          } else if (licenseData?.code === 'REVOKED') {
            toast.error('License has been suspended! Please contact administrator.', {
              duration: 10000
            });
          } else if (licenseData?.code === 'INVALID' || licenseData?.code === 'NOT_FOUND') {
            toast.error('Invalid license key! Please contact administrator.', {
              duration: 10000
            });
          } else if (licenseData?.code === 'DOMAIN_MISMATCH') {
            toast.error('License not authorized for this domain! Please contact administrator.', {
              duration: 10000
            });
          }

          setIsLoading(false);
          return;
        }

        // License is valid - always calculate from expiry_date for accuracy
        const expiryStr = extractExpiryDate(licenseData);
        const daysRemaining = expiryStr ? getDaysUntilExpiryFromDate(expiryStr) : (licenseData?.days_left || 0);
        console.log(`✅ License valid - ${daysRemaining} days remaining`);

        const isDemoPlan = (licenseData?.plan || '').toLowerCase() === 'demo';
        if (!isDemoPlan && daysRemaining <= 7 && daysRemaining > 0) {
          toast.warning(`License expiring soon! ${daysRemaining} days remaining.`, {
            duration: 8000
          });
        }

        // Show license info
        if (licenseData?.business_name) {
          console.log(`🏢 Business: ${licenseData.business_name}`);
          console.log(`📅 Valid until: ${formatExpiryDateDisplay(licenseData.expiry_date || '')}`);
        }

        // ====================================
        // CONTINUE WITH APP INITIALIZATION
        // ====================================

        // IMPORTANT: Migrate localStorage to IndexedDB first
        console.log('🔄 Starting IndexedDB migration...');
        await migrateFromLocalStorage();
        console.log('✅ IndexedDB migration completed');
        
        // Server (cloud sync) - sirf tab chalta hai jab server config mila ho
        // (config.json / license data / env). Nahi mila to app pehle ki tarah offline chalta hai.
        try {
          const server = await initServerSync();
          setServerMismatch(server.status === 'mismatch');
          if (server.status === 'ready') {
            console.log('✅ Server connected - data synced');
          } else if (server.status === 'unclaimed') {
            toast.info('Server taiyar hai - Settings > Server mein "Connect Server" dabayein', { duration: 6000 });
          } else if (server.status === 'mismatch') {
            toast.error('Ye server kisi dusri license key ka hai.', { duration: 8000 });
          } else if (server.status === 'schema-missing') {
            toast.warning('Server ka database setup baaki hai (Settings > Server).', { duration: 8000 });
          }
        } catch (serverError) {
          console.error('Server sync init failed:', serverError);
        }
      } catch (error) {
        console.error('Initialization error:', error);
        toast.error('Error loading data. Using local storage.');
      } finally {
        setIsLoading(false);
      }
    };

    initializeApp();
  }, []);

  const handleLogin = async (user: any, type: 'admin' | 'student') => {
    if (type === 'admin') {
      adminEpochRef.current = await getAdminResetEpoch();
    }
    setCurrentUser(user);
    setUserType(type);
    // Do not save to localStorage - session only
  };

  const handleLogout = () => {
    adminEpochRef.current = null;
    setCurrentUser(null);
    setUserType(null);
  };

  // Dusre device par "Forgot Password" (license key) se password reset hua?
  // Server sync jaise hi naya 'settings' data laata hai, epoch compare karke admin ko logout kar do.
  useEffect(() => {
    if (userType !== 'admin') return;
    let cancelled = false;

    const check = async () => {
      if (adminEpochRef.current === null) return;
      const latest = await getAdminResetEpoch();
      if (cancelled || latest === adminEpochRef.current) return;
      adminEpochRef.current = null;
      setCurrentUser(null);
      setUserType(null);
      toast.warning('Password reset ho gaya hai. Dobara login karein.', { duration: 8000 });
    };

    const onSync = (e: Event) => {
      const stores: string[] = (e as CustomEvent).detail || [];
      if (stores.includes('settings')) void check();
    };

    window.addEventListener('server-sync-updated', onSync);
    return () => {
      cancelled = true;
      window.removeEventListener('server-sync-updated', onSync);
    };
  }, [userType]);

  // Admin password popup — "Add New License Key" screen ko protect karta hai
  // (locked screen aur emergency login screen dono me use hota hai).
  const passwordDialog = (
    <Dialog open={showPasswordPrompt} onOpenChange={setShowPasswordPrompt}>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2"><ShieldAlert className="w-5 h-5" /> Admin Password</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Admin password daalein</Label>
                <Input
                  type="password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handlePasswordSubmit()}
                  placeholder="Password"
                  autoFocus
                />
                <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                  <Lightbulb className="w-3.5 h-3.5" /> Hint: Social Media Name + DOB + @
                </p>
              </div>
              <button
                onClick={handlePasswordSubmit}
                className="w-full py-3 rounded-lg text-white font-semibold"
                style={{ backgroundColor: 'var(--brand)' }}
              >
                Unlock
              </button>
            </div>
          </DialogContent>
        </Dialog>
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mb-4"></div>
          <p className="text-lg mb-2">Loading Ominibase CMS...</p>
          <p className="text-sm text-gray-500">Loading Data...</p>
        </div>
      </div>
    );
  }

  // Show License Key Input screen if no license key found
  if (showLicenseInput) {
    return (
      <BusinessProvider>
        <LicenseKeyInput onLicenseValidated={() => window.location.reload()} />
        <Toaster />
      </BusinessProvider>
    );
  }

  // Show locked screen if license is invalid/expired
  if (licenseValid === false) {
    // Admin unlocked → show the normal license key entry screen
    if (showAdminUnlock) {
      return (
        <BusinessProvider>
          <LicenseKeyInput onLicenseValidated={() => window.location.reload()} />
          <Toaster />
        </BusinessProvider>
      );
    }
    // Internet slow / band tha aur pehle ka saved license bhi nahi mila -> sirf "Internet slow" dikhao (expired nahi).
    if (licenseInfo?.code === 'NETWORK_ERROR') {
      return (
        <BusinessProvider>
          <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: 'var(--app-bg)' }}>
            <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-6 border-4 border-orange-400 text-center">
              <h2 className="text-2xl font-bold text-orange-700 mb-2">Internet slow hai</h2>
              <p className="text-gray-700 mb-4">Internet connection slow ya band hai. Internet theek hone par dobara try karein.</p>
              <button
                onClick={() => window.location.reload()}
                className="w-full py-3 rounded-lg text-white font-semibold"
                style={{ backgroundColor: 'var(--brand)' }}
              >
                Dobara Try Karein
              </button>
            </div>
          </div>
          <Toaster />
        </BusinessProvider>
      );
    }
    // Demo plan jo expire ho chuka hai — isko normal "license expired" screen se
    // alag, ek dedicated demo-expiry message dikhana hai (contact number ke saath).
    const isDemoPlan = (licenseInfo?.plan || '').toLowerCase() === 'demo';
    const isExpiredCode = licenseInfo?.code === 'EXPIRED';
    const showDemoExpiredScreen = isDemoPlan && isExpiredCode;
    const CONTACT_PHONE = '7323053397';

    return (
      <BusinessProvider>
        <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: 'var(--app-bg)' }}>
          <div className="max-w-md w-full">
            <div className="text-center mb-8 p-6 rounded-lg" style={{ backgroundColor: 'var(--brand)' }}>
              <h1 className="text-white text-2xl mb-2 flex items-center justify-center gap-2"><Lock className="w-6 h-6" /> System Locked</h1>
              <p className="text-white text-sm">{showDemoExpiredScreen ? 'Demo Session Expired' : 'License Expired'}</p>
            </div>

            {showDemoExpiredScreen ? (
              <div className="bg-white rounded-lg shadow-lg p-6 border-4 border-orange-400">
                <div className="text-center mb-6">
                  <div className="inline-block p-4 bg-orange-100 rounded-full mb-4">
                    <svg className="w-16 h-16 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  </div>
                  <h2 className="text-2xl font-bold text-orange-700 mb-2">Demo Session Expired</h2>
                  <p className="text-gray-700 mb-1">
                    Aapka demo session ki date expiry ho chuki hai.
                  </p>
                  <p className="text-green-700 font-semibold mb-1 flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" /> Aapka data safe hai.
                  </p>
                  <p className="text-gray-700">
                    Kripya paid plan mein switch karein.
                  </p>
                </div>

                {(licenseInfo?.business_name || licenseInfo?.license_key) && (
                  <div className="bg-orange-50 rounded-lg p-4 mb-6 space-y-2 text-sm">
                    {licenseInfo?.business_name && (
                      <div className="flex justify-between border-b border-orange-200 pb-2">
                        <span className="text-gray-600">Business:</span>
                        <span className="font-semibold text-orange-800">{licenseInfo.business_name}</span>
                      </div>
                    )}
                    {licenseInfo?.license_key && (
                      <div className="flex justify-between border-b border-orange-200 pb-2">
                        <span className="text-gray-600">License Key:</span>
                        <span className="font-mono font-semibold text-orange-800">{licenseInfo.license_key}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-gray-600">Demo Ended On:</span>
                      <span className="font-semibold text-orange-800">
                        {formatExpiryDateDisplay(licenseInfo?.expired_on || licenseInfo?.expiry_date || '')}
                      </span>
                    </div>
                  </div>
                )}

                <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4 mb-4">
                  <p className="text-sm text-yellow-800 text-center">
                    <strong className="inline-flex items-center gap-1.5"><MessageCircle className="w-4 h-4" /> Paid plan lene ke liye contact karein:</strong><br />
                    {CONTACT_PHONE} (WhatsApp ya Call)
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <a
                    href={`https://wa.me/91${CONTACT_PHONE}?text=${encodeURIComponent('Hi, mera CMS demo session expire ho gaya hai. Mujhe paid plan lena hai.')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 py-3 rounded-lg text-white font-semibold"
                    style={{ backgroundColor: '#25D366' }}
                  >
                    <MessageCircle className="w-4 h-4" /> WhatsApp
                  </a>
                  <a
                    href={`tel:${CONTACT_PHONE}`}
                    className="flex items-center justify-center gap-2 py-3 rounded-lg text-white font-semibold"
                    style={{ backgroundColor: 'var(--brand)' }}
                  >
                    <Phone className="w-4 h-4" /> Call
                  </a>
                </div>

                <button
                  onClick={handleAdminUnlock}
                  className="w-full mt-4 py-3 rounded-lg text-white font-semibold"
                  style={{ backgroundColor: '#6b7280' }}
                >
                  <Key className="inline w-4 h-4 -mt-0.5 mr-1" /> Naya License Key Add Karo (Admin Only)
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-lg p-6 border-4 border-red-500">
                <div className="text-center mb-6">
                  <div className="inline-block p-4 bg-red-100 rounded-full mb-4">
                    <svg className="w-16 h-16 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  </div>
                  <h2 className="text-2xl font-bold text-red-700 mb-2">Access Denied</h2>
                  <p className="text-gray-600 mb-6">
                    Your license key has {licenseInfo?.isActive === false ? 'been deactivated' : 'expired'}
                  </p>
                </div>

                {licenseInfo && (
                  <div className="bg-red-50 rounded-lg p-4 mb-6 space-y-2 text-sm">
                    <div className="flex justify-between border-b border-red-200 pb-2">
                      <span className="text-gray-600">License Key:</span>
                      <span className="font-mono font-semibold text-red-800">{licenseInfo.license_key || 'N/A'}</span>
                    </div>
                    {licenseInfo.business_name && (
                      <div className="flex justify-between border-b border-red-200 pb-2">
                        <span className="text-gray-600">Business:</span>
                        <span className="font-semibold text-red-800">{licenseInfo.business_name}</span>
                      </div>
                    )}
                    <div className="flex justify-between border-b border-red-200 pb-2">
                      <span className="text-gray-600">Expiry Date:</span>
                      <span className="font-semibold text-red-800">
                        {formatExpiryDateDisplay(licenseInfo.expiry_date || licenseInfo.expired_on || '')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Status:</span>
                      <span className="px-3 py-1 bg-red-200 text-red-800 rounded-full text-xs font-semibold">
                        {licenseInfo.code === 'REVOKED' ? 'REVOKED' : 'EXPIRED'}
                      </span>
                    </div>
                  </div>
                )}

                <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4">
                  <p className="text-sm text-yellow-800 text-center">
                    <strong className="inline-flex items-center gap-1.5"><AlertTriangle className="w-4 h-4" /> To regain access:</strong><br />
                    Please contact your system administrator to renew your license key.
                  </p>
                </div>

                <button
                  onClick={handleAdminUnlock}
                  className="w-full mt-4 py-3 rounded-lg text-white font-semibold"
                  style={{ backgroundColor: 'var(--brand)' }}
                >
                  <Key className="inline w-4 h-4 -mt-0.5 mr-1" /> Naya License Key Add Karo (Admin Only)
                </button>
              </div>
            )}
          </div>
        </div>

        {passwordDialog}

        <Toaster />
      </BusinessProvider>
    );
  }

  // Emergency (server mismatch): admin unlock hone par naya license key screen
  if (showAdminUnlock) {
    return (
      <BusinessProvider>
        <LicenseKeyInput onLicenseValidated={() => window.location.reload()} />
        <Toaster />
      </BusinessProvider>
    );
  }

  if (!currentUser || !userType) {
    return (
      <BusinessProvider>
        <LoginPage
          onLogin={handleLogin}
          licenseInfo={licenseInfo}
          emergencyKeyOption={serverMismatch}
          onEmergencyNewKey={handleAdminUnlock}
        />
        {passwordDialog}
        <Toaster />
      </BusinessProvider>
    );
  }

  return (
    <BusinessProvider>
      <div className="min-h-screen bg-gray-50">
        {userType === 'admin' ? (
          <AdminDashboard user={currentUser} onLogout={handleLogout} />
        ) : (
          <StudentDashboard user={currentUser} onLogout={handleLogout} />
        )}
        <Toaster />
      </div>
    </BusinessProvider>
  );
}
