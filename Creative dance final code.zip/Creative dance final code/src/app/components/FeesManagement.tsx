import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Search, Plus, FileText, MessageCircle, Edit, Trash2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { getAllStudents, saveStudent, getAllPayments, savePayment, getPaymentsByRegNo, deletePayment } from '../lib/indexedDB';
import { useBusinessName } from '../contexts/BusinessContext';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import { splitDues } from '../lib/dues';
import { buildBrandingHeader, buildBrandingFooter, printDocument } from '../lib/printReceipt';

export function FeesManagement() {
  const { businessName, businessLogo, businessAddress, businessPhone } = useBusinessName();
  const { matchesLocation, selectedLocation } = useLocationFilter();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [showPaymentSummary, setShowPaymentSummary] = useState(false);
  const [savedPayment, setSavedPayment] = useState<any>(null);
  const [paymentHistory, setPaymentHistory] = useState<any[]>([]);
  const [editingPayment, setEditingPayment] = useState<any>(null);
  // true when the form was opened from "Update Dues" (pay off the old balance), false for a new fees payment
  const payingDuesRef = useRef(false);

  const [paymentData, setPaymentData] = useState({
    regNo: '',
    paymentDate: new Date().toISOString().split('T')[0],
    sessionDate: new Date().toISOString().split('T')[0],
    duration: '',
    durationType: '',
    sessionExpiryDate: '',
    totalAmount: '',
    paidAmount: '',
    dues: 0,
    paymentMode: ''
  });

  useEffect(() => {
    if (selectedStudent && !matchesLocation(selectedStudent.location)) {
      setSelectedStudent(null);
      setPaymentHistory([]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedLocation]);

  useEffect(() => {
    if (selectedStudent) {
      loadPaymentHistory();
    }
  }, [selectedStudent]);

  useEffect(() => {
    if (paymentData.sessionDate && paymentData.duration && paymentData.durationType) {
      const startDate = new Date(paymentData.sessionDate);
      let expiryDate = new Date(startDate);
      const duration = parseInt(paymentData.duration);
      if (paymentData.durationType === 'Days') {
        expiryDate.setDate(expiryDate.getDate() + duration);
      } else if (paymentData.durationType === 'Month') {
        expiryDate.setMonth(expiryDate.getMonth() + duration);
      } else if (paymentData.durationType === 'Year') {
        expiryDate.setFullYear(expiryDate.getFullYear() + duration);
      }
      setPaymentData(prev => ({ ...prev, sessionExpiryDate: expiryDate.toISOString().split('T')[0] }));
    }
  }, [paymentData.sessionDate, paymentData.duration, paymentData.durationType]);

  useEffect(() => {
    const total = parseFloat(paymentData.totalAmount) || 0;
    const paid = parseFloat(paymentData.paidAmount) || 0;
    setPaymentData(prev => ({ ...prev, dues: total - paid }));
  }, [paymentData.totalAmount, paymentData.paidAmount]);

  const handleSearch = async () => {
    const allStudents = await getAllStudents();
    const students = allStudents.filter((s: any) => !s.deactivated && matchesLocation(s.location));
    const student = students.find((s: any) =>
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.regNo.includes(searchTerm) ||
      s.mobile.includes(searchTerm) ||
      s.alternateMobile?.includes(searchTerm)
    );
    if (student) {
      setSelectedStudent(student);
      await loadPaymentHistory(student.regNo);
      toast.success('Student found!');
    } else {
      toast.error(selectedLocation === 'all' ? 'Student not found!' : `Student not found in ${selectedLocation}!`);
      setSelectedStudent(null);
    }
  };

  const loadPaymentHistory = async (regNo?: string) => {
    const studentRegNo = regNo || selectedStudent?.regNo;
    if (!studentRegNo) return;
    const studentPayments = await getPaymentsByRegNo(studentRegNo);
    // Newest payment first — id is auto-incrementing, so a higher id always means
    // it was added more recently (reliable even when multiple payments share the
    // same Payment Date).
    const sorted = [...studentPayments].sort((a: any, b: any) => (b.id || 0) - (a.id || 0));
    setPaymentHistory(sorted);
  };

  const handleUpdateDues = () => {
    if (!selectedStudent) return;
    payingDuesRef.current = true;
    if (paymentHistory && paymentHistory.length > 0) {
      // Dues exist from a previous payment cycle — pre-fill last payment's details
      // (paymentHistory is already sorted newest-first by id, so this is just its first item)
      const lastPayment = [...paymentHistory].sort(
        (a: any, b: any) => (b.id || 0) - (a.id || 0)
      )[0];
      setPaymentData({
        regNo: selectedStudent.regNo,
        paymentDate: new Date().toISOString().split('T')[0],
        sessionDate: lastPayment.sessionDate || new Date().toISOString().split('T')[0],
        duration: lastPayment.duration || '',
        durationType: lastPayment.durationType || '',
        sessionExpiryDate: lastPayment.sessionExpiryDate || '',
        totalAmount: selectedStudent.dues > 0 ? selectedStudent.dues.toString() : '',
        paidAmount: selectedStudent.dues > 0 ? selectedStudent.dues.toString() : '',
        dues: 0,
        paymentMode: ''
      });
    } else {
      // Dues exist since admission (no payment record yet) — pre-fill admission date & expiry date
      setPaymentData({
        regNo: selectedStudent.regNo,
        paymentDate: new Date().toISOString().split('T')[0],
        sessionDate: selectedStudent.admissionDate || new Date().toISOString().split('T')[0],
        duration: selectedStudent.duration || '',
        durationType: selectedStudent.durationType || '',
        sessionExpiryDate: selectedStudent.expiryDate || '',
        totalAmount: selectedStudent.dues > 0 ? selectedStudent.dues.toString() : '',
        paidAmount: selectedStudent.dues > 0 ? selectedStudent.dues.toString() : '',
        dues: 0,
        paymentMode: ''
      });
    }
    setEditingPayment(null);
    setShowPaymentForm(true);
  };

  const handleAddPayment = () => {
    if (!selectedStudent) return;
    payingDuesRef.current = false;
    // Auto-fill session expiry date from student's existing expiry date
    const studentExpiryDate = selectedStudent.expiryDate || '';
    setPaymentData({
      regNo: selectedStudent.regNo,
      paymentDate: new Date().toISOString().split('T')[0],
      sessionDate: studentExpiryDate || new Date().toISOString().split('T')[0],
      duration: '',
      durationType: '',
      sessionExpiryDate: '',
      totalAmount: selectedStudent.dues > 0 ? selectedStudent.dues.toString() : '',
      paidAmount: selectedStudent.dues > 0 ? selectedStudent.dues.toString() : '',
      dues: 0,
      paymentMode: ''
    });
    setEditingPayment(null);
    setShowPaymentForm(true);
  };

  const handleSavePayment = async () => {
    if (!paymentData.duration || !paymentData.durationType ||
      !paymentData.totalAmount || !paymentData.paidAmount ||
      !paymentData.paymentMode) {
      toast.error('Please fill all required fields');
      return;
    }
    try {
      const paymentToSave = { ...paymentData, name: selectedStudent.name };
      await savePayment(paymentToSave);
      const updatedStudent = { ...selectedStudent };
      updatedStudent.expiryDate = paymentData.sessionExpiryDate;
      updatedStudent.duration = paymentData.duration;
      updatedStudent.durationType = paymentData.durationType;
      const previousDues = parseFloat(selectedStudent.dues) || 0;
      const paidAmount = parseFloat(paymentData.paidAmount) || 0;
      const totalAmount = parseFloat(paymentData.totalAmount) || 0;
      const newDues = totalAmount - paidAmount;

      const currentPaidAmount = parseFloat(updatedStudent.paidAmount) || 0;
      updatedStudent.paidAmount = currentPaidAmount + paidAmount; // always credit exactly what was paid this time
      const remaining = newDues > 0 ? newDues : 0; // remaining owed after this transaction
      // Split: paying off an old admission balance keeps the rest as Admission Dues;
      // a normal fees payment leaves its balance as Monthly Dues.
      const before = splitDues(selectedStudent, paymentHistory.length > 0);
      if (payingDuesRef.current && before.admission > 0) {
        updatedStudent.admissionDues = remaining;
        updatedStudent.monthlyDues = 0;
      } else {
        updatedStudent.admissionDues = 0;
        updatedStudent.monthlyDues = remaining;
      }
      updatedStudent.dues = updatedStudent.admissionDues + updatedStudent.monthlyDues;

      if (previousDues > 0 && paidAmount >= previousDues) {
        toast.success('Admission dues cleared successfully!');
      }
      await saveStudent(updatedStudent);
      window.dispatchEvent(new CustomEvent('studentsUpdated')); // Google Sheet ko jaldi sync ho
      setSelectedStudent(updatedStudent);
      setSavedPayment(paymentToSave);
      setShowPaymentForm(false);
      setShowPaymentSummary(true);
      await loadPaymentHistory();
      toast.success(editingPayment ? 'Payment updated successfully!' : 'Payment saved successfully!');
    } catch (error) {
      console.error('Error saving payment:', error);
      toast.error('Failed to save payment. Please try again.');
    }
  };

  const handleEditPayment = (payment: any) => {
    payingDuesRef.current = false;
    setPaymentData(payment);
    setEditingPayment(payment);
    setShowPaymentForm(true);
  };

  const handleDeletePayment = async (payment: any) => {
    if (!confirm('Are you sure you want to delete this payment record?')) return;
    try {
      if (payment.id) {
        await deletePayment(payment.id);
        const remainingPayments = await getPaymentsByRegNo(payment.regNo);

        // Revert the student's expiry date to whatever the most recent
        // REMAINING payment says, so deleting the latest payment doesn't
        // leave a stale future expiry date behind.
        if (selectedStudent && selectedStudent.regNo === payment.regNo) {
          const students = await getAllStudents();
          const studentRecord = students.find((s: any) => s.regNo === payment.regNo);
          if (studentRecord) {
            if (remainingPayments && remainingPayments.length > 0) {
              // Same "most recent" definition as the Payment History table itself
              // (highest id = most recently added) — so the expiry date always
              // matches whatever record is now sitting at the top of the list.
              const mostRecent = [...remainingPayments].sort(
                (a: any, b: any) => (b.id || 0) - (a.id || 0)
              )[0];
              const updatedStudent = {
                ...studentRecord,
                expiryDate: mostRecent.sessionExpiryDate || studentRecord.expiryDate,
                dues: parseFloat(mostRecent.dues) || 0,
                admissionDues: 0,
                monthlyDues: parseFloat(mostRecent.dues) || 0,
              };
              await saveStudent(updatedStudent);
              window.dispatchEvent(new CustomEvent('studentsUpdated'));
              setSelectedStudent(updatedStudent);
            } else {
              // No payments left at all — nothing to revert to, leave as-is
              setSelectedStudent(studentRecord);
            }
          }
        }

        await loadPaymentHistory();
        toast.success('Payment record deleted successfully!');
      } else {
        toast.error('Cannot delete payment without ID');
      }
    } catch (error) {
      console.error('Error deleting payment:', error);
      toast.error('Failed to delete payment. Please try again.');
    }
  };

  const handlePrint = async (payment: any) => {
    const formatDate = (dateString: string) => {
      if (!dateString) return 'N/A';
      return new Date(dateString).toLocaleDateString('en-GB');
    };
    const studentName = payment.name || selectedStudent?.name || 'Student';
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${studentName} - Payment Receipt</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; }
          .header { background-color: #E8630A; padding: 20px; text-align: center; margin-bottom: 30px; color: white; }
          .header h1 { margin: 0; color: white; }
          .section { margin-bottom: 20px; }
          .section h2 { background-color: #FCE6D4; padding: 10px; margin-bottom: 10px; }
          .row { display: flex; padding: 8px 0; border-bottom: 1px solid #eee; }
          .label { font-weight: bold; width: 200px; }
          .value { flex: 1; }
        </style>
      </head>
      <body>
        ${buildBrandingHeader({ businessName, businessLogo, businessAddress }, 'Payment Receipt')}
        <div class="section">
          <h2>Student Information</h2>
          <div class="row"><div class="label">Registration No:</div><div class="value">${payment.regNo}</div></div>
          <div class="row"><div class="label">Student Name:</div><div class="value">${studentName}</div></div>
          <div class="row"><div class="label">Payment Date:</div><div class="value">${formatDate(payment.paymentDate)}</div></div>
        </div>
        <div class="section">
          <h2>Session Information</h2>
          <div class="row"><div class="label">Session Date:</div><div class="value">${formatDate(payment.sessionDate)}</div></div>
          <div class="row"><div class="label">Duration:</div><div class="value">${payment.duration} ${payment.durationType}</div></div>
          <div class="row"><div class="label">Session Expiry Date:</div><div class="value">${formatDate(payment.sessionExpiryDate)}</div></div>
        </div>
        <div class="section">
          <h2>Payment Information</h2>
          <div class="row"><div class="label">Total Amount:</div><div class="value">₹${payment.totalAmount}</div></div>
          <div class="row"><div class="label">Paid Amount:</div><div class="value">₹${payment.paidAmount}</div></div>
          <div class="row"><div class="label">Dues:</div><div class="value">₹${payment.dues}</div></div>
          <div class="row"><div class="label">Payment Mode:</div><div class="value">${payment.paymentMode}</div></div>
        </div>
        ${buildBrandingFooter({ businessName, businessPhone }, 'payment')}
      </body>
      </html>
    `;
    await printDocument(html, `${studentName}_Payment_Receipt`);
  };

  const handleWhatsApp = (payment: any) => {
    if (!selectedStudent?.mobile) {
      toast.error('Mobile number not found!');
      return;
    }
    const formatDate = (dateString: string) => {
      if (!dateString) return 'N/A';
      return new Date(dateString).toLocaleDateString('en-GB');
    };
    const message =
`*${businessName.toUpperCase()}*
*Payment Receipt*

*Student Details:*
Name: ${payment.name || selectedStudent.name}
Reg No: ${payment.regNo}

*Payment Details:*
Payment Date: ${formatDate(payment.paymentDate)}
Session Date: ${formatDate(payment.sessionDate)}
Duration: ${payment.duration} ${payment.durationType}
Total Amount: ₹${payment.totalAmount}
Paid Amount: ₹${payment.paidAmount}
Dues: ₹${payment.dues}
Payment Mode: ${payment.paymentMode}
Expiry Date: ${formatDate(payment.sessionExpiryDate)}

Thank you for your payment!`;
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/91${selectedStudent.mobile}?text=${encodedMessage}`, '_blank');
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-GB');
  };

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Fees Management</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search Section */}
          <div className="flex gap-2">
            <Input
              placeholder="Search by Name, Reg No, Mobile, or Alternate Mobile..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            />
            <Button onClick={handleSearch}>
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
          </div>

          {/* Student Details */}
          {selectedStudent && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
                <div><p className="text-gray-500">Reg No</p><p>{selectedStudent.regNo}</p></div>
                <div><p className="text-gray-500">Name</p><p>{selectedStudent.name}</p></div>
                <div><p className="text-gray-500">Mobile</p><p>{selectedStudent.mobile}</p></div>
                <div><p className="text-gray-500">Category</p><p>{selectedStudent.category}</p></div>
                <div><p className="text-gray-500">Sub Category</p><p>{selectedStudent.subCategory || 'N/A'}</p></div>
                <div><p className="text-gray-500">Batch Time</p><p>{selectedStudent.batchTime}</p></div>
                <div><p className="text-gray-500">Location</p><p>{selectedStudent.location || 'N/A'}</p></div>
                <div><p className="text-gray-500">Admission Date</p><p>{formatDate(selectedStudent.admissionDate)}</p></div>
                <div><p className="text-gray-500">Duration</p><p>{selectedStudent.duration ? `${selectedStudent.duration} ${selectedStudent.durationType}` : 'N/A'}</p></div>
                <div>
                  <p className="text-gray-500">Expiry Date</p>
                  <p className={new Date(selectedStudent.expiryDate) < new Date() ? 'text-red-600' : 'text-green-600'}>
                    {formatDate(selectedStudent.expiryDate)}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Dues</p>
                  <div className="flex items-center gap-2">
                    <p className={selectedStudent.dues > 0 ? 'text-red-600' : 'text-green-600'}>
                      ₹{selectedStudent.dues || 0}
                    </p>
                    {selectedStudent.dues > 0 && (
                      <Button size="sm" variant="outline" onClick={() => { toast.info(`Student ${selectedStudent.name} has pending dues of ₹${selectedStudent.dues}.`, { duration: 5000 }); handleUpdateDues(); }} className="ml-2 bg-orange-50 border-orange-300 hover:bg-orange-100">
                        Update
                      </Button>
                    )}
                  </div>
                </div>
              </div>

              <Button onClick={handleAddPayment}>
                <Plus className="w-4 h-4 mr-2" />
                Add Payment
              </Button>

              {/* Payment History */}
              <div>
                <h3 className="mb-4">Payment History</h3>
                {paymentHistory.length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Payment Date</TableHead>
                          <TableHead>Duration</TableHead>
                          <TableHead>Total Amount</TableHead>
                          <TableHead>Paid Amount</TableHead>
                          <TableHead>Dues</TableHead>
                          <TableHead>Session Date</TableHead>
                          <TableHead>Session Expiry</TableHead>
                          <TableHead>Payment Mode</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {paymentHistory.map((payment, index) => (
                          <TableRow key={index}>
                            <TableCell>{formatDate(payment.paymentDate)}</TableCell>
                            <TableCell>{payment.duration} {payment.durationType}</TableCell>
                            <TableCell>₹{payment.totalAmount}</TableCell>
                            <TableCell>₹{payment.paidAmount}</TableCell>
                            <TableCell>₹{payment.dues}</TableCell>
                            <TableCell>{formatDate(payment.sessionDate)}</TableCell>
                            <TableCell>{formatDate(payment.sessionExpiryDate)}</TableCell>
                            <TableCell>{payment.paymentMode}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button size="sm" variant="outline" onClick={() => handlePrint(payment)}><FileText className="w-3 h-3" /></Button>
                                <Button size="sm" variant="outline" onClick={() => handleEditPayment(payment)}><Edit className="w-3 h-3" /></Button>
                                <Button size="sm" variant="outline" onClick={() => handleWhatsApp(payment)}><MessageCircle className="w-3 h-3" /></Button>
                                <Button size="sm" variant="outline" onClick={() => handleDeletePayment(payment)}><Trash2 className="w-3 h-3" /></Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <p className="text-center text-gray-500 py-8">No payment history found</p>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payment Form Dialog */}
      <Dialog open={showPaymentForm} onOpenChange={setShowPaymentForm}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingPayment ? 'Edit Payment' : 'Add Payment'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded">
              <h3>Student Information</h3>
              <p>Reg No: {selectedStudent?.regNo}</p>
              <p>Name: {selectedStudent?.name}</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Payment Date *</Label>
                <Input type="date" value={paymentData.paymentDate} onChange={(e) => setPaymentData({...paymentData, paymentDate: e.target.value})} />
              </div>
              <div>
                <Label>Session Date *</Label>
                <Input type="date" value={paymentData.sessionDate} onChange={(e) => setPaymentData({...paymentData, sessionDate: e.target.value})} />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Duration *</Label>
                <Input type="number" value={paymentData.duration} onChange={(e) => setPaymentData({...paymentData, duration: e.target.value})} placeholder="Enter duration" min="1" />
              </div>
              <div>
                <Label>Duration Type *</Label>
                <Select value={paymentData.durationType} onValueChange={(value) => setPaymentData({...paymentData, durationType: value})}>
                  <SelectTrigger><SelectValue placeholder="Select duration type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Days">Days</SelectItem>
                    <SelectItem value="Month">Month</SelectItem>
                    <SelectItem value="Year">Year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Session Expiry Date</Label>
                <Input type="date" value={paymentData.sessionExpiryDate} disabled />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Total Amount *</Label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5">₹</span>
                  <Input type="number" value={paymentData.totalAmount} onChange={(e) => setPaymentData({...paymentData, totalAmount: e.target.value})} placeholder="0" className="pl-8" min="0" />
                </div>
              </div>
              <div>
                <Label>Paid Amount *</Label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5">₹</span>
                  <Input type="number" value={paymentData.paidAmount} onChange={(e) => setPaymentData({...paymentData, paidAmount: e.target.value})} placeholder="0" className="pl-8" min="0" />
                </div>
              </div>
              <div>
                <Label>Dues</Label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5">₹</span>
                  <Input type="number" value={paymentData.dues} disabled className="pl-8" />
                </div>
              </div>
            </div>
            <div>
              <Label>Payment Mode *</Label>
              <div className="flex gap-4 mt-2">
                {['Cash', 'Online'].map((mode) => (
                  <div key={mode} className="flex items-center gap-2">
                    <Checkbox checked={paymentData.paymentMode === mode} onCheckedChange={() => setPaymentData({...paymentData, paymentMode: mode})} />
                    <span>{mode}</span>
                  </div>
                ))}
              </div>
            </div>
            <Button onClick={handleSavePayment} className="w-full">
              {editingPayment ? 'Update Payment' : 'Save Payment & Generate Receipt'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Summary Dialog */}
      <Dialog open={showPaymentSummary} onOpenChange={setShowPaymentSummary}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Payment Summary</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-green-50 rounded">
              <h3 className="text-green-600 mb-2">Payment Saved Successfully!</h3>
              <div className="space-y-2">
                <p>Student: {savedPayment?.name}</p>
                <p>Reg No: {savedPayment?.regNo}</p>
                <p>Amount Paid: ₹{savedPayment?.paidAmount}</p>
                <p>Session Expiry: {formatDate(savedPayment?.sessionExpiryDate)}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => handleWhatsApp(savedPayment)} className="flex-1">
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
              </Button>
              <Button onClick={() => handlePrint(savedPayment)} variant="outline" className="flex-1">
                <FileText className="w-4 h-4 mr-2" />
                Print
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
