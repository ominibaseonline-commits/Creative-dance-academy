import { useEffect, useState } from 'react';
import { CalendarCheck, Copy, Link2, RefreshCw, Unplug, CheckCircle2, Smartphone, Plus, Trash2, Shuffle, MessageCircle, Save } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { getAllBatches } from '../lib/indexedDB';
import { batchSortKey } from '../lib/batchTime';
import {
  AttendanceConfig,
  buildAttendanceScript,
  connectAttendance,
  disconnectAttendance,
  getAttendanceConfig,
  getStaffConfig,
  pushAttendanceConfig,
  pushStaffConfig,
  randomPin,
  saveAttendanceOptions,
  saveStaffConfig,
  staffLink,
  StaffConfig,
  StaffMember,
  syncStudentsToScript,
} from '../lib/attendance';

export function AttendanceSetup() {
  const [config, setConfig] = useState<AttendanceConfig | null>(null);
  const [urlInput, setUrlInput] = useState('');
  const [connecting, setConnecting] = useState(false);
  const [syncing, setSyncing] = useState(false);

  const load = async () => {
    const c = await getAttendanceConfig();
    setConfig(c);
    setUrlInput(c.webAppUrl);
  };

  useEffect(() => { load(); }, []);

  if (!config) return null;
  const connected = !!config.webAppUrl;
  const script = buildAttendanceScript(config.adminKey);

  const copyScript = async () => {
    try {
      await navigator.clipboard.writeText(script);
      toast.success('Code copy ho gaya! Ab Google Apps Script me paste karein.');
    } catch {
      toast.error('Copy nahi hua. Box me click karke Ctrl+A, Ctrl+C karein.');
    }
  };

  const handleConnect = async () => {
    if (!urlInput.trim()) { toast.error('Pehle Web App URL paste karein'); return; }
    setConnecting(true);
    try {
      await connectAttendance(urlInput);
      await load();
      toast.success('Attendance connect ho gaya! Students sync ho gaye.');
    } catch (e: any) {
      toast.error(e?.message || 'Connect nahi ho paya');
    } finally {
      setConnecting(false);
    }
  };

  const handleSync = async () => {
    setSyncing(true);
    try {
      const r = await syncStudentsToScript({ force: true });
      await load();
      toast.success(`${r.total} students sync ho gaye`);
    } catch (e: any) {
      toast.error(e?.message || 'Sync fail ho gaya');
    } finally {
      setSyncing(false);
    }
  };

  const handleDisconnect = async () => {
    await disconnectAttendance();
    await load();
    toast.success('Attendance disconnect kar diya');
  };

  const handleToggle = async (field: 'enableCheckout' | 'blockExpired', value: boolean) => {
    await saveAttendanceOptions({ [field]: value });
    setConfig({ ...config, [field]: value });
    if (connected) {
      try {
        await pushAttendanceConfig(true);
        toast.success('Setting save ho gayi');
      } catch (e: any) {
        toast.error(e?.message || 'Script tak setting nahi pahunchi');
      }
    }
  };

  return (
    <div className="mt-8 pt-6 border-t-2 border-orange-200 space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h3 className="flex items-center gap-2 text-lg font-semibold">
          <CalendarCheck className="w-5 h-5 text-orange-600" />
          Attendance Setup
        </h3>
        {connected ? (
          <span className="flex items-center gap-1 text-sm px-3 py-1 rounded-full bg-green-100 text-green-700">
            <CheckCircle2 className="w-4 h-4" /> Connected
          </span>
        ) : (
          <span className="text-sm px-3 py-1 rounded-full bg-gray-200 text-gray-600">Not connected</span>
        )}
      </div>

      {/* Step 1 — code */}
      <div className="p-4 bg-orange-50 rounded-lg border border-orange-200 space-y-3">
        <p className="font-medium">Step 1: Google Apps Script code</p>
        <ol className="list-decimal ml-5 text-sm text-gray-700 space-y-1">
          <li>Naya Google Sheet banayein → <b>Extensions → Apps Script</b> kholein.</li>
          <li>Neeche ka code copy karke wahan paste karein (purana code hata dein) → <b>Save</b>.</li>
          <li>
            <b>Deploy → New deployment → Web app</b>. <b>Execute as: Me</b>, <b>Who has access: Anyone</b> → Deploy.
          </li>
          <li>Jo <b>Web app URL</b> mile use neeche paste karke Connect karein.</li>
        </ol>
        <textarea
          readOnly
          value={script}
          onFocus={(e) => e.currentTarget.select()}
          className="w-full h-40 p-3 text-xs font-mono bg-white border rounded-md"
        />
        <Button onClick={copyScript} variant="outline">
          <Copy className="w-4 h-4 mr-2" />
          Copy Code
        </Button>
      </div>

      {/* Step 2 — URL */}
      <div className="p-4 bg-gray-50 rounded-lg border space-y-3">
        <p className="font-medium">Step 2: Web App URL</p>
        <div>
          <Label>Web App URL</Label>
          <div className="flex gap-2">
            <Input
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="https://script.google.com/macros/s/.../exec"
              onKeyDown={(e) => e.key === 'Enter' && handleConnect()}
            />
            <Button onClick={handleConnect} disabled={connecting}>
              <Link2 className="w-4 h-4 mr-2" />
              {connecting ? 'Connecting...' : connected ? 'Reconnect' : 'Connect'}
            </Button>
          </div>
        </div>

        {connected && (
          <div className="flex items-center justify-between flex-wrap gap-2 text-sm">
            <span className="text-gray-600">
              {config.lastSyncAt
                ? `Last sync: ${new Date(config.lastSyncAt).toLocaleString('en-GB')}`
                : 'Abhi tak sync nahi hua'}
            </span>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={handleSync} disabled={syncing}>
                <RefreshCw className={`w-4 h-4 mr-2 ${syncing ? 'animate-spin' : ''}`} />
                Sync Students Now
              </Button>
              <Button size="sm" variant="outline" className="text-red-600 border-red-300" onClick={handleDisconnect}>
                <Unplug className="w-4 h-4 mr-2" />
                Disconnect
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Options */}
      <div className="p-4 bg-gray-50 rounded-lg border space-y-4">
        <p className="font-medium">Options</p>
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-medium">Check-out option</p>
            <p className="text-xs text-gray-500">
              Off: sirf Check-in. On: student baad me Check-out bhi kar sakta hai (optional).
            </p>
          </div>
          <Switch checked={config.enableCheckout} onCheckedChange={(v) => handleToggle('enableCheckout', v)} />
        </div>
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-medium">Expired students ka check-in block karein</p>
            <p className="text-xs text-gray-500">
              Off: expired student ko red "Renewal Now" dikhega, par check-in ho jayega. On: check-in nahi hoga.
            </p>
          </div>
          <Switch checked={config.blockExpired} onCheckedChange={(v) => handleToggle('blockExpired', v)} />
        </div>
      </div>

      {/* Staff mobile panel */}
      <StaffPanelSetup webAppUrl={config.webAppUrl} connected={connected} />
    </div>
  );
}


// ---------------------------------------------------------------------------
// Staff Attendance Panel — admin turns it on, makes a PIN per staff member, picks which
// batches each can see, and sends the link. Staff open the link on their phone.
// ---------------------------------------------------------------------------
function StaffPanelSetup({ webAppUrl, connected }: { webAppUrl: string; connected: boolean }) {
  const [cfg, setCfg] = useState<StaffConfig | null>(null);
  const [batches, setBatches] = useState<string[]>([]);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      setCfg(await getStaffConfig());
      const all = await getAllBatches();
      const times: string[] = Array.from(new Set<string>(all.map((b: any) => String(b.batchTime || '')).filter(Boolean)));
      times.sort((a, b) => batchSortKey(a) - batchSortKey(b) || a.localeCompare(b));
      setBatches(times);
    })();
  }, []);

  if (!cfg) return null;
  const link = staffLink(webAppUrl);

  const update = (next: StaffConfig) => { setCfg(next); setDirty(true); };
  const patchMember = (id: string, patch: Partial<StaffMember>) =>
    update({ ...cfg, staff: cfg.staff.map((m) => (m.id === id ? { ...m, ...patch } : m)) });

  const usedPins = () => new Set(cfg.staff.map((m) => m.pin));
  const freshPin = () => { let p = randomPin(); const used = usedPins(); while (used.has(p)) p = randomPin(); return p; };

  const addStaff = () =>
    update({
      ...cfg,
      staff: [...cfg.staff, { id: `st${Date.now().toString(36)}`, name: '', pin: freshPin(), allBatches: false, batches: [] }],
    });

  const toggleBatch = (m: StaffMember, b: string) =>
    patchMember(m.id, { batches: m.batches.includes(b) ? m.batches.filter((x) => x !== b) : [...m.batches, b] });

  const handleSave = async () => {
    const pins = new Set<string>();
    for (const m of cfg.staff) {
      if (!m.name.trim()) { toast.error('Har staff ka naam daalein'); return; }
      if (!/^\d{4,8}$/.test(m.pin)) { toast.error(`${m.name}: PIN 4 se 8 digit ka hona chahiye`); return; }
      if (pins.has(m.pin)) { toast.error('Do staff ka PIN same nahi ho sakta'); return; }
      pins.add(m.pin);
      if (!m.allBatches && m.batches.length === 0) { toast.error(`${m.name}: kam se kam 1 batch chunein`); return; }
    }
    setSaving(true);
    try {
      const clean = { ...cfg, staff: cfg.staff.map((m) => ({ ...m, name: m.name.trim() })) };
      await saveStaffConfig(clean);
      setCfg(clean);
      if (connected) await pushStaffConfig(true);
      setDirty(false);
      toast.success(connected ? 'Staff panel save ho gaya' : 'Save ho gaya. Attendance connect hote hi script tak pahunchega');
    } catch (e: any) {
      toast.error(e?.message || 'Script tak setting nahi pahunchi');
    } finally {
      setSaving(false);
    }
  };

  const copy = async (text: string, msg: string) => {
    try { await navigator.clipboard.writeText(text); toast.success(msg); } catch { toast.error('Copy nahi hua'); }
  };

  const shareLink = () => {
    const text = `Staff Attendance panel ka link:\n${link}\n\n(PIN alag se bhej raha hu)`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="p-4 bg-gray-50 rounded-lg border space-y-4">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <p className="font-medium flex items-center gap-2"><Smartphone className="w-4 h-4 text-orange-600" /> Staff Attendance Panel (Mobile)</p>
          <p className="text-xs text-gray-500 mt-0.5">
            Staff ko link bhejein. Wo PIN daalke apne batch ke students dekhega aur Absent par tap karke Present mark karega.
          </p>
        </div>
        <Switch checked={cfg.enabled} onCheckedChange={(v) => update({ ...cfg, enabled: v })} />
      </div>

      {cfg.enabled && (
        <>
          {/* link */}
          <div className="space-y-2">
            <Label>Staff Link</Label>
            {connected ? (
              <div className="flex gap-2 flex-wrap">
                <Input readOnly value={link} onFocus={(e) => e.currentTarget.select()} className="flex-1 min-w-[220px] text-xs font-mono" />
                <Button size="sm" variant="outline" onClick={() => copy(link, 'Link copy ho gaya')}><Copy className="w-4 h-4 mr-1.5" />Copy</Button>
                <Button size="sm" variant="outline" className="text-green-700 border-green-300" onClick={shareLink}><MessageCircle className="w-4 h-4 mr-1.5" />WhatsApp</Button>
              </div>
            ) : (
              <p className="text-xs text-yellow-700 bg-yellow-50 border border-yellow-300 rounded-md p-2">Link banane ke liye pehle upar Attendance connect karein.</p>
            )}
            <p className="text-xs text-gray-500">Link aur PIN alag-alag bhejna better hai. Har staff ka apna PIN hota hai — PIN se hi pata chalta hai ki kaun sa batch khulega.</p>
          </div>

          {/* staff list */}
          <div className="space-y-3">
            {cfg.staff.length === 0 && <p className="text-sm text-gray-500">Abhi koi staff nahi hai. "Staff Add Karein" dabayein.</p>}
            {cfg.staff.map((m) => (
              <div key={m.id} className="bg-white border rounded-lg p-3 space-y-3">
                <div className="flex gap-2 flex-wrap items-end">
                  <div className="flex-1 min-w-[160px]">
                    <Label className="text-xs">Staff ka naam</Label>
                    <Input value={m.name} onChange={(e) => patchMember(m.id, { name: e.target.value })} placeholder="e.g. Govind Sir" />
                  </div>
                  <div className="w-40">
                    <Label className="text-xs">PIN (4-8 digit)</Label>
                    <div className="flex gap-1">
                      <Input
                        value={m.pin}
                        inputMode="numeric"
                        maxLength={8}
                        onChange={(e) => patchMember(m.id, { pin: e.target.value.replace(/\D/g, '') })}
                        className="font-mono tracking-widest"
                      />
                      <Button type="button" size="icon" variant="outline" title="Naya PIN banayein" onClick={() => patchMember(m.id, { pin: freshPin() })}>
                        <Shuffle className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  <Button type="button" size="icon" variant="outline" title="PIN copy" onClick={() => copy(m.pin, 'PIN copy ho gaya')}><Copy className="w-4 h-4" /></Button>
                  <Button type="button" size="icon" variant="outline" className="text-red-600 border-red-300" title="Staff hatayein"
                    onClick={() => update({ ...cfg, staff: cfg.staff.filter((x) => x.id !== m.id) })}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>

                <div>
                  <div className="flex items-center justify-between">
                    <Label className="text-xs">Batch access</Label>
                    <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer">
                      <Switch checked={m.allBatches} onCheckedChange={(v) => patchMember(m.id, { allBatches: v })} />
                      Saare batches
                    </label>
                  </div>
                  {!m.allBatches && (
                    <div className="mt-2 grid gap-1.5 sm:grid-cols-2 max-h-44 overflow-y-auto">
                      {batches.length === 0 && <p className="text-xs text-gray-500">Pehle Batches section me batch banayein.</p>}
                      {batches.map((b) => (
                        <label key={b} className={`flex items-center gap-2 text-sm px-2.5 py-1.5 rounded-md border cursor-pointer ${m.batches.includes(b) ? 'bg-orange-50 border-orange-300' : 'bg-white'}`}>
                          <input type="checkbox" className="w-4 h-4 accent-orange-500" checked={m.batches.includes(b)} onChange={() => toggleBatch(m, b)} />
                          {b}
                        </label>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          <Button size="sm" variant="outline" onClick={addStaff}><Plus className="w-4 h-4 mr-1.5" />Staff Add Karein</Button>
        </>
      )}

      <div className="flex items-center gap-3 flex-wrap">
        <Button onClick={handleSave} disabled={saving || !dirty} className="bg-orange-500 hover:bg-orange-600 text-white">
          <Save className="w-4 h-4 mr-2" />{saving ? 'Saving...' : 'Save Staff Panel'}
        </Button>
        {dirty && <span className="text-xs text-orange-600">Changes abhi save nahi hue</span>}
      </div>
    </div>
  );
}
