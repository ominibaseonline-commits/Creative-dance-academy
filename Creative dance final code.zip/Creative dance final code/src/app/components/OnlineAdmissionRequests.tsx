import { useEffect, useState } from 'react';
import { Globe, RefreshCw, Check, X, Phone, Clock, Loader2, Inbox } from 'lucide-react';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { useFormLayout } from '../lib/formLayout';
import {
  AdmissionRequest,
  claimAdmissionRequest,
  refreshAdmissionRequests,
  removeAdmissionRequest,
  setAdmissionPrefill,
  useAdmissionRequests,
} from '../lib/onlineAdmission';

// Sidebar -> Online Admission
// Students ke online form se aayi requests. Approve = Admission Form bhara hua khulta hai,
// Reject = request hata di jati hai.
export function OnlineAdmissionRequests({ onOpenForm }: { onOpenForm: () => void }) {
  const { items, loading, error } = useAdmissionRequests();
  const { fields } = useFormLayout();
  const [busyId, setBusyId] = useState('');

  useEffect(() => { refreshAdmissionRequests(); }, []);

  const labelOf = (id: string) => fields.find((f) => f.id === id)?.label || id;

  // Approve: data CMS ki local list se turant Admission Form me chala jata hai (Google ka wait nahi).
  // "Ye request kisi aur computer ne le li" ka check peeche background me hota hai.
  const approve = (r: AdmissionRequest) => {
    setAdmissionPrefill(r);
    onOpenForm();
    claimAdmissionRequest(r.id)
      .then((c) => {
        if (!c.ok) toast.warning(c.reason === 'gone'
          ? 'Dhyan dein: ye request kisi aur computer se hat chuki hai.'
          : 'Dhyan dein: is request ko koi aur computer bhi approve kar raha hai.');
      })
      .catch(() => { /* net nahi to bhi admission ho sakti hai */ });
  };

  const reject = async (r: AdmissionRequest) => {
    if (!window.confirm(`"${r.data.core.name || 'Student'}" ki online request hata dein?`)) return;
    setBusyId(r.id);
    await removeAdmissionRequest(r.id);
    setBusyId('');
    toast.success('Request hata di gayi');
  };

  const fmtTime = (t: string) => {
    const d = new Date(t);
    return isNaN(d.getTime()) ? t : d.toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: true });
  };

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-3">
            <CardTitle className="flex items-center gap-2">
              <Globe className="w-6 h-6" /> Online Admission
              {items.length > 0 && <span className="text-sm font-normal bg-orange-500 text-white rounded-full px-2.5 py-0.5">{items.length}</span>}
            </CardTitle>
            <Button variant="outline" size="sm" onClick={() => refreshAdmissionRequests()} disabled={loading}>
              <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} /> Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {error && <div className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800">{error}</div>}

          {!error && items.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              {loading ? <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" /> : <Inbox className="w-10 h-10 mx-auto mb-2 text-gray-300" />}
              <p>{loading ? 'Loading...' : 'Abhi koi online admission request nahi hai.'}</p>
            </div>
          )}

          {items.map((r) => {
            const core = r.data.core || {};
            const rest = [
              ...Object.entries(core).filter(([k]) => !['name', 'mobile', 'category', 'subCategory', 'batchTime', 'location'].includes(k)),
              ...Object.entries(r.data.custom || {}),
            ].filter(([, v]) => String(v || '').trim());
            const busy = busyId === r.id;
            return (
              <div key={r.id} className="rounded-lg border bg-white p-4 flex flex-col md:flex-row md:items-center gap-4">
                <div className="flex-1 min-w-0 space-y-1.5">
                  <div className="flex items-center gap-3 flex-wrap">
                    <p className="font-semibold text-base">{core.name || 'Student'}</p>
                    <span className="flex items-center gap-1 text-sm text-gray-600"><Phone className="w-3.5 h-3.5" /> {core.mobile}</span>
                    <span className="flex items-center gap-1 text-xs text-gray-500"><Clock className="w-3.5 h-3.5" /> {fmtTime(r.time)}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 text-xs">
                    {core.category && <span className="rounded-md bg-orange-50 border border-orange-200 text-orange-800 px-2 py-0.5">{core.category}{core.subCategory ? ` - ${core.subCategory}` : ''}</span>}
                    {core.batchTime && <span className="rounded-md bg-blue-50 border border-blue-200 text-blue-800 px-2 py-0.5">{core.batchTime}</span>}
                    {core.location && <span className="rounded-md bg-gray-100 border text-gray-700 px-2 py-0.5">{core.location}</span>}
                  </div>
                  {rest.length > 0 && (
                    <p className="text-xs text-gray-600 leading-relaxed">
                      {rest.map(([k, v]) => `${labelOf(k)}: ${v}`).join('  •  ')}
                    </p>
                  )}
                  {r.claimBy && <p className="text-xs text-amber-700">Ye request abhi {r.claimBy} par khuli hai (10 min me wapas free ho jati hai).</p>}
                </div>
                <div className="flex gap-2 shrink-0">
                  <Button onClick={() => approve(r)} disabled={busy || !!r.claimBy} className="bg-green-600 hover:bg-green-700 text-white">
                    {busy ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Check className="w-4 h-4 mr-1" />} Approve
                  </Button>
                  <Button variant="outline" onClick={() => reject(r)} disabled={busy} className="text-red-600 border-red-200 hover:bg-red-50">
                    <X className="w-4 h-4 mr-1" /> Reject
                  </Button>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
