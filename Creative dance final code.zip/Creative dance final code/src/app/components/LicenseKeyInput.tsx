import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { toast } from 'sonner';
import { Shield, Key, Lock, CheckCircle, AlertCircle, FileText, Lightbulb } from 'lucide-react';
import {
  validateLicenseFromGoogleSheet,
  storeLicenseKey,
  storeLicenseData,
  formatExpiryDateDisplay,
  GoogleSheetLicenseData
} from '../lib/googleSheetLicense';
import { useBusinessName } from '../contexts/BusinessContext';

interface LicenseKeyInputProps {
  onLicenseValidated: (data: GoogleSheetLicenseData) => void;
}

export function LicenseKeyInput({ onLicenseValidated }: LicenseKeyInputProps) {
  const { businessName } = useBusinessName();
  const [licenseKey, setLicenseKey] = useState('');
  const [validating, setValidating] = useState(false);
  const [error, setError] = useState('');

  const handleValidateLicense = async () => {
    // Clear previous errors
    setError('');

    // Validate input
    if (!licenseKey.trim()) {
      setError('Please enter your license key');
      toast.error('Please enter your license key');
      return;
    }

    // Basic format validation (AMS-XXXX-XXXX-XXXX or MDA-XXXX-XXXX)
    const normalizedKey = licenseKey.trim().toUpperCase();
    const licensePattern = /^(AMS|MDA|CMS)-[A-Z0-9]{4,}-[A-Z0-9]{4,}/i;

    if (!licensePattern.test(normalizedKey)) {
      setError('Invalid license key format. Expected format: CMS-XXXX-XXXX-XXXX');
      toast.error('Invalid license key format');
      return;
    }

    setValidating(true);

    try {
      console.log('🔑 Validating license key:', normalizedKey);

      // Call Google Sheet API
      const result = await validateLicenseFromGoogleSheet(normalizedKey);

      console.log('📊 Validation result:', result);

      if (result.success) {
        // License is valid
        storeLicenseKey(normalizedKey);
        storeLicenseData(result);

        toast.success(
          `License activated successfully!\nBusiness: ${result.business_name || 'N/A'}\nValid until: ${formatExpiryDateDisplay(result.expiry_date || '')}`,
          { duration: 5000 }
        );

        // Reload to apply license
        setTimeout(() => {
          onLicenseValidated(result);
        }, 1500);
      } else {
        // License validation failed
        let errorMessage = 'License validation failed';

        switch (result.code) {
          case 'EXPIRED':
            errorMessage = `License expired on ${formatExpiryDateDisplay(result.expired_on || '')}. Please contact your administrator for renewal.`;
            break;
          case 'REVOKED':
            errorMessage = 'This license has been revoked/suspended. Please contact your administrator.';
            break;
          case 'INVALID':
            errorMessage = 'Invalid license key. Please check and try again.';
            break;
          case 'DOMAIN_MISMATCH':
            errorMessage = 'This license is not authorized for this domain. Please contact your administrator.';
            break;
          case 'NOT_FOUND':
            errorMessage = 'License key not found in database. Please verify your license key.';
            break;
          case 'NETWORK_ERROR':
            errorMessage = result.message || 'Network error. Please check your internet connection and try again.';
            break;
          default:
            errorMessage = result.message || 'License validation failed. Please try again.';
        }

        setError(errorMessage);
        toast.error(errorMessage, { duration: 7000 });
      }
    } catch (error) {
      console.error('❌ License validation error:', error);
      const errorMsg = 'Failed to validate license. Please check your internet connection and try again.';
      setError(errorMsg);
      toast.error(errorMsg);
    } finally {
      setValidating(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: 'var(--app-bg)' }}>
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8 p-6 rounded-lg" style={{ backgroundColor: 'var(--brand)' }}>
          <div className="flex items-center justify-center gap-3 mb-2">
            <Shield className="w-8 h-8 text-white" />
            <h1 className="text-white text-2xl font-bold">{businessName}</h1>
          </div>
          <p className="text-white text-sm">License Activation Required</p>
        </div>

        {/* Main Card */}
        <Card className="p-6 shadow-xl border-2 border-orange-300">
          <div className="text-center mb-6">
            <div className="inline-block p-4 bg-orange-100 rounded-full mb-4">
              <Lock className="w-12 h-12 text-orange-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-800 mb-2">Enter License Key</h2>
            <p className="text-gray-600 text-sm">
              Please enter your license key to activate the system
            </p>
          </div>

          {/* License Key Input */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="license-key" className="flex items-center gap-2 mb-2">
                <Key className="w-4 h-4" />
                License Key
              </Label>
              <Input
                id="license-key"
                type="text"
                value={licenseKey}
                onChange={(e) => {
                  setLicenseKey(e.target.value.toUpperCase());
                  setError(''); // Clear error on input
                }}
                placeholder="CMS-XXXX-XXXX-XXXX"
                className="font-mono text-center text-lg border-orange-300"
                maxLength={50}
                disabled={validating}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && !validating) {
                    handleValidateLicense();
                  }
                }}
              />
              <p className="text-xs text-gray-500 mt-1 text-center">
                Format: CMS-XXXX-XXXX-XXXX
              </p>
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-800">{error}</p>
              </div>
            )}

            {/* Activate Button */}
            <Button
              onClick={handleValidateLicense}
              disabled={validating || !licenseKey.trim()}
              className="w-full bg-orange-600 hover:bg-orange-700 text-lg py-6"
            >
              {validating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Validating License...
                </>
              ) : (
                <>
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Activate License
                </>
              )}
            </Button>
          </div>

          {/* Information Box */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h3 className="font-semibold text-sm text-blue-900 mb-2 flex items-center gap-1.5"><FileText className="w-4 h-4" /> How to Get License Key:</h3>
            <ol className="text-xs text-blue-800 space-y-1 list-decimal list-inside">
              <li>Contact your system administrator</li>
              <li>Provide your business name and details</li>
              <li>Receive unique license key via email/WhatsApp</li>
              <li>Enter the key above and click "Activate License"</li>
            </ol>
          </div>

          {/* Help Text */}
          <div className="mt-4 p-3 bg-yellow-50 rounded border border-yellow-300">
            <p className="text-xs text-yellow-800 text-center">
              <strong className="inline-flex items-center gap-1"><Lightbulb className="w-4 h-4" /> Need Help?</strong><br />
              Contact your administrator for license key or assistance
            </p>
          </div>

          {/* Features List */}
          <div className="mt-6 space-y-2">
            <h3 className="text-sm font-semibold text-gray-700 mb-2">After Activation:</h3>
            <div className="space-y-1.5">
              {[
                'Complete student management system',
                'Payment tracking and receipts',
                'Reports and analytics',
                'WhatsApp integration',
                'Offline mode support'
              ].map((feature, idx) => (
                <div key={idx} className="flex items-center gap-2 text-xs text-gray-600">
                  <CheckCircle className="w-3 h-3 text-green-600" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Footer */}
        <div className="mt-4 text-center">
          <p className="text-xs text-gray-600">
            Powered by {businessName}
          </p>
        </div>
      </div>
    </div>
  );
}
