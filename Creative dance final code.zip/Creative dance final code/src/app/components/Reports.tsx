import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner';
import {
  Users, Trophy, AlertTriangle, Ticket, Wallet, TrendingDown, CalendarDays,
  RefreshCw, Search, Inbox, CheckCircle2, XCircle, Send, Clock, User, MapPin, ChevronLeft, ChevronRight,
} from 'lucide-react';
import { getStudentsLite } from '../lib/indexedDB';
import { getBatches, getTeachers, getLocations } from '../lib/storageAdapter';
import { useBusinessName } from '../contexts/BusinessContext';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import { DuesSplit } from '../lib/dues';
import { buildAbsentMessage, buildZeroAttendanceMessage } from '../lib/reminderMessages';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { batchSortKey } from '../lib/batchTime';
import { FlexiPlan, FlexiUsage, computeFlexiUsage, getFlexiPlans, planFor } from '../lib/flexi';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import {
  AttendanceRecord,
  buildDuesMap,
  fetchAttendance,
  getAttendanceConfig,
  getCachedAttendance,
  getCachedAttendanceDates,
} from '../lib/attendance';

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

type Records = Record<string, AttendanceRecord>;

const DAY_NAMES = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const WEEK_HEAD = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
const NO_BATCH = '__none__';
const GOOD_PERCENT = 75;

const pad = (n: number) => String(n).padStart(2, '0');
const toYMD = (y: number, m: number, d: number) => `${y}-${pad(m + 1)}-${pad(d)}`;
const todayStr = () => new Date().toLocaleDateString('en-CA');
// Parse YYYY-MM-DD as a *local* date (new Date('YYYY-MM-DD') would be UTC and can shift the day)
const parseYMD = (s: string) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const fmtLong = (s: string) => { const d = parseYMD(s); return `${pad(d.getDate())} ${MONTH_NAMES[d.getMonth()].slice(0, 3)} ${d.getFullYear()}`; };
const fmtSlash = (s: string) => { const d = parseYMD(s); return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`; };
const weekdayOf = (s: string) => DAY_NAMES[parseYMD(s).getDay()];

const regKey = (s: any) => String(s.regNo).toLowerCase();
const batchKeyOf = (s: any) => (s.batchTime && String(s.batchTime).trim()) || NO_BATCH;
const isExpired = (s: any, onDate: string) => !!s.expiryDate && String(s.expiryDate).slice(0, 10) < onDate;
const money = (n: number) => `₹${n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

// FLEXI students: the app has no dedicated "flexi" field, so a student counts as flexi when
// the word "flexi" appears in their category / sub-category / batch name, or they carry a
// flexi flag. Change this one function if you store flexi students differently.
const isFlexi = (s: any, batchNameByTime: Record<string, string>) => {
  if (s.flexi === true || s.isFlexi === true) return true;
  const hay = [s.category, s.subCategory, s.plan, s.studentType, batchNameByTime[s.batchTime]]
    .filter(Boolean).join(' ').toLowerCase();
  return hay.includes('flexi');
};

// A student should be expected on `date` only if admitted by then (and if the batch runs that weekday).
const admittedBy = (s: any, date: string) => {
  const a = s.admissionDate ? String(s.admissionDate).slice(0, 10) : '';
  return !a || a <= date;
};

interface BatchInfo { batchTime: string; batchName?: string; location?: string; weeklySchedule?: string[] }

interface BatchReportData {
  key: string;
  label: string;
  location: string;
  teachers: string;
  present: any[];
  absent: any[];
}

/** Builds the batch-wise present/absent lists for one day. */
function buildDayReport(
  date: string,
  students: any[],
  records: Records,
  batches: BatchInfo[],
  teachers: any[],
): { batches: BatchReportData[]; present: number; absent: number; hasData: boolean } {
  const hasData = Object.values(records).some((r) => r?.checkIn);
  if (!hasData) return { batches: [], present: 0, absent: 0, hasData: false };

  const batchByTime = new Map<string, BatchInfo>();
  batches.forEach((b) => batchByTime.set(b.batchTime, b));

  const groups = new Map<string, any[]>();
  students.filter((s) => admittedBy(s, date)).forEach((s) => {
    const k = batchKeyOf(s);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k)!.push(s);
  });

  const out: BatchReportData[] = [];
  groups.forEach((list, key) => {
    const info = batchByTime.get(key);
    const present = list.filter((s) => records[regKey(s)]?.checkIn);
    // Only batch slots whose attendance was actually marked (at least one check-in) are shown
    if (present.length === 0) return;
    const absent = list.filter((s) => !records[regKey(s)]?.checkIn);
    const location = info?.location || list[0]?.location || '';
    out.push({
      key,
      label: key === NO_BATCH ? 'No Batch' : key,
      location,
      teachers: teachers.filter((t) => t.location === location).map((t) => t.name).join(', '),
      present,
      absent,
    });
  });
  out.sort((a, b) => batchSortKey(a.label) - batchSortKey(b.label) || a.label.localeCompare(b.label));
  return {
    batches: out,
    present: out.reduce((n, b) => n + b.present.length, 0),
    absent: out.reduce((n, b) => n + b.absent.length, 0),
    hasData: true,
  };
}

// ---------------------------------------------------------------------------
// small UI pieces
// ---------------------------------------------------------------------------

function ExpiredTag() {
  return <span className="text-red-600 text-xs font-semibold ml-1.5 uppercase">Expired</span>;
}

function DuesTag({ dues }: { dues?: DuesSplit }) {
  if (!dues) return null;
  return (
    <>
      {dues.admission > 0 && <span className="text-orange-500 text-xs font-semibold ml-2">Adm: {money(dues.admission)}</span>}
      {dues.monthly > 0 && <span className="text-orange-500 text-xs font-semibold ml-2">Mon: {money(dues.monthly)}</span>}
    </>
  );
}

interface BatchCardProps {
  data: BatchReportData;
  date: string;
  duesMap: Record<string, DuesSplit>;
  variant: 'today' | 'history';
  onRemind?: (student: any, batchLabel: string) => void;
}

function BatchReportCard({ data, date, duesMap, variant, onRemind }: BatchCardProps) {
  const total = data.present.length + data.absent.length;
  const isToday = variant === 'today';

  return (
    <div className="rounded-2xl border border-orange-200 overflow-hidden bg-orange-50/60">
      {/* header */}
      {isToday ? (
        <div className="px-4 py-2 bg-gradient-to-r from-pink-100 to-orange-100 flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="font-bold text-sm flex items-center gap-1.5"><Clock className="w-4 h-4 text-red-500" />{data.label}</div>
            <div className="text-xs text-gray-600 flex items-center gap-1.5 mt-0.5">
              {data.teachers && (<><User className="w-3.5 h-3.5" />{data.teachers}<span>•</span></>)}
              <MapPin className="w-3.5 h-3.5" />{data.location || 'N/A'}
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="px-2 py-0.5 rounded-full bg-green-100 text-green-700 border border-green-200 font-semibold flex items-center gap-1"><CheckCircle2 className="w-4 h-4" />Present: {data.present.length}</span>
            <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-600 border border-red-200 font-semibold flex items-center gap-1"><XCircle className="w-4 h-4" />Absent: {data.absent.length}</span>
            <span className="text-gray-600">Total: {total}</span>
          </div>
        </div>
      ) : (
        <div className="px-4 py-1.5 bg-gradient-to-r from-purple-600 to-purple-500 text-white flex flex-wrap items-center justify-between gap-2">
          <div className="font-bold text-sm flex items-center gap-1.5"><Clock className="w-4 h-4" />{data.label}</div>
          <div className="text-sm flex items-center gap-3">
            <span className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4" />{data.present.length} Present</span>
            <span>|</span>
            <span className="flex items-center gap-1"><XCircle className="w-4 h-4" />{data.absent.length} Absent</span>
          </div>
        </div>
      )}

      {/* body */}
      <div className="grid md:grid-cols-2 md:divide-x divide-orange-200">
        <div className="p-3">
          <h4 className={`font-bold text-xs flex items-center gap-1.5 mb-1.5 text-green-600`}>
            <CheckCircle2 className="w-4 h-4" />{isToday ? 'PRESENT STUDENTS' : 'PRESENT'} ({data.present.length})
          </h4>
          {data.present.length === 0 && <p className="text-xs text-gray-500">Koi present nahi.</p>}
          <ul className={isToday ? 'divide-y divide-orange-200 max-h-56 overflow-y-auto pr-1' : 'space-y-0.5 text-sm'}>
            {data.present.map((s) => (
              <li key={s.regNo} className={isToday ? 'py-1 flex items-center justify-between text-sm' : ''}>
                <div>
                  <span className={isToday ? '' : 'font-medium'}>{s.name}</span>
                  {isToday ? (
                    <>
                      {isExpired(s, date) && <ExpiredTag />}
                      <div className="text-xs text-gray-600">{s.regNo}<DuesTag dues={duesMap[String(s.regNo)]} /></div>
                    </>
                  ) : (
                    <> <span className="text-gray-600">{s.regNo}</span>{isExpired(s, date) && <span className="ml-1.5 text-[11px] font-semibold text-red-600 bg-red-100 rounded px-1.5 py-0.5">EXPIRED</span>}</>
                  )}
                </div>
                {isToday && <CheckCircle2 className="w-5 h-5 text-green-600 shrink-0" />}
              </li>
            ))}
          </ul>
        </div>

        <div className="p-3 border-t md:border-t-0 border-orange-200">
          <h4 className="font-bold text-xs flex items-center gap-1.5 mb-1.5 text-red-600">
            <XCircle className="w-4 h-4" />{isToday ? 'ABSENT STUDENTS' : 'ABSENT'} ({data.absent.length})
          </h4>
          {data.absent.length === 0 && <p className="text-xs text-gray-500">Koi absent nahi.</p>}
          <ul className={isToday ? 'divide-y divide-orange-200 max-h-56 overflow-y-auto pr-1' : 'space-y-0.5 text-sm'}>
            {data.absent.map((s) => (
              <li key={s.regNo} className={isToday ? 'py-1 flex items-center justify-between text-sm' : ''}>
                <div>
                  <span className={isToday ? '' : 'font-medium'}>{s.name}</span>
                  {isToday ? (
                    <>
                      {isExpired(s, date) && <ExpiredTag />}
                      <div className="text-xs text-gray-600">{s.regNo}<DuesTag dues={duesMap[String(s.regNo)]} /></div>
                    </>
                  ) : (
                    <> <span className="text-gray-600">{s.regNo}</span>{isExpired(s, date) && <span className="ml-1.5 text-[11px] font-semibold text-red-600 bg-red-100 rounded px-1.5 py-0.5">EXPIRED</span>}</>
                  )}
                </div>
                {isToday && onRemind && (
                  <button
                    onClick={() => onRemind(s, data.label)}
                    title="WhatsApp bhejein"
                    className="w-8 h-6 rounded-md bg-green-500 hover:bg-green-600 text-white flex items-center justify-center shrink-0"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                )}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}


// Plain table used inside the stat-card popups (peach header like the rest of the app)
function PopupTable({ head, rows, empty }: { head: string[]; rows: ReactNode[][]; empty: string }) {
  return (
    <div className="rounded-2xl border border-orange-200 overflow-hidden">
      <Table className="text-sm">
        <TableHeader>
          <TableRow className="bg-orange-50 hover:bg-orange-50">
            {head.map((h) => <TableHead key={h} className="uppercase text-xs tracking-wider font-bold text-gray-700">{h}</TableHead>)}
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((cells, i) => (
            <TableRow key={i}>{cells.map((c, j) => <TableCell key={j}>{c}</TableCell>)}</TableRow>
          ))}
          {rows.length === 0 && (
            <TableRow><TableCell colSpan={head.length} className="text-center py-8 text-gray-500">{empty}</TableCell></TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}

// ---------------------------------------------------------------------------
// main page
// ---------------------------------------------------------------------------

type CardFilter = 'all' | 'good' | 'poor' | 'flexi' | 'dues' | 'zero';

export function Reports() {
  const { businessName } = useBusinessName();
  const { matchesLocation, selectedLocation } = useLocationFilter();

  const [students, setStudents] = useState<any[]>([]);
  const [batches, setBatches] = useState<BatchInfo[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [duesMap, setDuesMap] = useState<Record<string, DuesSplit>>({});
  const [connected, setConnected] = useState(true);

  // every day we have attendance for (cache first, then filled in from Google in the background)
  const [daily, setDaily] = useState<Record<string, Records>>({});
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  // Re-render when the date changes (app left open past midnight) so "today" and the month list stay current
  const [, setDateTick] = useState(todayStr());
  useEffect(() => {
    const id = setInterval(() => setDateTick(todayStr()), 60 * 1000);
    return () => clearInterval(id);
  }, []);
  const today = todayStr();
  const nowDate = new Date();
  const [calYear, setCalYear] = useState(nowDate.getFullYear());
  const [calMonth, setCalMonth] = useState(nowDate.getMonth());
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [calLocation, setCalLocation] = useState('all');

  const [openCard, setOpenCard] = useState<CardFilter | null>(null); // which stat-card popup is open
  // 0% popup filters: year + month (or whole year) + optional "last N days"
  const [zeroYear, setZeroYear] = useState(String(new Date().getFullYear()));
  const [zeroMon, setZeroMon] = useState(pad(new Date().getMonth() + 1)); // 'all' or '01'..'12'
  const [zeroDays, setZeroDays] = useState<'all' | '7' | '15' | '30'>('all');
  const [openRegs, setOpenRegs] = useState<Set<string>>(new Set()); // student-search cards with the day list open
  const [search, setSearch] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [monthFilter, setMonthFilter] = useState('all'); // 'all' or YYYY-MM
  const [visibleCount, setVisibleCount] = useState(50);

  const fetchedRef = useRef<Set<string>>(new Set());

  // Flexi packages (classes bought / taken / left)
  const [plans, setPlans] = useState<Record<string, FlexiPlan>>({});
  const [flexiUsage, setFlexiUsage] = useState<Record<string, FlexiUsage>>({});
  const [monthLoading, setMonthLoading] = useState(false);

  // ---------- load base data ----------
  const loadBase = useCallback(async () => {
    const [all, b, t, l] = await Promise.all([getStudentsLite(), getBatches(), getTeachers(), getLocations()]);
    const visible = all.filter((s: any) => !s.deactivated && matchesLocation(s.location));
    setStudents(visible);
    setBatches(b);
    setTeachers(t);
    setLocations(l);
    setDuesMap(await buildDuesMap(visible));
  }, [selectedLocation]);

  useEffect(() => { loadBase().catch(() => toast.error('Data load nahi hua')); }, [loadBase]);
  useEffect(() => {
    const h = () => loadBase();
    window.addEventListener('studentsUpdated', h);
    window.addEventListener('batchesUpdated', h);
    return () => { window.removeEventListener('studentsUpdated', h); window.removeEventListener('batchesUpdated', h); };
  }, [loadBase]);

  // ---------- attendance: saved copy first (instant), then Google for the days we are missing ----------
  const putDay = (date: string, records: Records) => setDaily((prev) => ({ ...prev, [date]: records }));

  const loadSavedDays = useCallback(async () => {
    const dates = await getCachedAttendanceDates();
    const loaded: Record<string, Records> = {};
    for (const d of dates) {
      const c = await getCachedAttendance(d);
      if (c) loaded[d] = c.records;
    }
    setDaily((prev) => ({ ...prev, ...loaded }));
    return dates;
  }, []);

  const fetchDay = useCallback(async (date: string, force = false): Promise<boolean> => {
    try {
      const res = await fetchAttendance(date, { force });
      putDay(date, res.records);
      setError('');
      return true;
    } catch (e: any) {
      setError(e?.message || 'Attendance load nahi ho payi');
      return false;
    }
  }, []);

  // Fill the days of a month (up to today) that are not saved on this computer yet. Past days are
  // downloaded once and then kept locally forever, so this is a one-time cost per month.
  const fillMonth = useCallback(async (year: number, month: number) => {
    const last = new Date(year, month + 1, 0).getDate();
    const missing: string[] = [];
    for (let d = 1; d <= last; d++) {
      const ymd = toYMD(year, month, d);
      if (ymd > today) break;
      if (ymd === today) continue; // today is handled by the live path
      if (!fetchedRef.current.has(ymd)) missing.push(ymd);
    }
    missing.forEach((d) => fetchedRef.current.add(d));
    const worker = async () => {
      while (missing.length) {
        const d = missing.shift()!;
        const ok = await fetchDay(d);
        if (!ok) fetchedRef.current.delete(d); // failed (offline?) -> try again next time
      }
    };
    await Promise.all([worker(), worker(), worker()]);
  }, [fetchDay, today]);

  useEffect(() => {
    (async () => {
      const cfg = await getAttendanceConfig();
      setConnected(!!cfg.webAppUrl);
      if (!cfg.webAppUrl) return;
      const saved = await loadSavedDays();
      saved.forEach((d) => fetchedRef.current.add(d));
      await fetchDay(today);
    })();
  }, [loadSavedDays, fetchDay, today]);

  // Whichever month the calendar shows (and the current month, for the stat cards) gets filled in
  // One download job per month, shared by everyone who asks for it (calendar, 0% popup, month filter)
  const monthJobs = useRef<Map<string, Promise<void>>>(new Map());
  const ensureMonth = useCallback((year: number, month: number): Promise<void> => {
    const key = `${year}-${month}`;
    let job = monthJobs.current.get(key);
    if (!job) {
      job = fillMonth(year, month).finally(() => { monthJobs.current.delete(key); });
      monthJobs.current.set(key, job);
    }
    return job;
  }, [fillMonth]);

  useEffect(() => {
    if (!connected) return;
    ensureMonth(nowDate.getFullYear(), nowDate.getMonth());
    if (calYear !== nowDate.getFullYear() || calMonth !== nowDate.getMonth()) ensureMonth(calYear, calMonth);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connected, calYear, calMonth, ensureMonth]);

  // New check-ins arrive via the background live sync
  useEffect(() => {
    const onLive = async (e: Event) => {
      const d = (e as CustomEvent).detail?.date || today;
      const c = await getCachedAttendance(d);
      if (c) putDay(d, c.records);
    };
    window.addEventListener('attendanceUpdated', onLive);
    return () => window.removeEventListener('attendanceUpdated', onLive);
  }, [today]);

  useEffect(() => {
    const load = async () => setPlans(await getFlexiPlans());
    load();
    window.addEventListener('flexiUpdated', load);
    return () => window.removeEventListener('flexiUpdated', load);
  }, []);

  const refreshFlexi = useCallback(async () => setFlexiUsage(await computeFlexiUsage(plans)), [plans]);
  useEffect(() => {
    refreshFlexi();
    window.addEventListener('attendanceUpdated', refreshFlexi);
    return () => window.removeEventListener('attendanceUpdated', refreshFlexi);
  }, [refreshFlexi]);

  const handleRefresh = async () => {
    if (!connected) { toast.error('Pehle Settings → Management & Setup me Attendance connect karein'); return; }
    setRefreshing(true);
    await fetchDay(today, true);
    await refreshFlexi();
    setRefreshing(false);
    toast.success('Report refresh ho gayi');
  };

  useEffect(() => {
    const t = setTimeout(() => setSearchTerm(search), 250);
    return () => clearTimeout(t);
  }, [search]);
  useEffect(() => { setVisibleCount(50); }, [searchTerm, monthFilter]);

  // ---------- per-student attendance numbers ----------
  const batchNameByTime = useMemo(() => {
    const m: Record<string, string> = {};
    batches.forEach((b) => { m[b.batchTime] = b.batchName || ''; });
    return m;
  }, [batches]);

  // Days on which classes actually ran = days where at least one student checked in.
  const classDays = useMemo(
    () => Object.keys(daily).filter((d) => Object.values((daily[d] || {}) as Records).some((r) => r?.checkIn)).sort(),
    [daily],
  );

  const batchByTime = useMemo(() => {
    const m = new Map<string, BatchInfo>();
    batches.forEach((b) => m.set(b.batchTime, b));
    return m;
  }, [batches]);

  /** present / total class days for one student, within the given class days. */
  const statFor = useCallback((s: any, days: string[]) => {
    const sched = batchByTime.get(s.batchTime)?.weeklySchedule;
    let present = 0;
    let total = 0;
    days.forEach((d) => {
      if (!admittedBy(s, d)) return;
      const attended = !!daily[d]?.[regKey(s)]?.checkIn;
      const scheduled = !sched || sched.length === 0 || sched.includes(weekdayOf(d));
      if (attended) { present++; total++; } else if (scheduled) { total++; }
    });
    return { present, total, percent: total === 0 ? 0 : Math.round((present / total) * 100) };
  }, [daily, batchByTime]);

  const thisMonthPrefix = today.slice(0, 7);
  const monthDays = useMemo(() => classDays.filter((d) => d.startsWith(thisMonthPrefix)), [classDays, thisMonthPrefix]);

  const rows = useMemo(() => {
    const days = monthFilter === 'all' ? classDays : classDays.filter((d) => d.startsWith(monthFilter));
    return students.map((s) => {
      const month = statFor(s, monthDays);          // drives the stat cards (current month)
      const shown = statFor(s, days);               // drives the list (selected month filter)
      const d = duesMap[String(s.regNo)] || { admission: 0, monthly: 0 };
      return { s, month, shown, dues: d, flexi: isFlexi(s, batchNameByTime) || !!planFor(plans, s.regNo) };
    });
  }, [students, statFor, monthDays, classDays, monthFilter, duesMap, batchNameByTime, plans]);

  const cards = useMemo(() => {
    const good = rows.filter((r) => r.month.percent >= GOOD_PERCENT).length;
    return {
      total: rows.length,
      good,
      poor: rows.length - good,
      flexi: rows.filter((r) => r.flexi).length,
      dues: rows.reduce((n, r) => n + r.dues.admission + r.dues.monthly, 0),
      zero: rows.filter((r) => r.month.percent === 0).length,
    };
  }, [rows]);

  // ---------- today's report ----------
  const todayRecords = daily[today] || {};
  const todayReport = useMemo(
    () => buildDayReport(today, students, todayRecords, batches, teachers),
    [today, students, todayRecords, batches, teachers],
  );

  // Message text comes from Campaign -> Attendance Messages (admin can edit it there)
  const sendAbsentMessage = async (s: any, batchLabel: string) => {
    const phone = String(s.mobile || '').replace(/\D/g, '').slice(-10);
    if (phone.length !== 10) { toast.error('Is student ka sahi mobile number nahi hai'); return; }
    const msg = await buildAbsentMessage(s, businessName, batchLabel === 'No Batch' ? '' : batchLabel);
    window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  // ---------- student search list ----------
  // Every month (not only the ones that already have attendance): the last 12 months, going further back
  // to the first admission / first saved attendance day (max 3 years). Attendance of a month is
  // downloaded from Google the first time it is picked.
  const monthOptions = useMemo(() => {
    // Current month comes from `today` (not a stale Date) so a new month shows up on its own
    const nowIdx = Number(today.slice(0, 4)) * 12 + (Number(today.slice(5, 7)) - 1);
    let startIdx = nowIdx - 11;
    const consider = (ymd?: string) => {
      if (!ymd || ymd.length < 7) return;
      const y = Number(ymd.slice(0, 4));
      const m = Number(ymd.slice(5, 7)) - 1;
      if (!y || isNaN(m) || m < 0 || m > 11) return;
      startIdx = Math.min(startIdx, y * 12 + m);
    };
    consider(classDays[0]);
    students.forEach((st) => consider(st.admissionDate ? String(st.admissionDate).slice(0, 10) : ''));
    startIdx = Math.max(startIdx, nowIdx - 35);
    const out: string[] = [];
    for (let i = nowIdx; i >= startIdx; i--) out.push(`${Math.floor(i / 12)}-${pad((i % 12) + 1)}`);
    return out;
  }, [classDays, students, thisMonthPrefix]);

  const loadMonth = useCallback(async (ym: string) => {
    if (!connected || !ym || ym === 'all') return;
    const [y, m] = ym.split('-').map(Number);
    setMonthLoading(true);
    try { await ensureMonth(y, m - 1); } finally { setMonthLoading(false); }
  }, [connected, ensureMonth]);

  useEffect(() => { loadMonth(monthFilter); }, [monthFilter, loadMonth]);

  // class days that count for the student search (all saved days, or just the picked month)
  const shownDays = useMemo(
    () => (monthFilter === 'all' ? classDays : classDays.filter((d) => d.startsWith(monthFilter))),
    [classDays, monthFilter],
  );
  const monthFilterLabel = useMemo(() => {
    if (monthFilter === 'all') return 'Poori History';
    const [y, m] = monthFilter.split('-').map(Number);
    return `${MONTH_NAMES[m - 1]} ${y}`;
  }, [monthFilter]);

  /** day-by-day present / absent list of one student (newest first) */
  const historyOf = (s: any) => {
    const sched = batchByTime.get(s.batchTime)?.weeklySchedule;
    const out: { date: string; present: boolean }[] = [];
    shownDays.forEach((d) => {
      if (!admittedBy(s, d)) return;
      const attended = !!daily[d]?.[regKey(s)]?.checkIn;
      const scheduled = !sched || sched.length === 0 || sched.includes(weekdayOf(d));
      if (attended) out.push({ date: d, present: true });
      else if (scheduled) out.push({ date: d, present: false });
    });
    return out.sort((a, b) => b.date.localeCompare(a.date));
  };

  const listRows = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((x) => String(x.s.regNo).toLowerCase().includes(q) || (x.s.name || '').toLowerCase().includes(q) || String(x.s.mobile || '').includes(q));
  }, [rows, searchTerm]);

  const showList = searchTerm.trim() !== '';

  // ---------- stat-card popups ----------
  const goodRows = useMemo(() => rows.filter((r) => r.month.percent >= GOOD_PERCENT), [rows]);
  const poorRows = useMemo(() => rows.filter((r) => r.month.percent < GOOD_PERCENT), [rows]);
  const flexiRows = useMemo(() => rows.filter((r) => r.flexi), [rows]);
  const admDuesRows = useMemo(() => rows.filter((r) => r.dues.admission > 0), [rows]);
  const monDuesRows = useMemo(() => rows.filter((r) => r.dues.monthly > 0), [rows]);

  // 0% popup: students with no class at all in the chosen period (month / whole year / last N days)
  const yearOptions = useMemo(() => Array.from(new Set(monthOptions.map((m) => m.slice(0, 4)))), [monthOptions]);
  const zeroMonthChoices = useMemo(() => monthOptions.filter((m) => m.startsWith(zeroYear)).map((m) => m.slice(5)), [monthOptions, zeroYear]);

  const zeroPeriod = useMemo(() => {
    if (zeroDays !== 'all') {
      const n = Number(zeroDays);
      const start = parseYMD(today);
      start.setDate(start.getDate() - (n - 1));
      const from = start.toLocaleDateString('en-CA');
      const months = Array.from(new Set([from.slice(0, 7), today.slice(0, 7)]));
      return { from, to: today, months, label: `Pichhle ${n} din` };
    }
    if (zeroMon === 'all') {
      return { from: `${zeroYear}-01-01`, to: `${zeroYear}-12-31`, months: monthOptions.filter((m) => m.startsWith(zeroYear)), label: `${zeroYear} (poora saal)` };
    }
    return { from: `${zeroYear}-${zeroMon}-01`, to: `${zeroYear}-${zeroMon}-31`, months: [`${zeroYear}-${zeroMon}`], label: `${MONTH_NAMES[Number(zeroMon) - 1]} ${zeroYear}` };
  }, [zeroDays, zeroMon, zeroYear, monthOptions, today]);

  // Download whatever months the chosen period needs (each month only once, then it stays on this computer)
  useEffect(() => {
    if (openCard !== 'zero' || !connected) return;
    let cancelled = false;
    setMonthLoading(true);
    Promise.all(zeroPeriod.months.map((ym) => { const [y, m] = ym.split('-').map(Number); return ensureMonth(y, m - 1); }))
      .finally(() => { if (!cancelled) setMonthLoading(false); });
    return () => { cancelled = true; };
  }, [openCard, connected, zeroPeriod, ensureMonth]);

  const zeroDayList = useMemo(() => classDays.filter((d) => d >= zeroPeriod.from && d <= zeroPeriod.to), [classDays, zeroPeriod]);
  const zeroHasData = zeroDayList.length > 0;
  const zeroRows = useMemo(
    () => students.filter((s) => statFor(s, zeroDayList).percent === 0),
    [students, statFor, zeroDayList],
  );

  const sendZeroMessage = async (s: any) => {
    const phone = String(s.mobile || '').replace(/\D/g, '').slice(-10);
    if (phone.length !== 10) { toast.error('Is student ka sahi mobile number nahi hai'); return; }
    const msg = await buildZeroAttendanceMessage(s, businessName, zeroPeriod.label);
    window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  // ---------- calendar ----------
  const calLocations = useMemo(() => locations.filter((l: any) => matchesLocation(l.name)), [locations, selectedLocation]);
  const calStudents = useMemo(
    () => (calLocation === 'all' ? students : students.filter((s) => s.location === calLocation)),
    [students, calLocation],
  );
  const calBatches = useMemo(
    () => (calLocation === 'all' ? batches : batches.filter((b) => b.location === calLocation)),
    [batches, calLocation],
  );

  const firstWeekday = new Date(calYear, calMonth, 1).getDay();
  const daysInMonth = new Date(calYear, calMonth + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(firstWeekday).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];

  const shiftMonth = (delta: number) => {
    const d = new Date(calYear, calMonth + delta, 1);
    setCalYear(d.getFullYear());
    setCalMonth(d.getMonth());
    setSelectedDate('');
  };

  const selectedReport = useMemo(
    () => (selectedDate ? buildDayReport(selectedDate, calStudents, daily[selectedDate] || {}, calBatches, teachers) : null),
    [selectedDate, calStudents, daily, calBatches, teachers],
  );

  // ---------- render ----------
  const card = (id: CardFilter, Icon: any, value: string | number, label: string, valueColor: string) => (
    <button
      key={id}
      onClick={() => { if (id === 'zero') { setZeroYear(thisMonthPrefix.slice(0, 4)); setZeroMon(thisMonthPrefix.slice(5)); setZeroDays('all'); } setOpenCard(id); }}
      className={`text-left rounded-2xl bg-white px-4 py-2.5 border transition-shadow hover:shadow-md ${
        openCard === id ? 'border-red-400 ring-2 ring-red-200' : 'border-orange-200'
      }`}
    >
      <Icon className="w-5 h-5 mb-1" />
      <div className={`text-2xl leading-tight font-extrabold ${valueColor}`}>{value}</div>
      <div className="mt-0.5 text-[11px] tracking-wide text-gray-700 uppercase">{label}</div>
    </button>
  );

  return (
    <div className="px-6 pt-3 pb-6 space-y-4">

      {!connected && (
        <div className="p-3 rounded-xl bg-yellow-50 border border-yellow-300 text-sm text-yellow-800 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>Attendance is not connected. Go to <b>Settings → Management & Setup → Attendance Setup</b> to connect.</span>
        </div>
      )}
      {connected && error && (
        <div className="p-3 rounded-xl bg-red-50 border border-red-300 text-sm text-red-700 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" /><span>{error} (Saved data dikh raha hai)</span>
        </div>
      )}

      {/* ===== stat cards ===== */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {card('all', Users, cards.total, 'Total Students', 'text-blue-600')}
        {card('good', Trophy, cards.good, `Good Attendance (${GOOD_PERCENT}%+)`, 'text-green-600')}
        {card('poor', AlertTriangle, cards.poor, `Poor Attendance (<${GOOD_PERCENT}%)`, 'text-red-600')}
        {card('flexi', Ticket, cards.flexi, 'Flexi Students', 'text-purple-600')}
        {card('dues', Wallet, `₹${cards.dues.toLocaleString('en-IN')}`, 'Total Dues', 'text-orange-500')}
        {card('zero', TrendingDown, cards.zero, '0% This Month', 'text-red-600')}
      </div>

      {/* ===== today's report ===== */}
      <section className="rounded-2xl bg-white border border-orange-200 p-4 space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h2 className="flex items-center gap-2 text-base font-bold"><CalendarDays className="w-5 h-5" />Today ka Report — {fmtLong(today)}</h2>
          <button onClick={handleRefresh} disabled={refreshing} className="px-3 py-1.5 rounded-lg bg-orange-100 border border-orange-200 text-xs flex items-center gap-1.5 hover:bg-orange-200">
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />Refresh
          </button>
        </div>

        <div className="grid sm:grid-cols-2 gap-3">
          <div className="rounded-xl border border-green-200 bg-green-50 py-2 text-center">
            <div className="text-2xl font-extrabold text-green-600">{todayReport.present}</div>
            <div className="text-xs">Total Present</div>
          </div>
          <div className="rounded-xl border border-red-200 bg-red-50 py-2 text-center">
            <div className="text-2xl font-extrabold text-red-600">{todayReport.absent}</div>
            <div className="text-xs">Total Absent</div>
          </div>
        </div>

        {!todayReport.hasData ? (
          <p className="text-center text-gray-700 py-6 text-sm flex items-center justify-center gap-2">
            <Inbox className="w-4 h-4" />Aaj ki attendance abhi tak mark nahi hui hai. Attendance mark hone ke baad batch-wise report yahan dikhayi degi.
          </p>
        ) : (
          <div className="space-y-3">
            {todayReport.batches.map((b) => (
              <BatchReportCard key={b.key} data={b} date={today} duesMap={duesMap} variant="today" onRemind={sendAbsentMessage} />
            ))}
          </div>
        )}
      </section>

      {/* ===== student report search ===== */}
      <section className="rounded-2xl bg-white border border-orange-200 p-4 space-y-2">
        <h2 className="flex items-center gap-2 text-base font-bold"><Search className="w-5 h-5" />Student Report Search</h2>
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Name, Reg No, Phone..."
            className="pl-9 h-9 rounded-xl text-sm bg-orange-50 border-orange-200"
          />
        </div>
        <Select value={monthFilter} onValueChange={setMonthFilter}>
          <SelectTrigger className="h-9 rounded-xl text-sm bg-orange-50 border-orange-200"><SelectValue placeholder="Sabhi Months" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Sabhi Months</SelectItem>
            {monthOptions.map((m) => {
              const [y, mo] = m.split('-').map(Number);
              return <SelectItem key={m} value={m}>{MONTH_NAMES[mo - 1]} {y}</SelectItem>;
            })}
          </SelectContent>
        </Select>

        {showList && (
          <div className="pt-2">
            <p className="text-sm text-gray-600 mb-2">{listRows.length} student{listRows.length === 1 ? '' : 's'}</p>
            <div className="divide-y divide-orange-100 rounded-2xl border border-orange-100 overflow-hidden">
              {listRows.slice(0, visibleCount).map(({ s, shown, dues }) => {
                const pct = shown.percent;
                const color = shown.total === 0 ? 'bg-gray-100 text-gray-600' : pct >= GOOD_PERCENT ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600';
                const reg = String(s.regNo);
                const open = listRows.length === 1 || openRegs.has(reg);
                const history = open ? historyOf(s) : [];
                return (
                  <div key={s.regNo}>
                    <button
                      type="button"
                      onClick={() => setOpenRegs((p) => { const n = new Set(p); if (n.has(reg)) n.delete(reg); else n.add(reg); return n; })}
                      className="w-full text-left px-4 py-3 hover:bg-orange-50/50"
                    >
                      <div className="flex items-start justify-between gap-3 flex-wrap">
                        <div>
                          <div className="font-semibold">{s.name}{isExpired(s, today) && <ExpiredTag />}</div>
                          <div className="text-sm text-gray-600">{s.regNo} • {s.mobile || 'N/A'} • {s.batchTime || 'No Batch'}<DuesTag dues={dues} /></div>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-sm font-semibold whitespace-nowrap ${color}`}>{pct}% — {monthFilterLabel}</span>
                      </div>
                      <div className="mt-2 flex items-center gap-4 flex-wrap text-sm">
                        <span className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4 text-green-600" />Present: <b>{shown.present}</b></span>
                        <span className="flex items-center gap-1"><XCircle className="w-4 h-4 text-red-500" />Absent: <b>{shown.total - shown.present}</b></span>
                        <span className="flex items-center gap-1"><CalendarDays className="w-4 h-4" />Expiry: <b>{s.expiryDate ? fmtSlash(String(s.expiryDate).slice(0, 10)) : '—'}</b></span>
                      </div>
                    </button>
                    {open && (
                      <div className="border-t border-orange-100 max-h-72 overflow-y-auto">
                        {history.length === 0 && <p className="px-4 py-4 text-sm text-gray-500">{monthFilterLabel} me abhi koi class ka record nahi hai.</p>}
                        {history.map((h) => (
                          <div key={h.date} className="px-4 py-2.5 flex items-center justify-between border-b border-orange-100/70 last:border-b-0">
                            <span className="text-sm">{fmtSlash(h.date)}</span>
                            <span className={`text-xs font-semibold px-3 py-1 rounded-full ${h.present ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'}`}>{h.present ? 'present' : 'absent'}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
              {listRows.length === 0 && <p className="p-6 text-center text-gray-500 text-sm">Koi student nahi mila.</p>}
            </div>
            {listRows.length > visibleCount && (
              <button onClick={() => setVisibleCount((c) => c + 50)} className="mt-3 w-full py-2 rounded-xl bg-orange-100 border border-orange-200 text-sm hover:bg-orange-200">
                Aur dikhayein ({listRows.length - visibleCount} baaki)
              </button>
            )}
          </div>
        )}
      </section>

      {/* ===== calendar ===== */}
      <section className="rounded-2xl bg-white border border-orange-200 p-4 space-y-3">
        <h2 className="flex items-center gap-2 text-base font-bold"><CalendarDays className="w-5 h-5" />Calendar — Date Select Karein</h2>

        <Select value={calLocation} onValueChange={setCalLocation}>
          <SelectTrigger className="h-9 rounded-xl text-sm bg-orange-50 border-orange-200"><SelectValue placeholder="Sabhi Locations" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Sabhi Locations</SelectItem>
            {calLocations.map((l: any) => <SelectItem key={l.name} value={l.name}>{l.name}</SelectItem>)}
          </SelectContent>
        </Select>

        <div className="flex items-center justify-between">
          <button onClick={() => shiftMonth(-1)} className="px-3 py-1.5 rounded-xl bg-orange-100 border border-orange-200 text-sm flex items-center gap-1 hover:bg-orange-200"><ChevronLeft className="w-4 h-4" />Pehle</button>
          <div className="font-semibold">{MONTH_NAMES[calMonth]} {calYear}</div>
          <button onClick={() => shiftMonth(1)} className="px-3 py-1.5 rounded-xl bg-orange-100 border border-orange-200 text-sm flex items-center gap-1 hover:bg-orange-200">Agle<ChevronRight className="w-4 h-4" /></button>
        </div>

        <div className="grid grid-cols-7 text-center text-sm">
          {WEEK_HEAD.map((w) => <div key={w} className="font-semibold py-2">{w}</div>)}
          {cells.map((day, i) => {
            if (day === null) return <div key={`e${i}`} />;
            const ymd = toYMD(calYear, calMonth, day);
            const isFuture = ymd > today;
            const isToday = ymd === today;
            const isSelected = ymd === selectedDate;
            const hasData = classDays.includes(ymd);
            return (
              <button
                key={ymd}
                disabled={isFuture}
                onClick={() => setSelectedDate(ymd)}
                className={`relative mx-1 my-0.5 py-1.5 rounded-lg text-sm transition-colors ${
                  isSelected ? 'bg-orange-600 text-white'
                    : isToday ? 'bg-pink-100 text-orange-600 font-bold'
                    : isFuture ? 'text-gray-300 cursor-not-allowed'
                    : 'hover:bg-orange-100'
                }`}
              >
                {day}
                {hasData && <span className={`absolute left-1/2 -translate-x-1/2 bottom-1 w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-green-300' : 'bg-green-600'}`} />}
              </button>
            );
          })}
        </div>

        {selectedDate && selectedReport && (
          <div className="pt-2 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3 className="font-bold">{fmtSlash(selectedDate)} ka Report</h3>
              <div className="flex items-center gap-4 text-sm font-semibold">
                <span className="text-green-600 flex items-center gap-1"><CheckCircle2 className="w-4 h-4" />{selectedReport.present} Present</span>
                <span className="text-red-600 flex items-center gap-1"><XCircle className="w-4 h-4" />{selectedReport.absent} Absent</span>
              </div>
            </div>
            {!selectedReport.hasData ? (
              <p className="text-center text-gray-600 py-8 flex items-center justify-center gap-2">
                <Inbox className="w-4 h-4" />{daily[selectedDate] !== undefined ? 'Is date ki attendance mark nahi hui thi.' : 'Report load ho rahi hai...'}
              </p>
            ) : (
              selectedReport.batches.map((b) => (
                <BatchReportCard key={b.key} data={b} date={selectedDate} duesMap={duesMap} variant="history" />
              ))
            )}
          </div>
        )}
      </section>

      {/* ===== stat card popups ===== */}
      <Dialog open={openCard !== null} onOpenChange={(o) => { if (!o) setOpenCard(null); }}>
        <DialogContent className="sm:max-w-3xl max-h-[88vh] overflow-y-auto rounded-2xl">
          {openCard === 'all' && (
            <>
              <DialogHeader><DialogTitle className="flex items-center gap-2"><Users className="w-5 h-5" />Sabhi Students ({rows.length})</DialogTitle></DialogHeader>
              <PopupTable
                head={['Name', 'Reg No', 'Phone', 'Adm Dues', 'Monthly Dues', 'Expiry']}
                empty="Koi student nahi hai."
                rows={rows.map(({ s, dues }) => [
                  s.name, s.regNo, s.mobile || '—',
                  dues.admission > 0 ? <span className="text-orange-500 font-semibold">{money(dues.admission)}</span> : '—',
                  dues.monthly > 0 ? <span className="text-orange-500 font-semibold">{money(dues.monthly)}</span> : '—',
                  <span className={isExpired(s, today) ? 'text-red-600' : 'text-green-600'}>{s.expiryDate ? fmtSlash(String(s.expiryDate).slice(0, 10)) : '—'}</span>,
                ])}
              />
            </>
          )}

          {(openCard === 'good' || openCard === 'poor') && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {openCard === 'good' ? <Trophy className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
                  {openCard === 'good' ? `Good Attendance (${GOOD_PERCENT}%+)` : `Poor Attendance (<${GOOD_PERCENT}%)`} — {(openCard === 'good' ? goodRows : poorRows).length}
                </DialogTitle>
              </DialogHeader>
              <p className="text-xs text-gray-500 -mt-2">Is mahine ({MONTH_NAMES[Number(thisMonthPrefix.slice(5)) - 1]} {thisMonthPrefix.slice(0, 4)}) ki attendance ke hisaab se.</p>
              <PopupTable
                head={['Name', 'Reg No', 'Phone', '%']}
                empty="Koi student nahi hai."
                rows={(openCard === 'good' ? goodRows : poorRows).map(({ s, month }) => [
                  s.name, s.regNo, s.mobile || '—',
                  <span className={`font-bold ${month.percent >= GOOD_PERCENT ? 'text-green-600' : 'text-red-600'}`}>{month.percent}%</span>,
                ])}
              />
            </>
          )}

          {openCard === 'flexi' && (
            <>
              <DialogHeader><DialogTitle className="flex items-center gap-2"><Ticket className="w-5 h-5" />Flexi/Session Students ({flexiRows.length})</DialogTitle></DialogHeader>
              <PopupTable
                head={['Name', 'Reg No', 'Batch', 'Total', 'Li Hui', 'Baaki', 'Expiry']}
                empty="Koi flexi student nahi hai. Attendance → student ke saamne 'Flexi' button se classes add karein."
                rows={flexiRows.map(({ s }) => {
                  const u = flexiUsage[String(s.regNo).toLowerCase()];
                  const expired = isExpired(s, today);
                  return [
                    <b>{s.name}</b>, s.regNo, s.batchTime || 'No Batch',
                    u ? u.total : '—',
                    u ? <span className="font-bold text-orange-600">{u.taken}</span> : '—',
                    u ? (
                      <span className={`font-bold flex items-center gap-1 ${u.left > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {u.left}
                        {u.left > 0 ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                        {u.extra > 0 && <span className="ml-1 text-[11px] font-semibold text-red-600">({u.extra} extra class{u.extra === 1 ? '' : 'es'})</span>}
                      </span>
                    ) : '—',
                    <span className={`flex items-center gap-1 ${expired ? 'text-red-600' : 'text-green-600'}`}>
                      {expired && <AlertTriangle className="w-3.5 h-3.5" />}
                      {s.expiryDate ? fmtSlash(String(s.expiryDate).slice(0, 10)) : '—'}
                    </span>,
                  ];
                })}
              />
            </>
          )}

          {openCard === 'dues' && (
            <>
              <DialogHeader><DialogTitle className="flex items-center gap-2"><Wallet className="w-5 h-5" />Total Dues — ₹{cards.dues.toLocaleString('en-IN')}</DialogTitle></DialogHeader>
              <h3 className="text-orange-600 font-bold">Admission Dues ({admDuesRows.length})</h3>
              <PopupTable
                head={['Name', 'Reg No', 'Dues']}
                empty="Koi admission dues nahi hai."
                rows={admDuesRows.map(({ s, dues }) => [s.name, s.regNo, <span className="text-orange-500 font-semibold">{money(dues.admission)}</span>])}
              />
              <h3 className="text-orange-600 font-bold mt-2">Monthly Dues ({monDuesRows.length})</h3>
              <PopupTable
                head={['Name', 'Reg No', 'Dues']}
                empty="Koi monthly dues nahi hai."
                rows={monDuesRows.map(({ s, dues }) => [s.name, s.regNo, <span className="text-orange-500 font-semibold">{money(dues.monthly)}</span>])}
              />
            </>
          )}

          {openCard === 'zero' && (
            <>
              <DialogHeader><DialogTitle className="flex items-center gap-2"><TrendingDown className="w-5 h-5" />0% Attendance — Nahi Aaye Students</DialogTitle></DialogHeader>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <p className="text-xs text-gray-600 mb-1">Year</p>
                  <Select
                    value={zeroYear}
                    onValueChange={(y) => {
                      setZeroYear(y);
                      const ch = monthOptions.filter((m) => m.startsWith(y)).map((m) => m.slice(5));
                      if (zeroMon !== 'all' && !ch.includes(zeroMon)) setZeroMon(ch[0] || 'all');
                    }}
                    disabled={zeroDays !== 'all'}
                  >
                    <SelectTrigger className="h-9 rounded-xl text-sm bg-orange-50 border-orange-200"><SelectValue /></SelectTrigger>
                    <SelectContent>{yearOptions.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <p className="text-xs text-gray-600 mb-1">Month</p>
                  <Select value={zeroMon} onValueChange={setZeroMon} disabled={zeroDays !== 'all'}>
                    <SelectTrigger className="h-9 rounded-xl text-sm bg-orange-50 border-orange-200"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Poora saal</SelectItem>
                      {zeroMonthChoices.map((m) => <SelectItem key={m} value={m}>{MONTH_NAMES[Number(m) - 1]}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <p className="text-xs text-gray-600 mb-1">Days</p>
                  <Select value={zeroDays} onValueChange={(v) => setZeroDays(v as 'all' | '7' | '15' | '30')}>
                    <SelectTrigger className="h-9 rounded-xl text-sm bg-orange-50 border-orange-200"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Month / Year ke hisaab se</SelectItem>
                      <SelectItem value="7">Pichhle 7 din</SelectItem>
                      <SelectItem value="15">Pichhle 15 din</SelectItem>
                      <SelectItem value="30">Pichhle 30 din</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              {monthLoading ? (
                <p className="text-sm text-gray-600 py-6 text-center flex items-center justify-center gap-2">
                  <RefreshCw className="w-4 h-4 animate-spin" />{zeroPeriod.label} ki attendance load ho rahi hai...
                </p>
              ) : (<>
              <div className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-600 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span><b>{zeroRows.length} students</b> ne <b>{zeroPeriod.label}</b> mein ek bhi class nahi li.</span>
              </div>
              {!zeroHasData && (
                <p className="text-xs text-gray-500">Note: {zeroPeriod.label} me abhi tak koi attendance mark nahi hui hai, isliye sab 0% dikh rahe hain.</p>
              )}
              <PopupTable
                head={['Name', 'Reg No', 'Batch', 'Phone', 'WhatsApp']}
                empty="Sabhi students ne is period me class li hai."
                rows={zeroRows.map((s) => [
                  <b>{s.name}</b>, s.regNo, s.batchTime || 'No Batch', s.mobile || '—',
                  <button onClick={() => sendZeroMessage(s)} className="px-3 py-1.5 rounded-lg bg-green-500 hover:bg-green-600 text-white text-sm flex items-center gap-1.5">
                    <Send className="w-4 h-4" /><span className="underline">Message</span>
                  </button>,
                ])}
              />
              </>)}
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
