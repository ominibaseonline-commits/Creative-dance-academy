import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { toast } from 'sonner';
import { Shield, Key, Lock, FileText, AlertTriangle } from 'lucide-react';
import { saveLicenseKey } from '../lib/indexedDB';
import { LicenseKey } from '../lib/licenseKey';

interface LicenseActivationProps {
  onActivated: () => void;
}

export function LicenseActivation({ onActivated }: LicenseActivationProps) {
  const [licenseKey, setLicenseKey] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [activating, setActivating] = useState(false);

  const handleActivateLicense = async () => {
    if (!licenseKey.trim()) {
      toast.error('Please enter license key');
      return;
    }

    if (!expiryDate) {
      toast.error('Please enter expiry date');
      return;
    }

    const expiry = new Date(expiryDate);
    const today = new Date();

    if (expiry <= today) {
      toast.error('Expiry date must be in the future');
      return;
    }

    // Validate license key format (MDA-XXXXXXXX-XXXXXXXX)
    const licensePattern = /^MDA-[A-Z0-9]{8,}-[A-Z0-9]{8,}$/i;
    if (!licensePattern.test(licenseKey.trim())) {
      toast.error('Invalid license key format! Format: MDA-XXXXXXXX-XXXXXXXX');
      return;
    }

    setActivating(true);
    try {
      const newLicense: LicenseKey = {
        key: licenseKey.trim().toUpperCase(),
        expiryDate: expiryDate,
        isActive: true,
        createdDate: new Date().toISOString()
      };

      await saveLicenseKey(newLicense);

      const daysRemaining = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

      toast.success(`License activated successfully! Valid for ${daysRemaining} days.`, {
        duration: 5000
      });

      // Reload page to apply license
      setTimeout(() => {
        window.location.reload();
      }, 1500);

    } catch (error) {
      console.error('Error activating license:', error);
      toast.error('Failed to activate license');
    } finally {
      setActivating(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: 'var(--app-bg)' }}>
      <div className="max-w-md w-full">
        <div className="text-center mb-8 p-6 rounded-lg" style={{ backgroundColor: 'var(--brand)' }}>
          <div className="flex items-center justify-center gap-3 mb-2">
            <Shield className="w-8 h-8 text-white" />
            <h1 className="text-white text-2xl">License Activation</h1>
          </div>
          <p className="text-white text-sm">Activate your system license</p>
        </div>

        <Card className="p-6 shadow-xl border-2 border-orange-300">
          <div className="text-center mb-6">
            <div className="inline-block p-4 bg-orange-100 rounded-full mb-4">
              <Lock className="w-12 h-12 text-orange-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-800 mb-2">System Not Activated</h2>
            <p className="text-gray-600 text-sm">
              Please enter your license key to activate the system
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <Label htmlFor="license-key" className="flex items-center gap-2 mb-2">
                <Key className="w-4 h-4" />
                License Key
              </Label>
              <Input
                id="license-key"
                type="text"
                value={licenseKey}
                onChange={(e) => setLicenseKey(e.target.value.toUpperCase())}
                placeholder="MDA-XXXXXXXX-XXXXXXXX"
                className="font-mono text-center text-lg border-orange-300"
                maxLength={50}
              />
              <p className="text-xs text-gray-500 mt-1">
                Format: MDA-XXXXXXXX-XXXXXXXX
              </p>
            </div>

            <div>
              <Label htmlFor="expiry-date" className="mb-2 block">
                License Expiry Date
              </Label>
              <Input
                id="expiry-date"
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                className="border-orange-300"
              />
            </div>

            <Button
              onClick={handleActivateLicense}
              disabled={activating}
              className="w-full bg-orange-600 hover:bg-orange-700 text-lg py-6"
            >
              {activating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Activating...
                </>
              ) : (
                <>
                  <Shield className="w-5 h-5 mr-2" />
                  Activate License
                </>
              )}
            </Button>
          </div>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h3 className="font-semibold text-sm text-blue-900 mb-2 flex items-center gap-1.5"><FileText className="w-4 h-4" /> How to Get License Key:</h3>
            <ol className="text-xs text-blue-800 space-y-1 list-decimal list-inside">
              <li>Contact your system administrator</li>
              <li>Provide your business details</li>
              <li>Receive unique license key via email/WhatsApp</li>
              <li>Enter the key above to activate</li>
            </ol>
          </div>

          <div className="mt-4 p-3 bg-yellow-50 rounded border border-yellow-300">
            <p className="text-xs text-yellow-800 text-center flex items-center justify-center gap-1.5">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" /> <span><strong>Important:</strong> Once activated, the license key cannot be changed by users. Only administrator can manage licenses.</span>
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
