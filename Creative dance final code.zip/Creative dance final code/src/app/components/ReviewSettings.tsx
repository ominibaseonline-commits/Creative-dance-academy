import { useEffect, useState } from 'react';
import { Star, Key, Copy, Download, ExternalLink, AlertTriangle, CheckCircle2, XCircle, Loader2, Plus, X } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Switch } from './ui/switch';
import { qrToDataUrl } from '../lib/qr';
import { isAttendanceConnected } from '../lib/attendance';
import {
  MAX_KEYWORDS,
  checkReviewScript,
  connectGroqKey,
  getReviewPageLink,
  getReviewSettings,
  maskKey,
  removeGroqKey,
  saveReviewDetails,
  setReviewEnabled,
} from '../lib/review';

// Settings -> Google Review
// 1) Groq API key (connect hote hi green)   2) Google Review link + keywords   3) QR / link
// Student QR scan karke star + keywords chunta hai, Google Script usi waqt Groq se chhota naya review banati hai
// aur Submit par review copy hoke Google Review link khulta hai. Google Sheet me kuch store nahi hota.
export function ReviewSettings() {
  const [loaded, setLoaded] = useState(false);
  const [connected, setConnected] = useState(true);
  const [enabled, setEnabled] = useState(false);
  const [savedKey, setSavedKey] = useState('');
  const [keyOk, setKeyOk] = useState(false);
  const [editingKey, setEditingKey] = useState(false);
  const [keyInput, setKeyInput] = useState('');
  const [keyError, setKeyError] = useState('');
  const [linkInput, setLinkInput] = useState('');
  const [keywords, setKeywords] = useState<string[]>([]);
  const [kwValue, setKwValue] = useState('');
  const [savedLink, setSavedLink] = useState('');
  const [pageLink, setPageLink] = useState('');
  const [qr, setQr] = useState('');
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState('');

  const load = async () => {
    const [s, conn, pl] = await Promise.all([getReviewSettings(), isAttendanceConnected(), getReviewPageLink()]);
    setEnabled(s.enabled);
    setSavedKey(s.groqKey);
    setKeyOk(s.keyOk);
    setEditingKey(!s.groqKey);
    setLinkInput(s.link);
    setSavedLink(s.link);
    setKeywords(s.keywords);
    setConnected(conn);
    setPageLink(pl);
    setQr(pl ? qrToDataUrl(pl, 700) : '');
    setLoaded(true);
    // Script me key nahi hai (naya Sheet / deploy) to CMS wali key wapas bhej deta hai
    if (conn && s.keyOk) {
      const st = await checkReviewScript();
      if (st.error) setProblem(st.error);
      else if (!st.hasKey) setKeyOk(false);
    }
  };

  useEffect(() => { load(); }, []);

  const connectKey = async () => {
    if (!keyInput.trim()) { setKeyError('Pehle Groq API key paste karein.'); return; }
    setBusy(true); setKeyError(''); setProblem('');
    const r = await connectGroqKey(keyInput);
    setBusy(false);
    if (r.ok) {
      setSavedKey(keyInput.trim()); setKeyOk(true); setEditingKey(false); setKeyInput('');
      toast.success('Groq connect ho gaya');
    } else {
      setKeyError(r.error || 'Connect nahi hua');
      toast.error('Groq connect nahi hua');
    }
  };

  const removeKey = async () => {
    if (!window.confirm('Groq key hata dein? Key hatane par review AI se nahi banenge (sirf simple backup review dikhega).')) return;
    setBusy(true);
    const r = await removeGroqKey();
    setBusy(false);
    setSavedKey(''); setKeyOk(false); setEditingKey(true); setKeyInput(''); setKeyError('');
    if (r.error) { setProblem(r.error); toast.error('CMS se hat gayi, par Script se abhi nahi hati'); }
    else toast.success('Groq key hat gayi');
  };

  const saveLink = async () => {
    setBusy(true); setProblem('');
    const r = await saveReviewDetails(linkInput, keywords);
    setBusy(false);
    if (r.ok) { setSavedLink(linkInput.trim()); toast.success('Google Review link save ho gaya'); }
    else if (linkInput.trim() && !/^https:\/\//i.test(linkInput.trim())) { setProblem(r.error || ''); toast.error('Link galat hai'); }
    else { setSavedLink(linkInput.trim()); setProblem(r.error || ''); toast.error('CMS me save hua, par Google Script ko abhi nahi bataya ja saka'); }
  };

  // Keywords turant save hote hain (Query Source ki tarah): box me likho, Add / Enter dabao, chip ban jata hai
  const persistKeywords = async (list: string[]) => {
    setKeywords(list);
    const r = await saveReviewDetails(savedLink, list);
    if (!r.ok) { setProblem(r.error || ''); toast.error('CMS me save hua, par Google Script ko abhi nahi bataya ja saka'); }
    else setProblem('');
  };

  const addKeyword = async () => {
    const v = kwValue.replace(/\s+/g, ' ').trim().slice(0, 40);
    if (!v) return;
    if (keywords.some((k) => k.toLowerCase() === v.toLowerCase())) { toast.error(`"${v}" pehle se list me hai!`); return; }
    if (keywords.length >= MAX_KEYWORDS) { toast.error(`Max ${MAX_KEYWORDS} keywords hi add ho sakte hain`); return; }
    setKwValue('');
    await persistKeywords([...keywords, v]);
    toast.success(`"${v}" add ho gaya`);
  };

  const removeKeyword = async (k: string) => {
    await persistKeywords(keywords.filter((x) => x !== k));
    toast.success(`"${k}" hata diya`);
  };

  const toggle = async (on: boolean) => {
    if (on && !savedLink) { toast.error('Pehle Google Review link save karein'); return; }
    setBusy(true); setEnabled(on);
    const r = await setReviewEnabled(on);
    setBusy(false);
    if (r.ok) { setProblem(''); toast.success(on ? 'Google Review ON ho gaya' : 'Google Review OFF ho gaya'); }
    else { setProblem(r.error || ''); toast.error(on ? 'ON ho gaya, par Google Script ko abhi nahi bataya ja saka' : 'OFF ho gaya, par Google Script ko abhi nahi bataya ja saka'); }
  };

  const copyLink = async () => {
    try { await navigator.clipboard.writeText(pageLink); toast.success('Link copy ho gaya'); }
    catch { toast.error('Copy nahi hua'); }
  };

  const downloadQr = () => {
    const a = document.createElement('a');
    a.href = qr; a.download = 'qr-google-review.png'; a.click();
  };

  if (!loaded) return null;

  const showQr = connected && keyOk && !!savedLink && !!pageLink;

  return (
    <div className="bg-white rounded-lg border p-4 space-y-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h4 className="flex items-center gap-2"><Star className="w-5 h-5 text-orange-600" /> Google Review</h4>
          <p className="text-sm text-gray-500 mt-1">
            {enabled
              ? 'ON — student QR scan karke star aur keywords chunta hai, review apne aap ban jata hai, aur Submit par Google Review page khulta hai.'
              : 'OFF — review page band hai (QR scan karne par "band hai" dikhega).'}
          </p>
        </div>
        <Switch checked={enabled} onCheckedChange={toggle} disabled={busy} />
      </div>

      {!connected && (
        <div className="flex gap-2 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>Setup: <strong>Settings → Management & Setup → Attendance Setup</strong> me system connect karein. Isi se sabhi modules chalte hain: Events, QR Enquiry, Online Admission, Attendance.</span>
        </div>
      )}

      {problem && (
        <div className="flex gap-2 rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{problem}</span>
        </div>
      )}

      {/* 1) Groq key */}
      <div className="space-y-3 border-t pt-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <p className="flex items-center gap-2 text-sm font-medium"><Key className="w-4 h-4" /> 1. Groq API key</p>
          {keyOk ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-green-100 text-green-800 text-xs font-semibold px-2.5 py-1"><CheckCircle2 className="w-3.5 h-3.5" /> Connected</span>
          ) : savedKey ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-red-100 text-red-800 text-xs font-semibold px-2.5 py-1"><XCircle className="w-3.5 h-3.5" /> Connect nahi hua</span>
          ) : (
            <span className="inline-flex items-center gap-1 rounded-full bg-gray-100 text-gray-600 text-xs font-semibold px-2.5 py-1">Key add nahi hui</span>
          )}
        </div>

        {editingKey ? (
          <div className="space-y-2">
            <div className="flex gap-2">
              <Input
                type="password"
                value={keyInput}
                onChange={(e) => { setKeyInput(e.target.value); setKeyError(''); }}
                placeholder="gsk_..."
                autoComplete="off"
                disabled={busy}
              />
              <Button onClick={connectKey} disabled={busy || !connected}>
                {busy ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : null} Connect
              </Button>
              {savedKey && <Button variant="outline" onClick={() => { setEditingKey(false); setKeyInput(''); setKeyError(''); }} disabled={busy}>Cancel</Button>}
            </div>
            {keyError && <p className="text-sm text-red-600">{keyError}</p>}
            <p className="text-xs text-gray-500">Key <strong>console.groq.com</strong> se free me banti hai. Key sirf CMS aur aapke Google Script me rehti hai, student ko kabhi nahi dikhti.</p>
          </div>
        ) : (
          <div className="flex items-center gap-2 flex-wrap">
            <div className="text-xs font-mono rounded-md bg-gray-50 border px-2 py-1.5">{maskKey(savedKey)}</div>
            <Button size="sm" variant="outline" onClick={() => { setEditingKey(true); setKeyError(''); }} disabled={busy}>Key badlein</Button>
            <Button size="sm" variant="outline" onClick={removeKey} disabled={busy}>Hatayein</Button>
            {!keyOk && <Button size="sm" onClick={async () => { setBusy(true); const r = await connectGroqKey(savedKey); setBusy(false); if (r.ok) { setKeyOk(true); setKeyError(''); toast.success('Groq connect ho gaya'); } else setKeyError(r.error || 'Connect nahi hua'); }} disabled={busy}>Dobara connect</Button>}
          </div>
        )}
        {!editingKey && keyError && <p className="text-sm text-red-600">{keyError}</p>}
      </div>

      {/* 2) Link + keywords */}
      <div className="space-y-3 border-t pt-4">
        <p className="text-sm font-medium">2. Google Review link aur keywords</p>
        <div className="space-y-1">
          <label className="text-xs text-gray-600">Google Review link</label>
          <Input value={linkInput} onChange={(e) => setLinkInput(e.target.value)} placeholder="https://g.page/r/.../review" disabled={busy} />
          <p className="text-xs text-gray-500">Google Business Profile → "Get more reviews" se jo link milta hai wo yahan daalein.</p>
        </div>
        <Button size="sm" onClick={saveLink} disabled={busy || !connected}>Link save karein</Button>

        <div className="space-y-2 pt-2">
          <label className="text-xs text-gray-600">Keywords (max {MAX_KEYWORDS})</label>
          <div className="flex gap-2">
            <Input
              value={kwValue}
              placeholder="e.g. Dance, Zumba, Friendly trainers..."
              onChange={(e) => setKwValue(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addKeyword(); } }}
            />
            <Button onClick={addKeyword} className="bg-orange-500 hover:bg-orange-600 text-white whitespace-nowrap">
              <Plus className="w-4 h-4 mr-1" /> Add
            </Button>
          </div>
          {keywords.length === 0 ? (
            <p className="text-sm text-gray-500">Abhi koi keyword nahi hai. Upar se add karein.</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {keywords.map((k) => (
                <span key={k} className="inline-flex items-center gap-1.5 bg-orange-50 border border-orange-200 text-orange-800 rounded-full pl-3 pr-1.5 py-1 text-sm">
                  {k}
                  <button type="button" onClick={() => removeKeyword(k)} title="Delete" className="rounded-full hover:bg-orange-200 p-0.5">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </span>
              ))}
            </div>
          )}
          <p className="text-xs text-gray-500">Student inme se apne hisaab se chunta hai, aur review usi ke hisaab se banta hai.</p>
        </div>
      </div>

      {/* 3) QR + link */}
      {showQr ? (
        <div className="space-y-3 border-t pt-4">
          <p className="flex items-center gap-2 text-sm font-medium"><CheckCircle2 className="w-4 h-4 text-green-600" /> 3. Ye QR / link office me lagayein</p>
          <div className="flex flex-col md:flex-row gap-4 items-start">
            {qr && <img src={qr} alt="Google Review QR" className="w-44 h-44 border rounded-lg" />}
            <div className="flex-1 min-w-0 space-y-3">
              <div className="text-xs font-mono break-all rounded-md bg-gray-50 border p-2">{pageLink}</div>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={copyLink}><Copy className="w-4 h-4 mr-1" /> Link copy</Button>
                <Button size="sm" variant="outline" onClick={downloadQr}><Download className="w-4 h-4 mr-1" /> QR download</Button>
                <Button size="sm" variant="outline" onClick={() => window.open(pageLink, '_blank')}><ExternalLink className="w-4 h-4 mr-1" /> Page dekhein</Button>
              </div>
              <ul className="text-xs text-gray-500 list-disc pl-4 space-y-1">
                {!enabled && <li>Abhi upar ka toggle <strong>OFF</strong> hai, isliye QR scan karne par page band dikhega. ON karein.</li>}
                <li>Student 1 se 5 star me se koi bhi chun sakta hai, aur sab Google Review link par hi jaate hain.</li>
              </ul>
            </div>
          </div>
        </div>
      ) : (
        <p className="text-xs text-gray-500 border-t pt-4">QR aur link tab dikhenge jab Groq key <strong>Connected (green)</strong> ho aur Google Review link save ho jaye.</p>
      )}
    </div>
  );
}
