import { useCallback, useEffect, useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { toast } from 'sonner';
import { AlertTriangle, CheckCircle2, ClipboardCheck, Lock, RefreshCw, Search } from 'lucide-react';
import { getStudentsLite } from '../lib/indexedDB';
import { getBatches } from '../lib/storageAdapter';
import { batchSortKey } from '../lib/batchTime';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import {
  AttendanceConfig,
  AttendanceRecord,
  adminCheckIn,
  adminCheckOut,
  fetchAttendance,
  getAttendanceConfig,
  getCachedAttendance,
  getSubmittedBatches,
  submitBatchAttendance,
} from '../lib/attendance';

const NO_BATCH = '__none__';
const todayStr = () => new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD in local time
const batchKeyOf = (s: any) => (s.batchTime && String(s.batchTime).trim()) || NO_BATCH;
const batchLabel = (k: string) => (k === NO_BATCH ? 'No Batch' : k);

/**
 * Daily Attendance — the admin picks a batch, sees every student of that batch, taps Check In for
 * the ones who came and leaves the rest alone, then submits. Submitting locks the batch in THIS
 * panel only; QR and the staff panel can still mark attendance, and the batch card keeps updating
 * (present / absent counts show only after the batch is submitted).
 */
export function DailyAttendance() {
  const { matchesLocation, selectedLocation } = useLocationFilter();

  const [date, setDate] = useState(todayStr());
  const [students, setStudents] = useState<any[]>([]);
  const [batchInfos, setBatchInfos] = useState<any[]>([]);
  const [config, setConfig] = useState<AttendanceConfig | null>(null);
  const [records, setRecords] = useState<Record<string, AttendanceRecord>>({});
  const [submitted, setSubmitted] = useState<string[]>([]);
  const [batch, setBatch] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [busy, setBusy] = useState<Set<string>>(new Set());
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const connected = !!config?.webAppUrl;

  const loadBase = useCallback(async () => {
    const [all, b] = await Promise.all([getStudentsLite(), getBatches()]);
    setStudents(all.filter((s: any) => !s.deactivated && matchesLocation(s.location)));
    setBatchInfos((b || []).filter((x: any) => !x.location || matchesLocation(x.location)));
  }, [selectedLocation]);

  const loadLocal = useCallback(async () => {
    const local = await getCachedAttendance(date);
    setRecords(local ? local.records : {});
    setSubmitted(await getSubmittedBatches(date));
  }, [date]);

  const refresh = useCallback(async () => {
    setConfig(await getAttendanceConfig());
    await loadLocal();
    try {
      const res = await fetchAttendance(date);
      setRecords(res.records);
    } catch { /* offline: the saved copy stays on screen */ }
  }, [date, loadLocal]);

  useEffect(() => { loadBase().catch(() => toast.error('Data load nahi hua')); }, [loadBase]);
  useEffect(() => {
    const h = () => loadBase();
    window.addEventListener('studentsUpdated', h);
    window.addEventListener('batchesUpdated', h);
    return () => { window.removeEventListener('studentsUpdated', h); window.removeEventListener('batchesUpdated', h); };
  }, [loadBase]);

  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => {
    window.addEventListener('attendanceUpdated', loadLocal);
    return () => window.removeEventListener('attendanceUpdated', loadLocal);
  }, [loadLocal]);
  // Settings -> Check-out option / Expired block changed
  useEffect(() => {
    const h = async () => setConfig(await getAttendanceConfig());
    window.addEventListener('attendanceConfigUpdated', h);
    return () => window.removeEventListener('attendanceConfigUpdated', h);
  }, []);

  // New day while the CMS stays open
  useEffect(() => {
    const t = setInterval(() => { const d = todayStr(); setDate((prev) => (prev === d ? prev : d)); }, 60000);
    return () => clearInterval(t);
  }, []);

  const recOf = (s: any): AttendanceRecord | undefined => records[String(s.regNo).toLowerCase()];

  // Every batch that exists in the CMS (plus any batch a student still carries), morning first
  const batchCards = useMemo(() => {
    const map = new Map<string, { total: number; present: number }>();
    batchInfos.forEach((b: any) => { const k = (b.batchTime && String(b.batchTime).trim()) || ''; if (k) map.set(k, { total: 0, present: 0 }); });
    students.forEach((s) => {
      const k = batchKeyOf(s);
      const e = map.get(k) || { total: 0, present: 0 };
      e.total++;
      if (records[String(s.regNo).toLowerCase()]?.checkIn) e.present++;
      map.set(k, e);
    });
    return Array.from(map.entries())
      .sort((a, b) => batchSortKey(a[0]) - batchSortKey(b[0]) || a[0].localeCompare(b[0]))
      .map(([key, v]) => ({ key, ...v }));
  }, [batchInfos, students, records]);

  const batchStudents = useMemo(() => {
    if (batch === null) return [];
    const q = search.trim().toLowerCase();
    return students
      .filter((s) => batchKeyOf(s) === batch)
      .filter((s) => !q || String(s.name || '').toLowerCase().includes(q) || String(s.regNo).toLowerCase().includes(q) || String(s.mobile || '').includes(q))
      .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
  }, [students, batch, search]);

  const allOfBatch = useMemo(() => (batch === null ? [] : students.filter((s) => batchKeyOf(s) === batch)), [students, batch]);
  const presentCount = allOfBatch.filter((s) => !!recOf(s)?.checkIn).length;
  const absentCount = allOfBatch.length - presentCount;
  const locked = batch !== null && submitted.includes(batch);

  const withBusy = async (reg: string, fn: () => Promise<void>) => {
    setBusy((p) => new Set(p).add(reg));
    try { await fn(); } finally { setBusy((p) => { const n = new Set(p); n.delete(reg); return n; }); }
  };

  const checkIn = (s: any) => withBusy(String(s.regNo), async () => {
    if (!connected) { toast.error('Pehle Settings → Management & Setup me Attendance connect karein'); return; }
    try {
      const r = await adminCheckIn(s.regNo, s.name, batchKeyOf(s));
      if (r.already) toast.info(`${s.name} ki attendance pehle se lagi hui hai (${r.checkIn})`);
      else if (r.pending) toast.warning(`${s.name} present (${r.checkIn}) — yahan save ho gaya, internet aate hi Google par jayega`);
      else if (r.expired) toast.warning(`${s.name} present (${r.checkIn}) — par session EXPIRED hai`);
      else toast.success(`${s.name} present ho gaya (${r.checkIn})`);
    } catch (e: any) {
      toast.error(e?.message || 'Attendance mark nahi hui');
    }
  });

  const checkOut = (s: any) => withBusy(String(s.regNo), async () => {
    try {
      const r = await adminCheckOut(s.regNo, s.name);
      if (r.already) toast.info(`${s.name} ka check-out pehle se ho chuka hai (${r.checkOut})`);
      else if (r.pending) toast.warning(`${s.name} check-out (${r.checkOut}) — yahan save ho gaya, internet aate hi Google par jayega`);
      else toast.success(`${s.name} ka check-out ho gaya (${r.checkOut})`);
    } catch (e: any) {
      toast.error(e?.message || 'Check-out nahi hua');
    }
  });

  const doSubmit = async () => {
    if (batch === null) return;
    setSubmitting(true);
    try {
      const r = await submitBatchAttendance(batch);
      setConfirmOpen(false);
      toast.success(r.pending
        ? `${batchLabel(batch)} submit ho gayi — internet aate hi Google par lock lagega`
        : `${batchLabel(batch)} ki attendance submit ho gayi`);
    } catch (e: any) {
      toast.error(e?.message || 'Submit nahi ho payi');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try { await refresh(); toast.success('Refresh ho gaya'); } finally { setRefreshing(false); }
  };

  return (
    <div className="px-6 pt-3 pb-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <CardTitle className="flex items-center gap-2"><ClipboardCheck className="w-5 h-5 text-orange-600" />Daily Attendance</CardTitle>
              <p className="text-xs text-gray-500 mt-1">
                Batch chunein, jo aaye unke saamne Check In dabayein, baaki ko chhod dein, phir Submit karein.
              </p>
            </div>
            <Button variant="outline" onClick={handleRefresh} disabled={refreshing}>
              <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />Refresh
            </Button>
          </div>

          {!connected && config && (
            <div className="mt-3 p-3 rounded-md bg-yellow-50 border border-yellow-300 text-sm text-yellow-800 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>Attendance is not connected. Go to <b>Settings → Management & Setup → Attendance Setup</b> to connect.</span>
            </div>
          )}
        </CardHeader>

        <CardContent className="space-y-4">
          {/* all batches */}
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {batchCards.length === 0 && <p className="text-sm text-gray-500">Abhi koi batch nahi hai.</p>}
            {batchCards.map((b) => {
              const isLocked = submitted.includes(b.key);
              const selected = batch === b.key;
              return (
                <button
                  key={b.key}
                  onClick={() => { setBatch(b.key); setSearch(''); }}
                  className={`text-left rounded-xl border px-3 py-2.5 transition-colors ${selected ? 'border-orange-500 bg-orange-50 ring-2 ring-orange-200' : 'bg-white hover:bg-orange-50/60'}`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-sm">{batchLabel(b.key)}</span>
                    {isLocked && <span className="flex items-center gap-1 text-[11px] font-semibold text-gray-600 bg-gray-100 rounded-full px-2 py-0.5"><Lock className="w-3 h-3" />Submitted</span>}
                  </div>
                  {isLocked ? (
                    // Submitted: full report. Total in bold black, present green, absent red (keeps updating live)
                    <div className="text-xs mt-1 flex items-center flex-wrap gap-x-1.5">
                      <span className="font-bold text-black">{b.total} students</span>
                      <span className="text-gray-400">•</span>
                      <span className="font-semibold text-green-700">{b.present} present</span>
                      <span className="text-gray-400">•</span>
                      <span className="font-semibold text-red-600">{Math.max(0, b.total - b.present)} absent</span>
                    </div>
                  ) : (
                    <div className="text-xs text-gray-600 mt-1">{b.total} students</div>
                  )}
                </button>
              );
            })}
          </div>

          {/* chosen batch */}
          {batch === null ? (
            <p className="text-center text-sm text-gray-500 py-6">Upar se batch chunein — us batch ke saare students yahan dikhenge.</p>
          ) : (
            <div className="space-y-3 border-t pt-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h3 className="font-bold">{batchLabel(batch)}</h3>
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <span className="px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200">Total: {allOfBatch.length}</span>
                  <span className="px-2.5 py-1 rounded-full bg-green-50 text-green-700 border border-green-200">Present: {presentCount}</span>
                  <span className="px-2.5 py-1 rounded-full bg-red-50 text-red-700 border border-red-200">Absent: {absentCount}</span>
                </div>
              </div>

              {locked && (
                <div className="p-3 rounded-md bg-amber-50 border border-amber-300 text-sm text-amber-800 flex items-start gap-2">
                  <Lock className="w-4 h-4 mt-0.5 shrink-0" />
                  <span>Is batch ki attendance submit ho chuki hai, isliye yahan se ab attendance nahi lagegi. QR ya staff panel se attendance lag sakti hai, aur upar ka present / absent count apne aap update hota rahega.</span>
                </div>
              )}

              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Name, Reg No ya Phone se dhundein..." className="pl-10" />
              </div>

              <div className="space-y-2 max-h-[55vh] overflow-y-auto pr-1">
                {batchStudents.length === 0 && <p className="text-center text-sm text-gray-500 py-6">Is batch me koi student nahi mila.</p>}
                {batchStudents.map((s) => {
                  const r = recOf(s);
                  const isBusy = busy.has(String(s.regNo));
                  return (
                    <div key={s.regNo} className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2">
                      <div className="min-w-0">
                        <div className="font-medium truncate">{s.name}</div>
                        <div className="text-xs text-gray-500">Reg No: {s.regNo}{s.mobile ? ` • ${s.mobile}` : ''}</div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {r?.checkIn ? (
                          <span className="flex items-center gap-1 text-sm font-semibold text-green-700 bg-green-100 rounded-lg px-2.5 py-1">
                            <CheckCircle2 className="w-4 h-4" />{r.checkIn}
                          </span>
                        ) : locked ? null : (
                          <Button size="sm" className="bg-orange-500 hover:bg-orange-600 text-white" disabled={isBusy} onClick={() => checkIn(s)}>
                            Check In
                          </Button>
                        )}
                        {config?.enableCheckout && r?.checkIn && (
                          r.checkOut
                            ? <span className="text-xs font-semibold text-purple-700 bg-purple-100 rounded-lg px-2 py-1">Out: {r.checkOut}</span>
                            : <Button size="sm" variant="outline" disabled={isBusy} onClick={() => checkOut(s)}>Check Out</Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              <Button
                onClick={() => setConfirmOpen(true)}
                disabled={locked || allOfBatch.length === 0 || !connected}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
              >
                <ClipboardCheck className="w-4 h-4 mr-2" />
                {locked ? 'Attendance Submit Ho Chuki Hai' : 'Attendance Submit Karein'}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Attendance submit karein?</DialogTitle></DialogHeader>
          {batch !== null && (
            <div className="space-y-3">
              <p className="text-sm text-gray-700">
                <b>{batchLabel(batch)}</b> — <span className="text-green-700 font-semibold">{presentCount} present</span>,{' '}
                <span className="text-red-600 font-semibold">{absentCount} absent</span>.
              </p>
              <p className="text-xs text-gray-500">Jinka Check In nahi hua wo absent maane jayenge. Submit ke baad is panel se attendance nahi lagegi; QR aur staff panel se lagti rahegi aur count update hota rahega.</p>
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={() => setConfirmOpen(false)}>Cancel</Button>
                <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white" onClick={doSubmit} disabled={submitting}>
                  {submitting ? 'Please wait...' : 'Haan, Submit'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
