import { useEffect, useState } from 'react';
import { CalendarDays, AlertTriangle, CheckCircle2, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { isAttendanceConnected } from '../lib/attendance';
import { getEventFormsEnabled } from '../events/lib/eventsDb';
import { eventsError, getRelayStatus, pushEventsConfig, setEventFormsEnabled, type RelayStatus } from '../events/lib/eventSync';

// Settings -> Event Forms: ek toggle. ON karte hi sidebar me "Events" section aa jata hai (form builder, public link,
// registrations). Baaki saari event setting Events section ke andar hi hai.
// OFF karne par sirf section chhupta hai aur public links band hote hain - event ka koi data delete nahi hota.
export function EventFormsSettings() {
  const [enabled, setEnabled] = useState(false);
  const [connected, setConnected] = useState(true);
  const [status, setStatus] = useState<RelayStatus | 'checking'>('checking');
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState('');
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    Promise.all([getEventFormsEnabled(), isAttendanceConnected()]).then(([on, conn]) => {
      setEnabled(on); setConnected(conn); setLoaded(true);
      if (conn) getRelayStatus().then(setStatus);
    });
  }, []);

  const toggle = async (on: boolean) => {
    setBusy(true);
    setEnabled(on);
    const r = await setEventFormsEnabled(on);
    setBusy(false);
    if (r.error) {
      setProblem(r.error);
      toast.error(on ? 'Event Forms ON ho gaya, par Google Sheet ko abhi nahi bataya ja saka' : 'OFF ho gaya, par Google Sheet ko abhi nahi bataya ja saka');
    } else {
      setProblem('');
      toast.success(on ? 'Event Forms ON ho gaya. Sidebar me Events aa gaya.' : 'Event Forms OFF ho gaya. Data safe hai, sirf hide hua hai.');
    }
    if (connected) getRelayStatus().then(setStatus);
  };

  const resync = async () => {
    setBusy(true);
    try {
      await pushEventsConfig(true);
      setProblem('');
      toast.success('Saare event forms Google Sheet me update ho gaye');
    } catch (e: any) {
      setProblem(eventsError(e));
      toast.error('Update nahi hua');
    } finally { setBusy(false); }
  };

  if (!loaded) return null;

  return (
    <div className="bg-white rounded-lg border p-4 space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h4 className="flex items-center gap-2"><CalendarDays className="w-5 h-5 text-orange-600" /> Event Forms</h4>
          <p className="text-sm text-gray-500 mt-1">
            {enabled
              ? 'ON — sidebar me Events section hai. Event banao, link / QR share karo; registration turant CMS me aati hai.'
              : 'OFF — Events section hide hai aur sab public event links band hain. Pehle ka koi data delete nahi hota.'}
          </p>
        </div>
        <Switch checked={enabled} onCheckedChange={toggle} disabled={busy} />
      </div>

      {!connected && (
        <div className="flex gap-2 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>Setup: <strong>Settings → Management & Setup → Attendance Setup</strong> me system connect karein. Isi se sabhi modules chalte hain: Events, QR Enquiry, Online Admission, Attendance.</span>
        </div>
      )}

      {connected && status === 'script_old' && (
        <div className="flex gap-2 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>Aapki Google Script me Events ka hissa nahi hai. <strong>Attendance Setup</strong> se naya code copy karke Apps Script me paste karein, phir <strong>Deploy → Manage deployments → Edit → New version</strong> karein.</span>
        </div>
      )}

      {problem && (
        <div className="flex gap-2 rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{problem}</span>
        </div>
      )}

      {enabled && connected && status === 'ok' && (
        <div className="space-y-3 border-t pt-4">
          <p className="flex items-center gap-2 text-sm font-medium"><CheckCircle2 className="w-4 h-4 text-green-600" /> Google Script connected hai</p>
          <ul className="text-xs text-gray-500 list-disc pl-4 space-y-1">
            <li>Har event ka alag link hota hai (Events → Events History → Copy link). Wo link / uska QR students ko do.</li>
          </ul>
          <Button size="sm" variant="outline" onClick={resync} disabled={busy}>
            <RefreshCw className={`w-4 h-4 mr-1 ${busy ? 'animate-spin' : ''}`} /> Forms Google Sheet me update karein
          </Button>
        </div>
      )}
    </div>
  );
}
