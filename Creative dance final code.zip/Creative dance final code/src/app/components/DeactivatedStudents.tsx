import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { toast } from 'sonner';
import { Search, X, Calendar as CalendarIcon, UserCheck, Trash2 } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Badge } from './ui/badge';
import { deleteStudent, getStudentsLite, getStudent } from '../lib/indexedDB';
import { StudentPhoto } from './StudentPhoto';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import { useFormLayout } from '../lib/formLayout';

export function DeactivatedStudents() {
  // Admission Form Layout: hidden fields are skipped, renamed fields show the new name
  const { isVisible, label: lbl } = useFormLayout();
  const altVisible = isVisible('alternateMobile');
  const emailVisible = isVisible('email');
  const guardianVisible = isVisible('guardianName');
  const searchParts = ['Reg No', 'Name', 'Mobile', ...(altVisible ? ['Alternate Mobile'] : []), ...(emailVisible ? ['Email'] : []), ...(guardianVisible ? ['Guardian Name'] : [])];
  const searchPlaceholder = `Search by ${searchParts.length > 1 ? `${searchParts.slice(0, -1).join(', ')}, or ${searchParts[searchParts.length - 1]}` : searchParts[0]}...`;
  const [students, setStudents] = useState<any[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<any[]>([]);
  // searchInput updates instantly while typing; searchTerm (what really filters)
  // updates ~250ms after typing pauses, so 10,000 students aren't filtered per keystroke.
  const [searchInput, setSearchInput] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  // Paginated, so only one page of rows is ever rendered (same as Student List)
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  const [loadProgress, setLoadProgress] = useState<{ loaded: number; total: number } | null>(null);
  const [selectedMonth, setSelectedMonth] = useState(''); // format: 'YYYY-MM'
  const [monthPickerOpen, setMonthPickerOpen] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState<string>('');
  const [showPhotoDialog, setShowPhotoDialog] = useState(false);
  const [showActivateConfirm, setShowActivateConfirm] = useState(false);
  const [activatingStudent, setActivatingStudent] = useState<any>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingStudent, setDeletingStudent] = useState<any>(null);
  // Prevents the "No deactivated students" text from flashing for a moment
  // before the real data comes back from IndexedDB on first load.
  const [loading, setLoading] = useState(true);

  const { matchesLocation, selectedLocation } = useLocationFilter();
  useEffect(() => { loadData(); }, [selectedLocation]);

  useEffect(() => {
    const timer = setTimeout(() => setSearchTerm(searchInput), 250);
    return () => clearTimeout(timer);
  }, [searchInput]);

  useEffect(() => {
    let result = students.filter((student) => student.deactivated);

    if (searchTerm.trim() !== '') {
      const search = searchTerm.toLowerCase();
      result = result.filter((student) => (
        student.regNo?.toLowerCase().includes(search) ||
        student.name?.toLowerCase().includes(search) ||
        student.mobile?.includes(search) ||
        (altVisible && student.alternateMobile?.includes(search)) ||
        (emailVisible && student.email?.toLowerCase().includes(search)) ||
        (guardianVisible && student.guardianName?.toLowerCase().includes(search))
      ));
    }

    if (selectedMonth) {
      result = result.filter((student) => student.admissionDate?.startsWith(selectedMonth));
    }

    // Newest admission first (same order as Student List)
    result.sort((a, b) => {
      const dateDiff = new Date(b.admissionDate || 0).getTime() - new Date(a.admissionDate || 0).getTime();
      if (dateDiff !== 0) return dateDiff;
      return (b.regNo || '').localeCompare(a.regNo || '');
    });

    setFilteredStudents(result);
  }, [searchTerm, selectedMonth, students, altVisible, emailVisible, guardianVisible]);

  // New search/filter/page-size starts at page 1 (activating/deleting does not)
  useEffect(() => { setCurrentPage(1); }, [searchTerm, selectedMonth, pageSize]);

  const totalPages = Math.max(1, Math.ceil(filteredStudents.length / pageSize));
  const page = Math.min(currentPage, totalPages);
  const paginatedStudents = filteredStudents.slice((page - 1) * pageSize, page * pageSize);

  const formatMonthLabel = (monthValue: string) => {
    if (!monthValue) return '';
    const [year, month] = monthValue.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1, 1);
    return date.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
  };

  const loadData = async () => {
    setLoading(true);
    try {
      // Lite list (no photos), cached in memory — fast even with 10,000+ students
      const studentsData = await getStudentsLite((loaded, total) => setLoadProgress({ loaded, total }));
      setStudents(studentsData.filter((s: any) => matchesLocation(s.location)));
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
      setLoadProgress(null);
    }
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-GB');
  };

  const handleActivateClick = (student: any) => {
    setActivatingStudent(student);
    setShowActivateConfirm(true);
  };

  const confirmActivateStudent = async () => {
    if (!activatingStudent) return;
    try {
      const { saveStudent } = await import('../lib/indexedDB');
      // Rows have no photo, so load the complete record first (otherwise the photo would be wiped)
      const fullStudent = (await getStudent(activatingStudent.regNo)) || activatingStudent;
      await saveStudent({ ...fullStudent, deactivated: false });
      loadData();
      window.dispatchEvent(new CustomEvent('studentsUpdated'));
      toast.success(`${activatingStudent.name} moved back to Student List!`);
    } catch (error) {
      console.error('Error activating student:', error);
      toast.error('Failed to activate student');
    } finally {
      setShowActivateConfirm(false);
      setActivatingStudent(null);
    }
  };

  const handleDeleteClick = (student: any) => {
    setDeletingStudent(student);
    setShowDeleteConfirm(true);
  };

  const confirmDeleteStudent = async () => {
    if (!deletingStudent) return;
    try {
      await deleteStudent(deletingStudent.regNo);
      loadData();
      window.dispatchEvent(new CustomEvent('studentsUpdated'));
      toast.success(`${deletingStudent.name} deleted permanently!`);
    } catch (error) {
      console.error('Error deleting student:', error);
      toast.error('Failed to delete student');
    } finally {
      setShowDeleteConfirm(false);
      setDeletingStudent(null);
    }
  };

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <CardTitle>Deactivated Students</CardTitle>
            {selectedMonth && (
              <Badge variant="secondary" className="text-sm">
                {formatMonthLabel(selectedMonth)}: {filteredStudents.length} student{filteredStudents.length !== 1 ? 's' : ''}
              </Badge>
            )}
          </div>
          <div className="mt-4 flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              <Input type="text" placeholder={searchPlaceholder} value={searchInput} onChange={(e) => setSearchInput(e.target.value)} className="pl-10" />
            </div>
            <Popover open={monthPickerOpen} onOpenChange={setMonthPickerOpen}>
              <PopoverTrigger asChild>
                <Button variant={selectedMonth ? 'default' : 'outline'} className="flex items-center gap-2 whitespace-nowrap">
                  <CalendarIcon className="h-4 w-4" />
                  {selectedMonth ? formatMonthLabel(selectedMonth) : 'Select Month'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-64" align="end">
                <div className="space-y-3">
                  <Label>Filter by Admission Month</Label>
                  <Input
                    type="month"
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                  />
                  {selectedMonth && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full"
                      onClick={() => { setSelectedMonth(''); setMonthPickerOpen(false); }}
                    >
                      <X className="h-4 w-4 mr-1" /> Clear Filter
                    </Button>
                  )}
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="sticky left-0 z-20 bg-white" style={{ minWidth: '80px' }}>Photo</TableHead>
                  <TableHead className="sticky left-[80px] z-20 bg-white" style={{ minWidth: '120px' }}>Reg No</TableHead>
                  <TableHead className="sticky left-[200px] z-20 bg-white" style={{ minWidth: '140px' }}>Admission Date</TableHead>
                  <TableHead className="sticky left-[340px] z-20 bg-white" style={{ minWidth: '180px' }}>Name</TableHead>
                  <TableHead>{lbl('mobile', 'Mobile')}</TableHead>
                  {isVisible('alternateMobile') && <TableHead>{lbl('alternateMobile', 'Alternate Mobile')}</TableHead>}
                  {isVisible('email') && <TableHead>{lbl('email', 'Email')}</TableHead>}
                  {isVisible('guardianName') && <TableHead>{lbl('guardianName', 'Guardian Name')}</TableHead>}
                  {isVisible('guardianRelation') && <TableHead>{lbl('guardianRelation', 'Guardian Relation')}</TableHead>}
                  {isVisible('address') && <TableHead>{lbl('address', 'Address')}</TableHead>}
                  <TableHead>Category</TableHead>
                  <TableHead>Sub Category</TableHead>
                  <TableHead>Batch Time</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Expiry Date</TableHead>
                  <TableHead>Total Amount</TableHead>
                  <TableHead>Paid Amount</TableHead>
                  <TableHead>Dues</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.length > 0 ? (
                  paginatedStudents.map((student) => (
                    <TableRow key={student.regNo}>
                      <TableCell className="sticky left-0 z-10 bg-white" style={{ minWidth: '80px' }}>
                        <StudentPhoto regNo={student.regNo} name={student.name} hasPhoto={!!student.hasPhoto} onOpen={(photo) => { setSelectedPhoto(photo); setShowPhotoDialog(true); }} />
                      </TableCell>
                      <TableCell className="sticky left-[80px] z-10 bg-white" style={{ minWidth: '120px' }}>{student.regNo}</TableCell>
                      <TableCell className="sticky left-[200px] z-10 bg-white" style={{ minWidth: '140px' }}>{formatDate(student.admissionDate)}</TableCell>
                      <TableCell className="sticky left-[340px] z-10 bg-white" style={{ minWidth: '180px' }}>{student.name}</TableCell>
                      <TableCell>{student.mobile}</TableCell>
                      {isVisible('alternateMobile') && <TableCell>{student.alternateMobile || 'N/A'}</TableCell>}
                      {isVisible('email') && <TableCell>{student.email || 'N/A'}</TableCell>}
                      {isVisible('guardianName') && <TableCell>{student.guardianName || 'N/A'}</TableCell>}
                      {isVisible('guardianRelation') && <TableCell>{student.guardianRelation || 'N/A'}</TableCell>}
                      {isVisible('address') && <TableCell>{student.address || 'N/A'}</TableCell>}
                      <TableCell>{student.category || 'N/A'}</TableCell>
                      <TableCell>{student.subCategory || 'N/A'}</TableCell>
                      <TableCell>{student.batchTime}</TableCell>
                      <TableCell>{student.location || 'N/A'}</TableCell>
                      <TableCell>{student.duration ? `${student.duration} ${student.durationType}` : 'N/A'}</TableCell>
                      <TableCell className={new Date(student.expiryDate) < new Date() ? 'text-red-600' : 'text-green-600'}>{formatDate(student.expiryDate)}</TableCell>
                      <TableCell>₹{student.totalAmount || 0}</TableCell>
                      <TableCell>₹{student.paidAmount || 0}</TableCell>
                      <TableCell className={(student.dues || 0) > 0 ? 'text-red-600' : 'text-green-600'}>₹{student.dues || 0}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" className="text-green-600 border-green-300 hover:bg-green-50" onClick={() => handleActivateClick(student)} title="Activate">
                            <UserCheck className="w-3 h-3 mr-1" /> Active
                          </Button>
                          <Button size="sm" variant="outline" className="text-red-600 border-red-300 hover:bg-red-50" onClick={() => handleDeleteClick(student)} title="Delete">
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={20 - ['alternateMobile', 'email', 'guardianName', 'guardianRelation', 'address'].filter((id) => !isVisible(id)).length} className="text-center py-8 text-gray-500">
                      {loading
                        ? (loadProgress && loadProgress.total > 0
                            ? `Loading students... ${loadProgress.loaded.toLocaleString()} / ${loadProgress.total.toLocaleString()}`
                            : 'Loading deactivated students...')
                        : students.filter((s) => s.deactivated).length === 0
                        ? 'No deactivated students.'
                        : 'No deactivated students match your search.'}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          {filteredStudents.length > 0 && (
            <div className="flex items-center justify-between mt-4 flex-wrap gap-2">
              <p className="text-sm text-gray-500">
                Showing {(page - 1) * pageSize + 1}-{Math.min(page * pageSize, filteredStudents.length)} of {filteredStudents.length.toLocaleString()} students
              </p>
              <div className="flex items-center gap-2 flex-wrap">
                <select
                  className="h-8 rounded-md border px-2 text-sm bg-white"
                  value={pageSize}
                  onChange={(e) => setPageSize(parseInt(e.target.value))}
                  title="Rows per page"
                >
                  <option value={25}>25 / page</option>
                  <option value={50}>50 / page</option>
                  <option value={100}>100 / page</option>
                </select>
                <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setCurrentPage(1)}>First</Button>
                <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setCurrentPage(Math.max(1, page - 1))}>Previous</Button>
                <span className="text-sm flex items-center gap-1">
                  Page
                  <input
                    key={page}
                    type="number"
                    min={1}
                    max={totalPages}
                    defaultValue={page}
                    className="w-16 h-8 rounded-md border px-2 text-sm text-center"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        const n = parseInt((e.target as HTMLInputElement).value);
                        if (!isNaN(n)) setCurrentPage(Math.min(totalPages, Math.max(1, n)));
                      }
                    }}
                    title="Type a page number and press Enter"
                  />
                  of {totalPages.toLocaleString()}
                </span>
                <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setCurrentPage(Math.min(totalPages, page + 1))}>Next</Button>
                <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setCurrentPage(totalPages)}>Last</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Photo Dialog */}
      <Dialog open={showPhotoDialog} onOpenChange={setShowPhotoDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Student Photo</DialogTitle></DialogHeader>
          {selectedPhoto && (<div className="flex justify-center"><img src={selectedPhoto} alt="Student" className="w-full h-auto max-h-[80vh] object-contain" /></div>)}
        </DialogContent>
      </Dialog>

      {/* Activate Confirmation Dialog */}
      <Dialog open={showActivateConfirm} onOpenChange={(open) => { setShowActivateConfirm(open); if (!open) setActivatingStudent(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Activate Student</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-green-50 border border-green-300 rounded">
              <p className="text-sm text-green-800">
                Move <strong>{activatingStudent?.name}</strong> (Reg No: {activatingStudent?.regNo}) back to the Student List?
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => { setShowActivateConfirm(false); setActivatingStudent(null); }} className="flex-1">Cancel</Button>
              <Button onClick={confirmActivateStudent} className="flex-1 bg-green-600 hover:bg-green-700 text-white">Yes, Activate</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteConfirm} onOpenChange={(open) => { setShowDeleteConfirm(open); if (!open) setDeletingStudent(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Delete Student</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-yellow-50 border border-yellow-300 rounded">
              <p className="text-sm text-yellow-800">
                Are you sure you want to permanently delete <strong>{deletingStudent?.name}</strong> (Reg No: {deletingStudent?.regNo})? This action cannot be undone.
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => { setShowDeleteConfirm(false); setDeletingStudent(null); }} className="flex-1">Cancel</Button>
              <Button onClick={confirmDeleteStudent} className="flex-1 bg-red-600 hover:bg-red-700 text-white">Yes, Delete</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
