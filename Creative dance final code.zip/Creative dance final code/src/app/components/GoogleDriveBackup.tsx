import { useEffect, useState } from 'react';
import { Cloud, CloudOff, RefreshCw, Download as DownloadIcon, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import {
  connectDrive,
  disconnectDrive,
  getDriveStatus,
  backupNow,
  listDriveBackups,
  restoreDriveBackup,
  DriveBackupFile,
} from '../lib/googleDrive';
import { toast } from 'sonner';

interface GoogleDriveBackupProps {
  businessName: string;
  onRestored?: () => void;
}

export function GoogleDriveBackup({ businessName, onRestored }: GoogleDriveBackupProps) {
  const [connected, setConnected] = useState(false);
  const [checkingStatus, setCheckingStatus] = useState(true);
  const [connecting, setConnecting] = useState(false);
  const [backingUp, setBackingUp] = useState(false);
  const [files, setFiles] = useState<DriveBackupFile[]>([]);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [restoringId, setRestoringId] = useState<string | null>(null);

  const refreshStatus = async () => {
    setCheckingStatus(true);
    const status = await getDriveStatus();
    setConnected(status.connected);
    setCheckingStatus(false);
    if (status.connected) {
      loadFiles();
    }
  };

  useEffect(() => {
    refreshStatus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadFiles = async () => {
    setLoadingFiles(true);
    const result = await listDriveBackups();
    setLoadingFiles(false);
    if (result.success) {
      setFiles(result.data || []);
    } else {
      toast.error(result.error || 'Could not load backups from Drive');
    }
  };

  const handleConnect = async () => {
    setConnecting(true);
    const result = await connectDrive();
    setConnecting(false);
    if (result.success) {
      toast.success('Google Drive connected!');
      setConnected(true);
      loadFiles();
    } else {
      toast.error(result.error || 'Could not connect to Google Drive');
    }
  };

  const handleDisconnect = async () => {
    await disconnectDrive();
    setConnected(false);
    setFiles([]);
    toast.info('Google Drive disconnected');
  };

  const handleBackupNow = async () => {
    setBackingUp(true);
    const result = await backupNow(businessName);
    setBackingUp(false);
    if (result.success) {
      if (result.data?.skippedNoChange) {
        toast.info('Data unchanged since the last backup — nothing new to save.');
      } else {
        toast.success(`Backed up to Drive: ${result.data?.fileName}`);
        loadFiles();
      }
    } else {
      toast.error(result.error || 'Backup failed');
    }
  };

  const handleRestore = async (file: DriveBackupFile) => {
    const ok = window.confirm(
      `Restore "${file.name}"?\n\nThis will bring data from this Drive backup into the app on THIS device. Existing records with the same ID will be overwritten.`
    );
    if (!ok) return;

    setRestoringId(file.id);
    const result = await restoreDriveBackup(file.id);
    setRestoringId(null);
    if (result.success) {
      toast.success('Data restored from Drive! Reloading...', { duration: 3000 });
      onRestored?.();
      setTimeout(() => window.location.reload(), 1500);
    } else {
      toast.error(result.error || 'Restore failed');
    }
  };

  return (
    <Card className="p-4 bg-white border-2 border-blue-200">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="flex items-center gap-1.5">
            {connected ? <Cloud className="w-4 h-4 text-blue-600" /> : <CloudOff className="w-4 h-4 text-gray-400" />}
            Google Drive Auto Backup
          </h4>
          {connected && (
            <span className="text-xs flex items-center gap-1 text-green-700">
              <CheckCircle2 className="w-3.5 h-3.5" /> Connected
            </span>
          )}
        </div>

        <p className="text-sm text-gray-600">
          Automatic daily backup at 9 PM. Your data stays safe and up to date.
        </p>

        {checkingStatus ? (
          <p className="text-xs text-gray-400">Checking status...</p>
        ) : !connected ? (
          <Button onClick={handleConnect} disabled={connecting} className="w-full bg-blue-600 hover:bg-blue-700">
            {connecting ? 'Connecting...' : 'Connect Google Drive'}
          </Button>
        ) : (
          <>
            <div className="flex gap-2">
              <Button onClick={handleBackupNow} disabled={backingUp} className="flex-1 bg-blue-600 hover:bg-blue-700">
                <RefreshCw className={`w-4 h-4 mr-2 ${backingUp ? 'animate-spin' : ''}`} />
                {backingUp ? 'Backing up...' : 'Backup Now'}
              </Button>
              <Button onClick={handleDisconnect} variant="outline" className="text-red-600 border-red-200">
                Disconnect
              </Button>
            </div>

            <div className="pt-2 border-t">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-gray-500">Latest backup on Drive</p>
                <Button variant="ghost" size="sm" onClick={loadFiles} disabled={loadingFiles} className="h-6 px-2 text-xs">
                  Refresh
                </Button>
              </div>

              {loadingFiles ? (
                <p className="text-xs text-gray-400">Loading...</p>
              ) : files.length === 0 ? (
                <p className="text-xs text-gray-400">No backups yet — click "Backup Now" to create the first one.</p>
              ) : (
                (() => {
                  const file = files[0]; // list is newest-first, we only show the latest
                  return (
                    <div className="flex items-center justify-between text-xs bg-gray-50 rounded px-2 py-1.5">
                      <div className="min-w-0">
                        <p className="truncate">{file.name}</p>
                        <p className="text-gray-400">{new Date(file.createdTime).toLocaleString('en-IN')}</p>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-6 px-2 text-xs shrink-0 ml-2"
                        disabled={restoringId === file.id}
                        onClick={() => handleRestore(file)}
                      >
                        <DownloadIcon className="w-3 h-3 mr-1" />
                        {restoringId === file.id ? 'Restoring...' : 'Restore'}
                      </Button>
                    </div>
                  );
                })()
              )}
            </div>

            <p className="text-xs text-gray-400 flex items-start gap-1">
              <AlertTriangle className="w-3 h-3 mt-0.5 shrink-0" />
              Restore replaces matching records on this device — use it when setting up a new/replacement system.
            </p>
          </>
        )}
      </div>
    </Card>
  );
}
