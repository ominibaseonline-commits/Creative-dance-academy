import { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Tag } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { toast } from 'sonner';
import {
  getAllCategories,
  saveCategory,
  deleteCategory
} from '../lib/indexedDB';

export function CategoryManagement() {
  const [categories, setCategories] = useState<any[]>([]);
  const [categoryName, setCategoryName] = useState('');
  const [subCategories, setSubCategories] = useState<string[]>(['']);
  const [editingCategory, setEditingCategory] = useState<any>(null);

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    try {
      const categoriesData = await getAllCategories();
      setCategories(categoriesData);
    } catch (error) {
      console.error('Error loading categories:', error);
    }
  };

  const handleAddSubCategory = () => {
    setSubCategories([...subCategories, '']);
  };

  const handleRemoveSubCategory = (index: number) => {
    const newSubCategories = subCategories.filter((_, i) => i !== index);
    setSubCategories(newSubCategories);
  };

  const handleSubCategoryChange = (index: number, value: string) => {
    const newSubCategories = [...subCategories];
    newSubCategories[index] = value;
    setSubCategories(newSubCategories);
  };

  const handleSaveCategory = async () => {
    if (!categoryName.trim()) {
      toast.error('Please enter category name');
      return;
    }

    const filteredSubCategories = subCategories.filter(s => s.trim());
    if (filteredSubCategories.length === 0) {
      toast.error('Please add at least one sub-category');
      return;
    }

    try {
      const categoryData = {
        id: editingCategory?.id || `cat-${Date.now()}`,
        name: categoryName.trim(),
        subCategories: filteredSubCategories
      };

      await saveCategory(categoryData);
      await loadCategories();

      setCategoryName('');
      setSubCategories(['']);
      setEditingCategory(null);

      toast.success(editingCategory ? 'Category updated successfully!' : 'Category added successfully!');

      // Dispatch custom event to notify other components
      window.dispatchEvent(new CustomEvent('categoriesUpdated'));
    } catch (error) {
      console.error('Error saving category:', error);
      toast.error('Failed to save category');
    }
  };

  const handleEditCategory = (category: any) => {
    setCategoryName(category.name);
    setSubCategories(category.subCategories);
    setEditingCategory(category);
  };

  const handleDeleteCategory = async (categoryId: string) => {
    if (!confirm('Are you sure you want to delete this category? This will affect all batches and students using this category.')) {
      return;
    }

    try {
      await deleteCategory(categoryId);
      await loadCategories();
      toast.success('Category deleted successfully!');

      // Dispatch custom event to notify other components
      window.dispatchEvent(new CustomEvent('categoriesUpdated'));
    } catch (error) {
      console.error('Error deleting category:', error);
      toast.error('Failed to delete category');
    }
  };

  const handleCancelEditCategory = () => {
    setEditingCategory(null);
    setCategoryName('');
    setSubCategories(['']);
  };

  return (
    <div className="p-6 space-y-6">
      <Card className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border-2 border-blue-200">
        <h3 className="flex items-center gap-2 mb-4">
          <Tag className="w-5 h-5 text-blue-600" />
          Category & Sub-Category Management
        </h3>

        <div className="space-y-4">
          {/* Add/Edit Category Form */}
          <div className="p-4 bg-white rounded-lg border-2 border-gray-200">
            <h4 className="mb-3">{editingCategory ? 'Edit Category' : 'Add New Category'}</h4>

            <div className="space-y-3">
              <div>
                <Label>Category Name</Label>
                <Input
                  value={categoryName}
                  onChange={(e) => setCategoryName(e.target.value)}
                  placeholder="e.g., Dance, Fitness, Yoga"
                />
              </div>

              <div>
                <Label>Sub-Categories</Label>
                <div className="space-y-2">
                  {subCategories.map((subCat, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        value={subCat}
                        onChange={(e) => handleSubCategoryChange(index, e.target.value)}
                        placeholder={`Sub-category ${index + 1} (e.g., Classical, Hip-Hop)`}
                      />
                      {subCategories.length > 1 && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleRemoveSubCategory(index)}
                          className="shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleAddSubCategory}
                    className="w-full"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Sub-Category
                  </Button>
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={handleSaveCategory} className="flex-1 bg-blue-600 hover:bg-blue-700">
                  <Plus className="w-4 h-4 mr-2" />
                  {editingCategory ? 'Update Category' : 'Add Category'}
                </Button>
                {editingCategory && (
                  <Button onClick={handleCancelEditCategory} variant="outline" className="flex-1">
                    Cancel
                  </Button>
                )}
              </div>
            </div>
          </div>

          {/* Categories List */}
          <div className="space-y-3">
            <h4>Existing Categories ({categories.length})</h4>
            {categories.length > 0 ? (
              categories.map((category: any, index: number) => (
                <Card key={category.id} className="p-4 bg-white border-2 border-purple-100">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="bg-purple-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm">
                          {index + 1}
                        </span>
                        <h5 className="font-bold text-lg">{category.name}</h5>
                      </div>
                      <div className="ml-8">
                        <p className="text-sm text-gray-600 mb-1">Sub-Categories:</p>
                        <div className="flex flex-wrap gap-2">
                          {category.subCategories.map((sub: string, idx: number) => (
                            <span
                              key={idx}
                              className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm"
                            >
                              {sub}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2 ml-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEditCategory(category)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteCategory(category.id)}
                        className="text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))
            ) : (
              <p className="text-center text-gray-500 py-8">No categories added yet</p>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
