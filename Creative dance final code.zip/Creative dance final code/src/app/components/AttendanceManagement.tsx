import { useCallback, useEffect, useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { toast } from 'sonner';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';
import { Label } from './ui/label';
import { QrCode, RefreshCw, Search, Download, AlertTriangle, MessageCircle, UserCheck, Plus, Pencil, CalendarCheck, BarChart3, Trash2, ClipboardCheck, CheckCircle2 } from 'lucide-react';
import { Reports } from './Reports';
import { DailyAttendance } from './DailyAttendance';
import { StudentPhoto } from './StudentPhoto';
import { batchSortKey } from '../lib/batchTime';
import { buildAttendanceDuesMessage, AttendanceDuesKind, buildAttendanceExpiryMessage, AttendanceExpiryKind } from '../lib/reminderMessages';
import {
  FlexiPlan, FlexiUsage, computeFlexiUsage, flexiLabel, getFlexiPlans, planFor, removeFlexiPlan, saveFlexiPlan,
} from '../lib/flexi';
import { DuesSplit } from '../lib/dues';
import { getStudentsLite } from '../lib/indexedDB';
import { useBusinessName } from '../contexts/BusinessContext';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import {
  AttendanceConfig,
  AttendanceRecord,
  adminCheckIn,
  adminCheckOut,
  buildDuesMap,
  buildQrPreview,
  downloadAttendanceQrPdf,
  fetchAttendance,
  getAttendanceConfig,
  getCachedAttendance,
  pushAttendanceConfig,
  syncStudentsToScript,
} from '../lib/attendance';

type StatusFilter = 'all' | 'present' | 'absent';

const todayStr = () => new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD in local time

const NO_BATCH = '__none__';
const ALL_BATCHES = 'all';

/** Same lookup the Quick Check-in button uses: exact Reg No, else a full 10-digit phone number. */
async function findQuickMatches(q: string): Promise<any[]> {
  const t = q.trim();
  if (!t) return [];
  const all = (await getStudentsLite()).filter((x: any) => !x.deactivated);
  const low = t.toLowerCase();
  let found = all.filter((x: any) => String(x.regNo).toLowerCase() === low);
  if (found.length === 0) {
    const digits = t.replace(/\D/g, '');
    if (digits.length >= 10) {
      const last10 = digits.slice(-10);
      found = all.filter((x: any) => String(x.mobile || '').replace(/\D/g, '').slice(-10) === last10);
    }
  }
  return found;
}

const formatSavedAt = (iso: string) =>
  iso ? new Date(iso).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '';

/** Attendance page = two tabs: the live attendance list and the Reports (moved here from the sidebar). */
export function AttendanceManagement({ initialTab = 'attendance' }: { initialTab?: 'daily' | 'attendance' | 'reports' }) {
  const [tab, setTab] = useState<string>(initialTab);
  return (
    <Tabs value={tab} onValueChange={setTab} className="gap-0">
      <div className="px-6 pt-6">
        <Card className="overflow-hidden">
        <TabsList className="w-full grid grid-cols-3 h-auto rounded-none">
          <TabsTrigger value="daily" className="flex items-center gap-1.5 py-2.5"><ClipboardCheck className="w-4 h-4" />Daily Attendance</TabsTrigger>
          <TabsTrigger value="attendance" className="flex items-center gap-1.5 py-2.5"><CalendarCheck className="w-4 h-4" />QR Attendance</TabsTrigger>
          <TabsTrigger value="reports" className="flex items-center gap-1.5 py-2.5"><BarChart3 className="w-4 h-4" />Reports</TabsTrigger>
        </TabsList>
        </Card>
      </div>
      <TabsContent value="daily"><DailyAttendance /></TabsContent>
      <TabsContent value="attendance"><AttendancePanel /></TabsContent>
      <TabsContent value="reports"><Reports /></TabsContent>
    </Tabs>
  );
}

function AttendancePanel() {
  const { businessName, businessLogo } = useBusinessName();
  const { matchesLocation, selectedLocation } = useLocationFilter();

  const [students, setStudents] = useState<any[]>([]);
  const [duesMap, setDuesMap] = useState<Record<string, DuesSplit>>({});
  const [config, setConfig] = useState<AttendanceConfig | null>(null);
  // Attendance is always for today (the date picker was replaced by the batch filter)
  const [date, setDate] = useState(todayStr());
  const [batch, setBatch] = useState<string>(ALL_BATCHES);
  const [records, setRecords] = useState<Record<string, AttendanceRecord>>({});
  const [savedAt, setSavedAt] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [fetchError, setFetchError] = useState('');

  const [searchInput, setSearchInput] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const PAGE_SIZE = 100;

  // Quick check-in by the admin (reg no / phone no)
  const [quick, setQuick] = useState('');
  const [quickBusy, setQuickBusy] = useState(false);
  const [quickMatches, setQuickMatches] = useState<any[]>([]); // student(s) the typed Reg No / phone belongs to (shown above the box)
  const [busyRegs, setBusyRegs] = useState<Set<string>>(new Set());

  // Batch check-in popup: pick a batch time -> every student of that batch with a Check In button
  const [batchDlg, setBatchDlg] = useState<{ batch: string; highlight: string[] } | null>(null);

  // Flexi classes
  const [plans, setPlans] = useState<Record<string, FlexiPlan>>({});
  const [usage, setUsage] = useState<Record<string, FlexiUsage>>({});
  const [flexiStudent, setFlexiStudent] = useState<any | null>(null);
  const [flexiCount, setFlexiCount] = useState('');
  const [flexiMode, setFlexiMode] = useState<'add' | 'new'>('add');

  const [showQr, setShowQr] = useState(false);
  const [qrPreview, setQrPreview] = useState('');

  const connected = !!config?.webAppUrl;

  const loadStudents = useCallback(async () => {
    const all = await getStudentsLite(); // from the CMS's own local storage
    // Deactivated students are not part of attendance
    const visible = all.filter((s: any) => !s.deactivated && matchesLocation(s.location));
    setStudents(visible);
    setDuesMap(await buildDuesMap(visible));
  }, [selectedLocation]);

  /**
   * 1) show what is already saved on this computer (instant, no internet)
   * 2) then ask Google only if something new was marked (cheap version check inside fetchAttendance)
   */
  const loadRecords = useCallback(async (opts: { silent?: boolean; force?: boolean } = {}) => {
    const cfg = await getAttendanceConfig();
    setConfig(cfg);
    if (!cfg.webAppUrl) { setRecords({}); setSavedAt(''); setFetchError(''); return; }

    if (!opts.silent && !opts.force) {
      const local = await getCachedAttendance(date);
      if (local) { setRecords(local.records); setSavedAt(local.savedAt); } else { setRecords({}); setSavedAt(''); }
    }

    if (!opts.silent) setRefreshing(true);
    try {
      const res = await fetchAttendance(date, { force: opts.force });
      setRecords(res.records);
      setSavedAt(res.savedAt);
      setFetchError('');
    } catch (e: any) {
      // Offline / script down: the saved copy stays on screen
      setFetchError(e?.message || 'Attendance load nahi ho payi');
    } finally {
      setRefreshing(false);
    }
  }, [date]);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        await loadStudents();
      } catch (e) {
        console.error(e);
        toast.error('Failed to load data');
      } finally {
        setLoading(false);
      }
    })();
  }, [loadStudents]);

  useEffect(() => {
    const handler = () => loadStudents();
    window.addEventListener('studentsUpdated', handler);
    return () => window.removeEventListener('studentsUpdated', handler);
  }, [loadStudents]);

  // Load this date: saved copy first, then a quick catch-up from Google
  useEffect(() => { loadRecords(); }, [loadRecords]);

  // The background live-sync (AdminDashboard) saves new check-ins locally within ~2 seconds
  // and fires this event; we just re-read the local copy, so the row appears instantly.
  useEffect(() => {
    const onLive = async (e: Event) => {
      const d = (e as CustomEvent).detail?.date;
      if (d && d !== date) return;
      const local = await getCachedAttendance(date);
      if (local) { setRecords(local.records); setSavedAt(local.savedAt); setFetchError(''); }
    };
    window.addEventListener('attendanceUpdated', onLive);
    return () => window.removeEventListener('attendanceUpdated', onLive);
  }, [date]);

  // Settings -> Check-out option / Expired block changed: show or hide the Check Out column at once
  useEffect(() => {
    const h = async () => setConfig(await getAttendanceConfig());
    window.addEventListener('attendanceConfigUpdated', h);
    return () => window.removeEventListener('attendanceConfigUpdated', h);
  }, []);

  // New day while the CMS stays open -> move to the new date
  useEffect(() => {
    const t = setInterval(() => { const d = todayStr(); setDate((prev) => (prev === d ? prev : d)); }, 60000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setSearchTerm(searchInput), 250);
    return () => clearTimeout(t);
  }, [searchInput]);

  const batchKeyOf = (s: any) => (s.batchTime && String(s.batchTime).trim()) || NO_BATCH;

  // Distinct batch slots with how many students each has
  const batchOptions = useMemo(() => {
    const counts = new Map<string, number>();
    students.forEach((s) => { const k = batchKeyOf(s); counts.set(k, (counts.get(k) || 0) + 1); });
    return Array.from(counts.entries())
      .sort((a, b) => batchSortKey(a[0]) - batchSortKey(b[0]) || a[0].localeCompare(b[0]))
      .map(([value, count]) => ({ value, count, label: value === NO_BATCH ? 'No Batch' : value }));
  }, [students]);

  // If the chosen batch disappears (e.g. students moved), fall back to all
  useEffect(() => {
    if (batch !== ALL_BATCHES && !batchOptions.some((b) => b.value === batch)) setBatch(ALL_BATCHES);
  }, [batchOptions, batch]);

  const batchStudents = useMemo(
    () => (batch === ALL_BATCHES ? students : students.filter((s) => batchKeyOf(s) === batch)),
    [students, batch],
  );

  const recordOf = (s: any): AttendanceRecord | undefined => records[String(s.regNo).toLowerCase()];

  const counts = useMemo(() => {
    let present = 0;
    let out = 0;
    batchStudents.forEach((s) => {
      const r = records[String(s.regNo).toLowerCase()];
      if (r?.checkIn) present++;
      if (r?.checkOut) out++;
    });
    return { total: batchStudents.length, present, absent: batchStudents.length - present, out };
  }, [batchStudents, records]);

  const filtered = useMemo(() => {
    let result = batchStudents;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      result = result.filter((s) =>
        s.regNo?.toLowerCase().includes(q) ||
        s.name?.toLowerCase().includes(q) ||
        s.mobile?.includes(q));
    }
    if (statusFilter !== 'all') {
      result = result.filter((s) => {
        const present = !!records[String(s.regNo).toLowerCase()]?.checkIn;
        return statusFilter === 'present' ? present : !present;
      });
    }
    return [...result].sort((a, b) => {
      // Present students first, then newest reg no
      const pa = records[String(a.regNo).toLowerCase()]?.checkIn ? 0 : 1;
      const pb = records[String(b.regNo).toLowerCase()]?.checkIn ? 0 : 1;
      if (pa !== pb) return statusFilter === 'all' ? pa - pb : 0;
      return (b.regNo || '').localeCompare(a.regNo || '');
    });
  }, [batchStudents, searchTerm, statusFilter, records]);

  useEffect(() => { setCurrentPage(1); }, [searchTerm, statusFilter, date, batch]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageRows = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const handleSyncAndRefresh = async () => {
    if (!connected) { toast.error('Pehle Settings → Management & Setup me Attendance connect karein'); return; }
    setRefreshing(true);
    try {
      await pushAttendanceConfig();
      await syncStudentsToScript(); // only changed students are sent
      await loadRecords({ silent: true, force: true });
      toast.success('Attendance refresh ho gayi');
    } catch (e: any) {
      toast.error(e?.message || 'Refresh fail ho gaya');
    } finally {
      setRefreshing(false);
    }
  };

  const openQr = async () => {
    if (!config?.webAppUrl) {
      toast.error('Pehle Settings → Management & Setup me Attendance connect karein');
      return;
    }
    setQrPreview(await buildQrPreview(config.webAppUrl));
    setShowQr(true);
  };

  const downloadQr = async () => {
    if (!config?.webAppUrl) return;
    try {
      await downloadAttendanceQrPdf({ businessName, businessLogo, url: config.webAppUrl });
      toast.success('QR PDF download ho gayi');
    } catch (e) {
      console.error(e);
      toast.error('PDF nahi ban payi');
    }
  };

  // ---------- flexi plans + classes taken ----------
  const loadPlans = useCallback(async () => setPlans(await getFlexiPlans()), []);
  useEffect(() => {
    loadPlans();
    window.addEventListener('flexiUpdated', loadPlans);
    return () => window.removeEventListener('flexiUpdated', loadPlans);
  }, [loadPlans]);

  const refreshUsage = useCallback(async () => setUsage(await computeFlexiUsage(plans)), [plans]);
  useEffect(() => {
    refreshUsage();
    window.addEventListener('attendanceUpdated', refreshUsage);
    return () => window.removeEventListener('attendanceUpdated', refreshUsage);
  }, [refreshUsage]);

  const openFlexi = (s: any) => {
    setFlexiStudent(s);
    setFlexiCount('');
    setFlexiMode(planFor(plans, s.regNo) ? 'add' : 'new');
  };

  const saveFlexi = async () => {
    const n = Math.floor(Number(flexiCount));
    if (!flexiStudent || !n || n < 1) { toast.error('Classes ki sankhya daalein (kam se kam 1)'); return; }
    await saveFlexiPlan(flexiStudent.regNo, n, flexiMode);
    toast.success(`${flexiStudent.name}: ${n} flexi class${n === 1 ? '' : 'es'} ${flexiMode === 'add' && planFor(plans, flexiStudent.regNo) ? 'add ho gayi' : 'set ho gayi'}`);
    setFlexiStudent(null);
  };

  const deleteFlexi = async () => {
    if (!flexiStudent) return;
    await removeFlexiPlan(flexiStudent.regNo);
    toast.success('Flexi package hata diya');
    setFlexiStudent(null);
  };

  // ---------- dues WhatsApp ----------
  const sendDues = async (s: any, kind: AttendanceDuesKind, amount: number) => {
    const phone = String(s.mobile || '').replace(/\D/g, '').slice(-10);
    if (phone.length !== 10) { toast.error('Is student ka sahi mobile number nahi hai'); return; }
    const msg = await buildAttendanceDuesMessage(s, businessName, kind, amount);
    window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  // ---------- expiry WhatsApp (Expiry Soon = 5 din ya kam bacha, Expired = ho chuki) ----------
  const expiryKindOf = (s: any): AttendanceExpiryKind | null => {
    if (!s.expiryDate) return null;
    const e = new Date(s.expiryDate);
    if (isNaN(e.getTime())) return null;
    const now = new Date();
    const limit = new Date(); limit.setDate(limit.getDate() + 5);
    if (e < now) return 'expired';
    if (e <= limit) return 'soon';
    return null;
  };
  const sendExpiry = async (s: any, kind: AttendanceExpiryKind) => {
    const phone = String(s.mobile || '').replace(/\D/g, '').slice(-10);
    if (phone.length !== 10) { toast.error('Is student ka sahi mobile number nahi hai'); return; }
    const msg = await buildAttendanceExpiryMessage(s, businessName, kind, (d) => (d ? new Date(d).toLocaleDateString('en-GB') : 'N/A'));
    window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  // ---------- admin check-in (saved on this computer first, Google gets it right after) ----------
  const markPresent = async (s: any, fromQuick = false) => {
    if (!connected) { toast.error('Pehle Settings → Management & Setup me Attendance connect karein'); return; }
    const reg = String(s.regNo);
    setBusyRegs((p) => new Set(p).add(reg));
    if (fromQuick) setQuickBusy(true);
    try {
      // No batch passed: the submit-lock belongs to the Daily Attendance panel only
      const r = await adminCheckIn(s.regNo, s.name);
      if (r.already) toast.info(`${s.name} ki attendance pehle se lagi hui hai (${r.checkIn})`);
      else if (r.pending) toast.warning(`${s.name} present (${r.checkIn}) — yahan save ho gaya, internet aate hi Google par jayega`);
      else if (r.expired) toast.warning(`${s.name} present (${r.checkIn}) — par session EXPIRED hai`);
      else toast.success(`${s.name} present ho gaya (${r.checkIn})`);
      if (fromQuick) setQuick('');
    } catch (e: any) {
      toast.error(e?.message || 'Attendance mark nahi hui');
    } finally {
      setBusyRegs((p) => { const n = new Set(p); n.delete(reg); return n; });
      if (fromQuick) setQuickBusy(false);
    }
  };

  const markOut = async (s: any) => {
    const reg = String(s.regNo);
    setBusyRegs((p) => new Set(p).add(reg));
    try {
      const r = await adminCheckOut(s.regNo, s.name);
      if (r.already) toast.info(`${s.name} ka check-out pehle se ho chuka hai (${r.checkOut})`);
      else if (r.pending) toast.warning(`${s.name} check-out (${r.checkOut}) — yahan save ho gaya, internet aate hi Google par jayega`);
      else toast.success(`${s.name} ka check-out ho gaya (${r.checkOut})`);
    } catch (e: any) {
      toast.error(e?.message || 'Check-out nahi hua');
    } finally {
      setBusyRegs((p) => { const n = new Set(p); n.delete(reg); return n; });
    }
  };

  // As soon as a Reg No / phone no is typed, show who it is so the admin can confirm the name first
  useEffect(() => {
    const q = quick.trim();
    if (!q) { setQuickMatches([]); return; }
    let alive = true;
    findQuickMatches(q).then((m) => { if (alive) setQuickMatches(m); }).catch(() => { if (alive) setQuickMatches([]); });
    return () => { alive = false; };
  }, [quick, students]);

  const handleQuickCheckIn = async () => {
    const q = quick.trim();
    if (!q) return;
    const found = await findQuickMatches(q);
    if (found.length === 0) { toast.error('Is Reg No / Phone No ka koi active student nahi mila'); return; }
    if (found.length > 1) {
      // Same phone no. on several students -> choose the batch time and tick the right student there
      setBatchDlg({ batch: batchKeyOf(found[0]), highlight: found.map((x: any) => String(x.regNo)) });
      return;
    }
    await markPresent(found[0], true);
  };

  const dlgStudents = useMemo(() => {
    if (!batchDlg) return [];
    const hi = new Set(batchDlg.highlight);
    return students
      .filter((s) => batchKeyOf(s) === batchDlg.batch)
      .sort((a, b) => (hi.has(String(b.regNo)) ? 1 : 0) - (hi.has(String(a.regNo)) ? 1 : 0) || String(a.name || '').localeCompare(String(b.name || '')));
  }, [batchDlg, students]);

  const dlgPresent = dlgStudents.filter((s) => !!recordOf(s)?.checkIn).length;

  const statCard = (label: string, value: number, cls: string) => (
    <div className={`rounded-lg p-4 border ${cls}`}>
      <p className="text-sm opacity-80">{label}</p>
      <p className="text-2xl font-semibold">{value}</p>
    </div>
  );

  const colCount = config?.enableCheckout ? 9 : 8;

  return (
    <div className="px-6 pt-3 pb-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <CardTitle>QR Attendance</CardTitle>
              {connected && savedAt && (
                <p className="text-xs text-gray-500 mt-1">Last updated: {formatSavedAt(savedAt)}</p>
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleSyncAndRefresh} disabled={refreshing}>
                <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Button onClick={openQr} className="bg-orange-500 hover:bg-orange-600 text-white">
                <QrCode className="w-4 h-4 mr-2" />
                Generate QR
              </Button>
            </div>
          </div>

          {!connected && config && (
            <div className="mt-3 p-3 rounded-md bg-yellow-50 border border-yellow-300 text-sm text-yellow-800 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>
                Attendance is not connected. Go to <b>Settings → Management & Setup → Attendance Setup</b> to connect.
              </span>
            </div>
          )}
          {connected && fetchError && (
            <div className="mt-3 p-3 rounded-md bg-red-50 border border-red-300 text-sm text-red-700 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{fetchError}{savedAt ? ' (Saved data dikh raha hai)' : ''}</span>
            </div>
          )}

          <div className={`mt-4 grid gap-3 ${config?.enableCheckout ? 'grid-cols-2 md:grid-cols-4' : 'grid-cols-3'}`}>
            {statCard(batch === ALL_BATCHES ? 'Total Students' : 'Batch Students', counts.total, 'bg-blue-50 border-blue-200 text-blue-800')}
            {statCard('Present', counts.present, 'bg-green-50 border-green-200 text-green-800')}
            {statCard('Absent', counts.absent, 'bg-red-50 border-red-200 text-red-800')}
            {config?.enableCheckout && statCard('Checked Out', counts.out, 'bg-purple-50 border-purple-200 text-purple-800')}
          </div>

          {/* Student confirmation: appears above the Quick Check-in box as soon as a matching Reg No / phone is typed */}
          {quick.trim() !== '' && (
            <div className="mt-4 space-y-2">
              {quickMatches.length > 0 ? quickMatches.map((m) => {
                const rec = recordOf(m);
                const dz = duesMap[String(m.regNo)] || { admission: 0, monthly: 0 };
                const dueTotal = (Number(dz.admission) || 0) + (Number(dz.monthly) || 0);
                const expired = m.expiryDate && new Date(m.expiryDate) < new Date();
                return (
                  <div key={m.regNo} className="flex items-center gap-4 rounded-lg border-2 border-green-300 bg-green-50 p-3">
                    <StudentPhoto regNo={String(m.regNo)} name={m.name} hasPhoto={!!m.hasPhoto} onOpen={() => {}} />
                    <div className="min-w-0 flex-1">
                      <p className="text-lg font-bold text-gray-900 truncate">{m.name}</p>
                      <p className="text-sm text-gray-600">
                        Reg No: <b>{m.regNo}</b>{m.mobile ? <> &nbsp;•&nbsp; {m.mobile}</> : null}{m.batchTime ? <> &nbsp;•&nbsp; {m.batchTime}</> : null}
                      </p>
                      <div className="flex items-center gap-2 flex-wrap mt-1 text-xs">
                        {rec?.checkIn
                          ? <span className="px-2 py-0.5 rounded-full bg-green-100 text-green-700 font-semibold">Aaj present ({rec.checkIn})</span>
                          : <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-700 font-semibold">Aaj abhi check-in nahi hua</span>}
                        {expired && <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 font-semibold">Session Expired</span>}
                        {dueTotal > 0 && <span className="px-2 py-0.5 rounded-full bg-orange-100 text-orange-700 font-semibold">Dues ₹{dueTotal}</span>}
                      </div>
                    </div>
                  </div>
                );
              }) : (
                <div className="rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-500">
                  Ye Reg No / phone abhi kisi active student se match nahi hua (phone poora 10 digit daalein).
                </div>
              )}
            </div>
          )}

          <div className="mt-3 flex items-center gap-2 flex-wrap rounded-lg border border-orange-200 bg-orange-50 p-3">
            <UserCheck className="w-5 h-5 text-orange-600 shrink-0" />
            <Input
              type="text"
              placeholder="Quick Check-in: student ka Reg No ya Phone No daalein"
              value={quick}
              onChange={(e) => setQuick(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleQuickCheckIn()}
              className="flex-1 min-w-[240px] bg-white"
            />
            <Button onClick={handleQuickCheckIn} disabled={quickBusy || !quick.trim()} className="bg-orange-500 hover:bg-orange-600 text-white">
              {quickBusy ? 'Please wait...' : 'Check In'}
            </Button>
          </div>

          <div className="mt-3 flex items-center gap-2 flex-wrap">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Search by Reg No, Name or Phone..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={batch} onValueChange={setBatch}>
              <SelectTrigger className="w-[230px]">
                <SelectValue placeholder="Batch Slot" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_BATCHES}>All Batches</SelectItem>
                {batchOptions.map((b) => (
                  <SelectItem key={b.value} value={b.value}>{b.label} ({b.count})</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {(['all', 'present', 'absent'] as StatusFilter[]).map((f) => (
              <Button
                key={f}
                variant={statusFilter === f ? 'default' : 'outline'}
                onClick={() => setStatusFilter(f)}
                className="capitalize"
              >
                {f}
              </Button>
            ))}
          </div>
        </CardHeader>

        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Reg No</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Phone No</TableHead>
                  <TableHead>Admission Dues</TableHead>
                  <TableHead>Monthly Dues</TableHead>
                  <TableHead>Check In</TableHead>
                  {config?.enableCheckout && <TableHead>Check Out</TableHead>}
                  <TableHead>Expiry</TableHead>
                  <TableHead className="text-right">Flexi Classes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pageRows.length > 0 ? (
                  pageRows.map((s) => {
                    const r = recordOf(s);
                    const dz = duesMap[String(s.regNo)] || { admission: 0, monthly: 0 };
                    const plan = planFor(plans, s.regNo);
                    const u = plan ? usage[String(s.regNo).toLowerCase()] : undefined;
                    const lbl = u ? flexiLabel(u) : null;
                    const lblCls = !lbl ? '' : lbl.tone === 'extra' ? 'bg-red-100 text-red-700' : lbl.tone === 'zero' ? 'bg-amber-100 text-amber-800' : 'bg-purple-100 text-purple-700';
                    const expKind = expiryKindOf(s);
                    const waBtn = (kind: AttendanceDuesKind, amount: number) => amount > 0 && (
                      <button
                        onClick={() => sendDues(s, kind, amount)}
                        title={kind === 'admission' ? 'WhatsApp: Admission Dues reminder' : 'WhatsApp: Monthly Dues reminder'}
                        className="w-7 h-7 rounded-md bg-green-500 hover:bg-green-600 text-white flex items-center justify-center shrink-0"
                      >
                        <MessageCircle className="w-4 h-4" />
                      </button>
                    );
                    return (
                      <TableRow key={s.regNo}>
                        <TableCell>{s.regNo}</TableCell>
                        <TableCell>{s.name}</TableCell>
                        <TableCell>{s.mobile || 'N/A'}</TableCell>
                        <TableCell className={dz.admission > 0 ? 'text-red-600' : 'text-green-600'}>
                          <div className="flex items-center gap-2"><span>₹{dz.admission}</span>{waBtn('admission', dz.admission)}</div>
                        </TableCell>
                        <TableCell className={dz.monthly > 0 ? 'text-red-600' : 'text-green-600'}>
                          <div className="flex items-center gap-2"><span>₹{dz.monthly}</span>{waBtn('monthly', dz.monthly)}</div>
                        </TableCell>
                        <TableCell>{r?.checkIn || '—'}</TableCell>
                        {config?.enableCheckout && (
                          <TableCell>
                            {r?.checkOut || (r?.checkIn ? (
                              <Button size="sm" variant="outline" className="h-7 px-2 text-xs" disabled={busyRegs.has(String(s.regNo))} onClick={() => markOut(s)}>Check Out</Button>
                            ) : '—')}
                          </TableCell>
                        )}
                        <TableCell className={`font-medium whitespace-nowrap ${expKind === 'expired' ? 'text-red-600' : s.expiryDate ? 'text-green-600' : 'text-gray-400'}`}>
                          <div className="flex items-center gap-2">
                            <span>{s.expiryDate ? new Date(s.expiryDate).toLocaleDateString('en-GB') : '—'}</span>
                            {expKind && (
                              <button
                                onClick={() => sendExpiry(s, expKind)}
                                title={expKind === 'soon' ? 'WhatsApp: Expiry Soon reminder' : 'WhatsApp: Expired reminder'}
                                className="w-7 h-7 rounded-md bg-green-500 hover:bg-green-600 text-white flex items-center justify-center shrink-0"
                              >
                                <MessageCircle className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center justify-end gap-2">
                            {lbl && <span className={`text-xs font-semibold px-2 py-0.5 rounded-full whitespace-nowrap ${lblCls}`}>{lbl.text}</span>}
                            <Button size="sm" variant="outline" className="h-7 px-2 text-xs" onClick={() => openFlexi(s)}>
                              {plan ? <><Pencil className="w-3.5 h-3.5 mr-1" />Edit</> : <><Plus className="w-3.5 h-3.5 mr-1" />Flexi</>}
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={colCount} className="text-center py-8 text-gray-500">
                      {loading
                        ? 'Loading students...'
                        : students.length === 0
                        ? 'No students found. Please add students from Admission Form.'
                        : 'No students match your search.'}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>

          {filtered.length > 0 && (
            <div className="flex items-center justify-between mt-4 flex-wrap gap-2">
              <p className="text-sm text-gray-500">
                Showing {(currentPage - 1) * PAGE_SIZE + 1}-{Math.min(currentPage * PAGE_SIZE, filtered.length)} of {filtered.length} students
              </p>
              <div className="flex items-center gap-2">
                <Button size="sm" variant="outline" disabled={currentPage <= 1} onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}>Previous</Button>
                <span className="text-sm">Page {currentPage} of {totalPages}</span>
                <Button size="sm" variant="outline" disabled={currentPage >= totalPages} onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}>Next</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Batch check-in: choose the batch time, every student of that batch has its own Check In button */}
      <Dialog open={!!batchDlg} onOpenChange={(o) => { if (!o) setBatchDlg(null); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Batch se Check-in</DialogTitle></DialogHeader>
          {batchDlg && (
            <div className="space-y-3">
              {batchDlg.highlight.length > 0 && (
                <p className="text-sm text-gray-600">Is phone number par ek se zyada students hain (peele me dikhe). Sahi student ke saamne Check In dabayein.</p>
              )}
              <Select value={batchDlg.batch} onValueChange={(v) => setBatchDlg({ ...batchDlg, batch: v })}>
                <SelectTrigger><SelectValue placeholder="Batch time chunein" /></SelectTrigger>
                <SelectContent>
                  {batchOptions.map((b) => (
                    <SelectItem key={b.value} value={b.value}>{b.label} ({b.count})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500">{dlgPresent} present / {dlgStudents.length} students</p>
              <div className="max-h-[50vh] overflow-y-auto space-y-2 pr-1">
                {dlgStudents.length === 0 && <p className="text-center text-sm text-gray-500 py-6">Is batch me koi student nahi hai.</p>}
                {dlgStudents.map((x) => {
                  const rec = recordOf(x);
                  const hl = batchDlg.highlight.includes(String(x.regNo));
                  return (
                    <div key={x.regNo} className={`flex items-center justify-between gap-3 rounded-lg border px-3 py-2 ${hl ? 'bg-yellow-50 border-yellow-300' : ''}`}>
                      <div className="min-w-0">
                        <div className="font-medium truncate">{x.name}</div>
                        <div className="text-xs text-gray-500">Reg No: {x.regNo}{x.mobile ? ` • ${x.mobile}` : ''}</div>
                      </div>
                      {rec?.checkIn ? (
                        <span className="flex items-center gap-1 text-sm font-semibold text-green-700 bg-green-100 rounded-lg px-2.5 py-1 shrink-0">
                          <CheckCircle2 className="w-4 h-4" />{rec.checkIn}
                        </span>
                      ) : (
                        <Button size="sm" className="bg-orange-500 hover:bg-orange-600 text-white shrink-0" disabled={busyRegs.has(String(x.regNo))} onClick={() => markPresent(x)}>
                          Check In
                        </Button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Add / edit flexi classes */}
      <Dialog open={!!flexiStudent} onOpenChange={(o) => { if (!o) setFlexiStudent(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Flexi Classes</DialogTitle></DialogHeader>
          {flexiStudent && (() => {
            const plan = planFor(plans, flexiStudent.regNo);
            const u = plan ? usage[String(flexiStudent.regNo).toLowerCase()] : undefined;
            return (
              <div className="space-y-4">
                <div>
                  <p className="font-medium">{flexiStudent.name}</p>
                  <p className="text-xs text-gray-500">Reg No: {flexiStudent.regNo}</p>
                </div>
                {plan && u && (
                  <div className="grid grid-cols-3 gap-2 text-center text-sm">
                    <div className="rounded-lg bg-gray-50 border p-2"><div className="font-bold">{u.total}</div><div className="text-xs text-gray-500">Total</div></div>
                    <div className="rounded-lg bg-orange-50 border border-orange-200 p-2"><div className="font-bold text-orange-600">{u.taken}</div><div className="text-xs text-gray-500">Li Hui</div></div>
                    <div className="rounded-lg bg-green-50 border border-green-200 p-2"><div className="font-bold text-green-700">{u.left}</div><div className="text-xs text-gray-500">Baaki</div></div>
                  </div>
                )}
                {plan && (
                  <div className="flex gap-2">
                    <Button type="button" size="sm" variant={flexiMode === 'add' ? 'default' : 'outline'} className="flex-1" onClick={() => setFlexiMode('add')}>Classes jodein</Button>
                    <Button type="button" size="sm" variant={flexiMode === 'new' ? 'default' : 'outline'} className="flex-1" onClick={() => setFlexiMode('new')}>Naya package</Button>
                  </div>
                )}
                <div>
                  <Label>{plan && flexiMode === 'add' ? 'Kitni classes aur add karni hain?' : 'Kitni classes hain?'}</Label>
                  <Input
                    type="number"
                    min={1}
                    autoFocus
                    value={flexiCount}
                    onChange={(e) => setFlexiCount(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && saveFlexi()}
                    placeholder="e.g. 10"
                    className="mt-1"
                  />
                  {plan && flexiMode === 'new' && (
                    <p className="text-xs text-gray-500 mt-1">Naya package aaj se shuru hoga; purani gini hui classes reset ho jayengi.</p>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button onClick={saveFlexi} className="flex-1 bg-orange-500 hover:bg-orange-600 text-white">Save</Button>
                  {plan && (
                    <Button variant="outline" className="text-red-600 border-red-300" onClick={deleteFlexi} title="Flexi package hatayein">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      {/* QR preview + PDF download */}
      <Dialog open={showQr} onOpenChange={setShowQr}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>QR Attendance</DialogTitle></DialogHeader>
          <div className="flex flex-col items-center gap-3 py-2">
            {businessLogo && <img src={businessLogo} alt="Logo" className="w-20 h-20 object-contain" />}
            <h3 className="text-xl font-bold text-center">{businessName}</h3>
            <p className="text-orange-600 font-semibold text-lg">QR Attendance</p>
            {qrPreview && <img src={qrPreview} alt="Attendance QR" className="w-64 h-64" />}
            <Button onClick={downloadQr} className="w-full bg-orange-500 hover:bg-orange-600 text-white">
              <Download className="w-4 h-4 mr-2" />
              Download PDF
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
