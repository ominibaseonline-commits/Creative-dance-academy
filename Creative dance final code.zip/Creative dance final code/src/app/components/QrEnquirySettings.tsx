import { useEffect, useState } from 'react';
import { QrCode, Copy, Download, ExternalLink, RefreshCw, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { qrToDataUrl } from '../lib/qr';
import { isAttendanceConnected } from '../lib/attendance';
import { getQrEnquiryEnabled, getQrEnquiryLink, pushQrEnquiryConfig, qrEnquiryError, setQrEnquiryEnabled } from '../lib/qrEnquiry';

// QR Enquiry: ek toggle. ON karte hi Enquiry section me "QR Enquiry" tab aa jata hai aur student QR / link se
// Name, Phone aur Course bhar sakta hai. Form me wahi courses dikhte hain jo upar "Courses" list me hain.
export function QrEnquirySettings() {
  const [enabled, setEnabled] = useState(false);
  const [connected, setConnected] = useState(true);
  const [link, setLink] = useState('');
  const [qr, setQr] = useState('');
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState('');
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    Promise.all([getQrEnquiryEnabled(), isAttendanceConnected(), getQrEnquiryLink()]).then(([on, conn, l]) => {
      setEnabled(on); setConnected(conn); setLink(l);
      setQr(l ? qrToDataUrl(l, 700) : '');
      setLoaded(true);
    });
  }, []);

  const toggle = async (on: boolean) => {
    setBusy(true);
    setEnabled(on);
    const r = await setQrEnquiryEnabled(on);
    setBusy(false);
    if (r.error) {
      setProblem(r.error);
      toast.error(on ? 'QR Enquiry ON ho gaya, par Google Sheet ko abhi nahi bataya ja saka' : 'OFF ho gaya, par Google Sheet ko abhi nahi bataya ja saka');
    } else {
      setProblem('');
      toast.success(on ? 'QR Enquiry ON ho gaya. Enquiry section me tab aa gaya.' : 'QR Enquiry OFF ho gaya.');
    }
  };

  const resync = async () => {
    setBusy(true);
    try {
      await pushQrEnquiryConfig(true);
      setProblem('');
      toast.success('Form Google Sheet me update ho gaya');
    } catch (e: any) {
      setProblem(qrEnquiryError(e));
      toast.error('Update nahi hua');
    } finally { setBusy(false); }
  };

  const copyLink = async () => {
    try { await navigator.clipboard.writeText(link); toast.success('Link copy ho gaya'); }
    catch { toast.error('Copy nahi hua'); }
  };

  const downloadQr = () => {
    const a = document.createElement('a');
    a.href = qr; a.download = 'qr-enquiry.png'; a.click();
  };

  if (!loaded) return null;

  return (
    <div className="bg-white rounded-lg border p-4 space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h4 className="flex items-center gap-2"><QrCode className="w-5 h-5 text-orange-600" /> QR Enquiry</h4>
          <p className="text-sm text-gray-500 mt-1">
            {enabled
              ? 'ON — student QR scan karke Name, Phone aur Course bhar sakta hai. Enquiry turant Enquiry → QR Enquiry tab me aati hai.'
              : 'OFF — QR form band hai aur Enquiry section me QR Enquiry tab nahi dikhega.'}
          </p>
        </div>
        <Switch checked={enabled} onCheckedChange={toggle} disabled={busy} />
      </div>

      {!connected && (
        <div className="flex gap-2 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>Setup: <strong>Settings → Management & Setup → Attendance Setup</strong> me system connect karein. Isi se sabhi modules chalte hain: Events, QR Enquiry, Online Admission, Attendance.</span>
        </div>
      )}

      {problem && (
        <div className="flex gap-2 rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{problem}</span>
        </div>
      )}

      {enabled && connected && link && (
        <div className="space-y-3 border-t pt-4">
          <p className="flex items-center gap-2 text-sm font-medium"><CheckCircle2 className="w-4 h-4 text-green-600" /> Ye QR / link office me lagayein</p>
          <div className="flex flex-col md:flex-row gap-4 items-start">
            {qr && <img src={qr} alt="QR Enquiry QR" className="w-44 h-44 border rounded-lg" />}
            <div className="flex-1 min-w-0 space-y-3">
              <div className="text-xs font-mono break-all rounded-md bg-gray-50 border p-2">{link}</div>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={copyLink}><Copy className="w-4 h-4 mr-1" /> Link copy</Button>
                <Button size="sm" variant="outline" onClick={downloadQr}><Download className="w-4 h-4 mr-1" /> QR download</Button>
                <Button size="sm" variant="outline" onClick={() => window.open(link, '_blank')}><ExternalLink className="w-4 h-4 mr-1" /> Form dekhein</Button>
                <Button size="sm" variant="outline" onClick={resync} disabled={busy}><RefreshCw className={`w-4 h-4 mr-1 ${busy ? 'animate-spin' : ''}`} /> Form update karein</Button>
              </div>
              <ul className="text-xs text-gray-500 list-disc pl-4 space-y-1">
                <li>Form me Name, Phone No aur Select Course aate hain. Courses wahi hain jo <strong>Settings → Enquiry Settings → Courses</strong> list me hain (badalne par form apne aap update ho jata hai).</li>
                <li>Query Source apne aap <strong>Office Visit</strong> set hota hai.</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
