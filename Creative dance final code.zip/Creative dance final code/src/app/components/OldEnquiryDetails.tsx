import { AlertTriangle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import {
  Enquiry, REPEAT_WARNING, enquirySection, statusInfo, formatDateTime, formatDateOnly,
} from '../lib/enquiries';

// Small warning line + "View Old Details" button, shown only on repeat enquiries
// (same name + same phone as an earlier one). Used on the Dashboard and in the QR Enquiry tab.
export function RepeatNotice({ onView, compact = false }: { onView: () => void; compact?: boolean }) {
  return (
    <div className={`flex items-center flex-wrap gap-x-2 gap-y-1 ${compact ? 'text-[11px] leading-tight' : 'text-sm bg-amber-50 border border-amber-300 rounded-md px-3 py-1.5'} text-amber-800`}>
      <span className="flex items-center gap-1 font-medium"><AlertTriangle className={compact ? 'w-3 h-3' : 'w-4 h-4'} /> {REPEAT_WARNING}</span>
      <button
        type="button"
        onClick={(ev) => { ev.stopPropagation(); onView(); }}
        className="text-blue-600 hover:underline font-medium"
      >
        View Old Details
      </button>
    </div>
  );
}

// Popup with everything saved about the earlier enquiry/enquiries of the same person
export function OldEnquiryDialog({ enquiry, olds, qrOn, onClose }: {
  enquiry: Enquiry | null; olds: Enquiry[]; qrOn: boolean; onClose: () => void;
}) {
  return (
    <Dialog open={!!enquiry} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><AlertTriangle className="w-5 h-5 text-amber-600" /> Old Enquiry Details</DialogTitle>
        </DialogHeader>
        {enquiry && (
          <div className="space-y-3">
            <p className="text-sm text-gray-600">
              <strong>{enquiry.name}</strong> (+91 {enquiry.phone}) has enquired {olds.length === 1 ? 'once' : `${olds.length} times`} before:
            </p>
            {olds.map((o) => {
              const sec = enquirySection(o, qrOn);
              const st = statusInfo(o.status);
              return (
                <div key={o.id} className="border rounded-lg p-3 bg-[var(--app-bg)]/40 text-sm space-y-1.5">
                  <div className="flex items-center flex-wrap gap-2">
                    <span className="font-semibold">{o.name}</span>
                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${st.chip}`}>{st.short}</span>
                  </div>
                  <div className="text-gray-700">Enquired on: <strong>{formatDateTime(o.createdAt)}</strong></div>
                  <div className="text-gray-700">Enquired about: <strong>{o.course || '-'}</strong></div>
                  <div className="text-gray-600">Source: {o.source || '-'}{o.fromQr ? ' (QR form)' : ''}</div>
                  {o.followUpDate && <div className="text-gray-600">Follow-up date: {formatDateOnly(o.followUpDate)}</div>}
                  {o.followUpNote && <div className="text-gray-600 italic">📝 {o.followUpNote}</div>}
                  {o.convertedAt && <div className="text-gray-600">Converted on: {formatDateTime(o.convertedAt)}</div>}
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-gray-700">Now in:</span>
                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${sec.cls}`}>{sec.label}</span>
                  </div>
                </div>
              );
            })}
            <Button variant="outline" className="w-full" onClick={onClose}>Close</Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
