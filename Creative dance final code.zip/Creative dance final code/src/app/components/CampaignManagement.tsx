import { useState, useEffect, type ReactNode } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Button } from './ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { CalendarCheck, TrendingDown, ClipboardList, QrCode, MessageCircle, Megaphone, RotateCw, Lock, IndianRupee, CalendarClock, UserX, FileText, Save, Trash2, Plus, AlertCircle } from 'lucide-react';
import { getAllStudents, getAllBatches, getAllCampaignTemplates, saveCampaignTemplate, deleteCampaignTemplate } from '../lib/indexedDB';
import { useBusinessName } from '../contexts/BusinessContext';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import {
  getDuesTemplate, saveDuesTemplate, DEFAULT_DUES_TEMPLATE, DUES_PLACEHOLDERS,
  getExpiryTemplate, saveExpiryTemplate, DEFAULT_EXPIRY_TEMPLATE,
  getExpiredTemplate, saveExpiredTemplate, DEFAULT_EXPIRED_TEMPLATE, EXPIRY_PLACEHOLDERS,
  getAbsentTemplate, saveAbsentTemplate, DEFAULT_ABSENT_TEMPLATE, ABSENT_PLACEHOLDERS,
  getZeroTemplate, saveZeroTemplate, DEFAULT_ZERO_TEMPLATE, ZERO_PLACEHOLDERS,
  getAttendanceDuesTemplate, saveAttendanceDuesTemplate,
  getAttendanceExpiryTemplate, saveAttendanceExpiryTemplate,
} from '../lib/reminderMessages';
import {
  getEnquiryTemplate, saveEnquiryTemplate, DEFAULT_ENQUIRY_TEMPLATES, ENQUIRY_PLACEHOLDERS,
} from '../lib/enquiries';
import { toast } from 'sonner';

// Ready-made preset templates — always available, not editable/deletable,
// just a quick starting point the admin can tap to load into the Message box.
const PRESET_CAMPAIGN_TEMPLATES: { name: string; message: string }[] = [
  {
    name: 'Batch Reminder',
    message: 'प्रिय Students,\nकल आपकी class समय पर शुरू होगी। कृपया समय पर पहुंचें।\nधन्यवाद!'
  },
  {
    name: 'Fee Due Notice',
    message: 'प्रिय Students,\nआपकी इस माह की फीस अभी बकाया है। कृपया जल्द से जल्द जमा करें।\nधन्यवाद!'
  },
  {
    name: 'Holiday Notice',
    message: 'सूचना: कल Academy बंद रहेगी। अगली class सामान्य समय पर होगी।\nधन्यवाद!'
  },
  {
    name: 'New Batch / Offer',
    message: 'खुशखबरी! नया बैच शुरू हो रहा है — अभी admission लें और special offer पाएं!\nअधिक जानकारी के लिए संपर्क करें।'
  },
];

export function CampaignManagement() {
  const [message, setMessage] = useState('');
  const [batches, setBatches] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [selectedBatchTime, setSelectedBatchTime] = useState('');
  // Reg Nos that a message has already been sent to in this session — their button turns gray
  const [sentRegNos, setSentRegNos] = useState<Set<string>>(new Set());

  // Admin's own saved custom message templates (device/CMS data — included in JSON backup)
  const [customTemplates, setCustomTemplates] = useState<any[]>([]);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [newTemplateName, setNewTemplateName] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingTemplate, setDeletingTemplate] = useState<any>(null);

  const { matchesLocation, selectedLocation } = useLocationFilter();
  // Campaign stays mounted (hidden) — reload + reset the picked batch when the location changes
  useEffect(() => { setSelectedBatchTime(''); loadData(); }, [selectedLocation]);

  const loadData = async () => {
    const [batchesData, studentsData, templatesData] = await Promise.all([
      getAllBatches(), getAllStudents(), getAllCampaignTemplates()
    ]);
    setBatches(batchesData.filter((b: any) => matchesLocation(b.location)));
    // Only active (non-deactivated) students can be messaged from a campaign
    setStudents(studentsData.filter((s: any) => !s.deactivated && matchesLocation(s.location)));
    setCustomTemplates(templatesData);
  };

  const studentsInBatch = selectedBatchTime
    ? students.filter((s: any) => s.batchTime === selectedBatchTime)
    : [];

  const getStudentCount = (batchTime: string) => students.filter((s: any) => s.batchTime === batchTime).length;

  const handleSendWhatsApp = (student: any) => {
    if (!student.mobile) return;
    const text = encodeURIComponent(message || '');
    window.open(`https://wa.me/91${student.mobile}${text ? `?text=${text}` : ''}`, '_blank');
    setSentRegNos((prev) => new Set(prev).add(student.regNo));
  };

  const handleReload = () => {
    setMessage('');
    setSelectedBatchTime('');
    setSentRegNos(new Set());
    loadData();
  };

  const handleOpenSaveDialog = () => {
    if (!message.trim()) {
      toast.error('Pehle message likhein, phir template save karein!');
      return;
    }
    setNewTemplateName('');
    setShowSaveDialog(true);
  };

  const handleSaveTemplate = async () => {
    if (!newTemplateName.trim()) {
      toast.error('Template ka naam dalein!');
      return;
    }
    const template = {
      id: `tmpl_${Date.now()}`,
      name: newTemplateName.trim(),
      message,
      order: Date.now()
    };
    await saveCampaignTemplate(template);
    await loadData();
    setShowSaveDialog(false);
    setNewTemplateName('');
    toast.success('Template saved!');
  };

  const handleDeleteClick = (template: any) => {
    setDeletingTemplate(template);
    setShowDeleteConfirm(true);
  };

  const confirmDeleteTemplate = async () => {
    if (!deletingTemplate) return;
    await deleteCampaignTemplate(deletingTemplate.id);
    await loadData();
    setShowDeleteConfirm(false);
    setDeletingTemplate(null);
    toast.success('Template deleted!');
  };

  return (
    <div className="p-6">
      <Tabs defaultValue="batch" className="space-y-4">
        <Card className="overflow-hidden">
        <TabsList className="w-full grid grid-cols-4 h-auto rounded-none">
          <TabsTrigger value="batch" className="flex items-center gap-1.5 py-2.5"><Megaphone className="w-4 h-4" /> Batch Messaging</TabsTrigger>
          <TabsTrigger value="reminders" className="flex items-center gap-1.5 py-2.5"><MessageCircle className="w-4 h-4" /> Auto Reminders</TabsTrigger>
          <TabsTrigger value="enquiry" className="flex items-center gap-1.5 py-2.5"><ClipboardList className="w-4 h-4" /> Enquiry Messages</TabsTrigger>
          <TabsTrigger value="attendance" className="flex items-center gap-1.5 py-2.5"><CalendarCheck className="w-4 h-4" /> Attendance Messages</TabsTrigger>
        </TabsList>
        </Card>

        <TabsContent value="batch">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Megaphone className="w-5 h-5" />
                  Campaign
                </CardTitle>
                <Button size="sm" variant="outline" onClick={handleReload} className="flex items-center gap-1">
                  <RotateCw className="w-3.5 h-3.5" />
                  Reload
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Templates */}
              <div>
                <Label className="flex items-center gap-1.5"><FileText className="w-3.5 h-3.5" /> Templates</Label>
                <p className="text-xs text-gray-500 mt-0.5 mb-2">Tap a template to load it into the message box below.</p>

                <div className="flex flex-wrap gap-1.5 mb-2">
                  {PRESET_CAMPAIGN_TEMPLATES.map((t, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setMessage(t.message)}
                      className="text-xs bg-orange-50 text-orange-700 border border-orange-200 rounded-full px-3 py-1 hover:bg-orange-100"
                    >
                      {t.name}
                    </button>
                  ))}
                </div>

                {customTemplates.length > 0 && (
                  <div className="space-y-1.5 mb-2">
                    <p className="text-xs text-gray-500">My Templates</p>
                    <div className="flex flex-wrap gap-1.5">
                      {customTemplates.map((t: any) => (
                        <span
                          key={t.id}
                          className="flex items-center gap-1 text-xs bg-blue-50 text-blue-700 border border-blue-200 rounded-full pl-3 pr-1 py-1"
                        >
                          <button type="button" onClick={() => setMessage(t.message)} className="hover:underline">
                            {t.name}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteClick(t)}
                            className="text-blue-400 hover:text-red-600 rounded-full p-0.5"
                            title="Delete template"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <Label>Message</Label>
                  <Button size="sm" variant="outline" onClick={handleOpenSaveDialog} className="flex items-center gap-1 h-7 text-xs">
                    <Save className="w-3 h-3" />
                    Save as Template
                  </Button>
                </div>
                <Textarea
                  placeholder="Type the message you want to send..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={4}
                  className="mt-1"
                />
              </div>

              <div>
                <Label>Batch Time</Label>
                <Select value={selectedBatchTime} onValueChange={setSelectedBatchTime}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select a batch" />
                  </SelectTrigger>
                  <SelectContent>
                    {batches.map((batch: any, i: number) => (
                      <SelectItem key={i} value={batch.batchTime}>
                        {batch.batchTime} — {batch.batchName} ({getStudentCount(batch.batchTime)} students)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedBatchTime && (
                <div className="border rounded-lg overflow-hidden">
                  <div className="bg-orange-50 px-4 py-2 text-sm font-medium">
                    Students in this batch ({studentsInBatch.length})
                  </div>
                  {studentsInBatch.length === 0 ? (
                    <p className="text-center text-gray-500 py-6 text-sm">No students in this batch</p>
                  ) : (
                    <div className="divide-y max-h-96 overflow-y-auto">
                      {studentsInBatch.map((student: any) => (
                        <div key={student.regNo} className="flex items-center justify-between px-4 py-3">
                          <div>
                            <p className="font-medium">{student.name}</p>
                            <p className="text-xs text-gray-500">Reg No: {student.regNo} • {student.mobile || 'No mobile'}</p>
                          </div>
                          <Button
                            size="sm"
                            disabled={!student.mobile}
                            onClick={() => handleSendWhatsApp(student)}
                            className={`flex items-center gap-1 text-white ${
                              sentRegNos.has(student.regNo)
                                ? 'bg-gray-400 hover:bg-gray-500'
                                : 'bg-green-600 hover:bg-green-700'
                            }`}
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            {sentRegNos.has(student.regNo) ? 'Sent' : 'Send'}
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reminders">
          <AutoReminderTemplates />
        </TabsContent>

        <TabsContent value="enquiry">
          <EnquiryMessageTemplates />
        </TabsContent>

        <TabsContent value="attendance">
          <AttendanceMessageTemplates />
        </TabsContent>
      </Tabs>

      {/* Save Template Dialog */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Plus className="w-4 h-4" /> Save as Template</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Template Name</Label>
              <Input
                value={newTemplateName}
                onChange={(e) => setNewTemplateName(e.target.value)}
                placeholder="e.g. Diwali Offer"
                className="mt-1"
                autoFocus
              />
            </div>
            <p className="text-xs text-gray-500">
              Ye template aapke device par save ho jayega aur JSON backup/restore ke saath automatically export-import ho jayega.
            </p>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowSaveDialog(false)} className="flex-1">Cancel</Button>
              <Button onClick={handleSaveTemplate} className="flex-1 bg-orange-600 hover:bg-orange-700 text-white">Save</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Template Confirmation */}
      <Dialog open={showDeleteConfirm} onOpenChange={(open) => { setShowDeleteConfirm(open); if (!open) setDeletingTemplate(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Delete Template</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-yellow-50 border border-yellow-300 rounded">
              <p className="text-sm text-yellow-800">
                Are you sure you want to delete <strong>{deletingTemplate?.name}</strong>?
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => { setShowDeleteConfirm(false); setDeletingTemplate(null); }} className="flex-1">Cancel</Button>
              <Button onClick={confirmDeleteTemplate} className="flex-1 bg-red-600 hover:bg-red-700 text-white">Yes, Delete</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================================
// Auto Reminder Templates — Dues / Expiry Soon / Expired
// ============================================================================

function AutoReminderTemplates() {
  const { businessName } = useBusinessName();

  return (
    <div className="space-y-4">
      <p className="text-sm text-gray-600">
        Sent via the "Remind" button for Dues, Expiry Soon, and Expired lists. Editable message—Business Name is automatically added from settings.
      </p>

      <ReminderTemplateCard
        icon={<IndianRupee className="w-4 h-4" />}
        title="Dues Reminder"
        subtitle="Students with pending Admission or Monthly dues"
        placeholders={DUES_PLACEHOLDERS}
        businessName={businessName}
        defaultTemplate={DEFAULT_DUES_TEMPLATE}
        getTemplate={getDuesTemplate}
        saveTemplate={saveDuesTemplate}
      />

      <ReminderTemplateCard
        icon={<CalendarClock className="w-4 h-4" />}
        title="Expiry Soon Reminder"
        subtitle="Students whose package expires within 5 days"
        placeholders={EXPIRY_PLACEHOLDERS}
        businessName={businessName}
        defaultTemplate={DEFAULT_EXPIRY_TEMPLATE}
        getTemplate={getExpiryTemplate}
        saveTemplate={saveExpiryTemplate}
      />

      <ReminderTemplateCard
        icon={<UserX className="w-4 h-4" />}
        title="Expired Students Reminder"
        subtitle="Students whose package has already expired"
        placeholders={EXPIRY_PLACEHOLDERS}
        businessName={businessName}
        defaultTemplate={DEFAULT_EXPIRED_TEMPLATE}
        getTemplate={getExpiredTemplate}
        saveTemplate={saveExpiredTemplate}
      />
    </div>
  );
}

// ============================================================================
// Enquiry Messages — WhatsApp messages used in the Enquiry section
// ============================================================================

function EnquiryMessageTemplates() {
  const { businessName } = useBusinessName();
  return (
    <div className="space-y-4">
      <p className="text-sm text-gray-600">
        Used for the WhatsApp button in the Enquiry section. Custom text allowed—<span className="font-mono text-xs bg-orange-50 border border-orange-200 rounded px-1">{'{{studentName}}'}</span>, <span className="font-mono text-xs bg-orange-50 border border-orange-200 rounded px-1">{'{{course}}'}</span>, and <span className="font-mono text-xs bg-orange-50 border border-orange-200 rounded px-1">{'{{studioName}}'}</span> automatically fill in.
      </p>

      <ReminderTemplateCard
        icon={<Plus className="w-4 h-4" />}
        title="Add Enquiry Message"
        subtitle="Enquiry save karte hi student ko jaata hai (thank-you message)"
        placeholders={ENQUIRY_PLACEHOLDERS}
        businessName={businessName}
        showSignature={false}
        defaultTemplate={DEFAULT_ENQUIRY_TEMPLATES.add}
        getTemplate={() => getEnquiryTemplate('add')}
        saveTemplate={(t) => saveEnquiryTemplate('add', t)}
      />

      <ReminderTemplateCard
        icon={<ClipboardList className="w-4 h-4" />}
        title="Enquiry List Message"
        subtitle='Enquiry List me "WA" button dabane par jaata hai'
        placeholders={ENQUIRY_PLACEHOLDERS}
        businessName={businessName}
        showSignature={false}
        defaultTemplate={DEFAULT_ENQUIRY_TEMPLATES.list}
        getTemplate={() => getEnquiryTemplate('list')}
        saveTemplate={(t) => saveEnquiryTemplate('list', t)}
      />

      <ReminderTemplateCard
        icon={<CalendarClock className="w-4 h-4" />}
        title="Follow-Up Message"
        subtitle='Follow-Up me "WA Message" button dabane par jaata hai'
        placeholders={ENQUIRY_PLACEHOLDERS}
        businessName={businessName}
        showSignature={false}
        defaultTemplate={DEFAULT_ENQUIRY_TEMPLATES.followup}
        getTemplate={() => getEnquiryTemplate('followup')}
        saveTemplate={(t) => saveEnquiryTemplate('followup', t)}
      />

      <ReminderTemplateCard
        icon={<QrCode className="w-4 h-4" />}
        title="QR Enquiry Message"
        subtitle='QR Enquiry tab me "WhatsApp" button dabane par jaata hai'
        placeholders={ENQUIRY_PLACEHOLDERS}
        businessName={businessName}
        showSignature={false}
        defaultTemplate={DEFAULT_ENQUIRY_TEMPLATES.qr}
        getTemplate={() => getEnquiryTemplate('qr')}
        saveTemplate={(t) => saveEnquiryTemplate('qr', t)}
      />
    </div>
  );
}

// ============================================================================
// Attendance Messages — message sent to absent students from Reports
// ============================================================================

function AttendanceMessageTemplates() {
  const { businessName } = useBusinessName();
  return (
    <div className="space-y-4">
      <p className="text-sm text-gray-600">
        Sent via Attendance Reports and Dues WhatsApp buttons. Fully editable—Business Name auto-attaches to the end.
      </p>

      <ReminderTemplateCard
        icon={<UserX className="w-4 h-4" />}
        title="Absent Student Message"
        subtitle="Reports → Today ka Report me absent student ke saamne send button dabane par jaata hai"
        placeholders={ABSENT_PLACEHOLDERS}
        businessName={businessName}
        defaultTemplate={DEFAULT_ABSENT_TEMPLATE}
        getTemplate={getAbsentTemplate}
        saveTemplate={saveAbsentTemplate}
      />

      <ReminderTemplateCard
        icon={<IndianRupee className="w-4 h-4" />}
        title="Admission Dues Message"
        subtitle="Attendance → Admission Dues ke saamne WhatsApp button dabane par jaata hai (jab tak aap badlein nahi, CMS ke Dues Reminder jaisa hi rehta hai)"
        placeholders={DUES_PLACEHOLDERS}
        businessName={businessName}
        defaultTemplate={DEFAULT_DUES_TEMPLATE}
        getTemplate={() => getAttendanceDuesTemplate('admission')}
        saveTemplate={(t) => saveAttendanceDuesTemplate('admission', t)}
      />

      <ReminderTemplateCard
        icon={<IndianRupee className="w-4 h-4" />}
        title="Monthly Dues Message"
        subtitle="Attendance → Monthly Dues ke saamne WhatsApp button dabane par jaata hai (jab tak aap badlein nahi, CMS ke Dues Reminder jaisa hi rehta hai)"
        placeholders={DUES_PLACEHOLDERS}
        businessName={businessName}
        defaultTemplate={DEFAULT_DUES_TEMPLATE}
        getTemplate={() => getAttendanceDuesTemplate('monthly')}
        saveTemplate={(t) => saveAttendanceDuesTemplate('monthly', t)}
      />

      <ReminderTemplateCard
        icon={<AlertCircle className="w-4 h-4" />}
        title="Expiry Soon Message"
        subtitle="Attendance → Expiry column me WhatsApp button (jab expiry me 5 din ya kam bache) dabane par jaata hai (jab tak aap badlein nahi, Dashboard ke Expiry Soon reminder jaisa hi rehta hai)"
        placeholders={EXPIRY_PLACEHOLDERS}
        businessName={businessName}
        defaultTemplate={DEFAULT_EXPIRY_TEMPLATE}
        getTemplate={() => getAttendanceExpiryTemplate('soon')}
        saveTemplate={(t) => saveAttendanceExpiryTemplate('soon', t)}
      />

      <ReminderTemplateCard
        icon={<AlertCircle className="w-4 h-4" />}
        title="Expired Students Message"
        subtitle="Attendance → Expiry column me WhatsApp button (jab expiry ho chuki ho) dabane par jaata hai (jab tak aap badlein nahi, Dashboard ke Expired reminder jaisa hi rehta hai)"
        placeholders={EXPIRY_PLACEHOLDERS}
        businessName={businessName}
        defaultTemplate={DEFAULT_EXPIRED_TEMPLATE}
        getTemplate={() => getAttendanceExpiryTemplate('expired')}
        saveTemplate={(t) => saveAttendanceExpiryTemplate('expired', t)}
      />

      <ReminderTemplateCard
        icon={<TrendingDown className="w-4 h-4" />}
        title="0% Attendance Message"
        subtitle='Reports → "0% This Month" list me "Message" button dabane par jaata hai (jisne mahine me ek bhi class nahi li)'
        placeholders={ZERO_PLACEHOLDERS}
        businessName={businessName}
        defaultTemplate={DEFAULT_ZERO_TEMPLATE}
        getTemplate={getZeroTemplate}
        saveTemplate={saveZeroTemplate}
      />
    </div>
  );
}

function ReminderTemplateCard({
  icon, title, subtitle, placeholders, businessName, defaultTemplate, getTemplate, saveTemplate, showSignature = true,
}: {
  icon: ReactNode;
  title: string;
  subtitle: string;
  placeholders: string[];
  businessName: string;
  defaultTemplate: string;
  getTemplate: () => Promise<string>;
  saveTemplate: (text: string) => Promise<void>;
  // Auto Reminders always sign with the Business Name; Enquiry messages use {{studioName}} inside the text instead
  showSignature?: boolean;
}) {
  const [text, setText] = useState('');
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    getTemplate().then((t) => { setText(t); setLoaded(true); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSave = async () => {
    await saveTemplate(text);
    toast.success(`${title} saved!`);
  };

  const handleReset = () => setText(defaultTemplate);

  if (!loaded) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          {icon} {title}
        </CardTitle>
        <p className="text-xs text-gray-500">{subtitle}</p>
      </CardHeader>
      <CardContent className="space-y-3">
        <div>
          <Label>Message</Label>
          <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={4} className="mt-1" />
        </div>

        <div className="flex flex-wrap gap-1.5">
          {placeholders.map((p) => (
            <span key={p} className="text-[11px] font-mono bg-orange-50 text-orange-700 border border-orange-200 rounded px-1.5 py-0.5">
              {p}
            </span>
          ))}
        </div>

        {/* Business name is locked — always auto-appended, never editable here */}
        {showSignature && <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-md px-3 py-2 text-sm text-gray-600">
          <Lock className="w-3.5 h-3.5 flex-shrink-0" />
          <span>Signed automatically as: <strong className="text-gray-800">{businessName}</strong></span>
        </div>}

        <div className="flex gap-2">
          <Button size="sm" onClick={handleSave} className="bg-orange-600 hover:bg-orange-700 text-white">Save</Button>
          <Button size="sm" variant="outline" onClick={handleReset}>Reset to Default</Button>
        </div>
      </CardContent>
    </Card>
  );
}
