import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner';
import { Plus, Trash2, Edit, FileText, MessageCircle, AlertTriangle, CheckCircle2, Percent, IndianRupee, X, CalendarPlus, History, CalendarClock } from 'lucide-react';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from './ui/alert-dialog';
import { getAllEvents, saveEvent, deleteEvent } from '../lib/indexedDB';
import { useBusinessName } from '../contexts/BusinessContext';
import { buildBrandingHeader, buildBrandingFooter, printDocument } from '../lib/printReceipt';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
interface EventService {
  id: string;
  name: string;
  startDate: string;
  days: string;
  trainers: string[];
}

interface EventPayment {
  id: string;
  amount: number;
  date: string;
  mode: string;
  note?: string;
}

interface EventForm {
  id?: string;
  name: string;
  date: string;
  company: string;
  contact: string;
  address: string;
  services: EventService[];
  totalAmount: string;
  discountEnabled: boolean;
  discountType: 'percent' | 'amount';
  discountValue: string;
  paidAmount: string; // only used while creating (becomes payment #1)
  paymentMode: string;
}

const PAYMENT_MODES = ['Cash', 'UPI', 'Bank'];

// ---------------------------------------------------------------------------
// Date + money helpers (all dates are 'YYYY-MM-DD' strings, handled in local time)
// ---------------------------------------------------------------------------
const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const parseDate = (s: string) => {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
};

const toStr = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

// 1 day event => ends the same day. N days => start + (N-1)
const calcEndDate = (start: string, days: string | number) => {
  const n = Number(days);
  if (!start || !n || n < 1) return '';
  const d = parseDate(start);
  d.setDate(d.getDate() + n - 1);
  return toStr(d);
};

const fmtDate = (s?: string) => (s ? parseDate(s).toLocaleDateString('en-GB') : '-');
const money = (n: number) => `₹${(Math.round(n * 100) / 100).toLocaleString('en-IN')}`;
const esc = (s: any) =>
  String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const calcTotals = (e: {
  totalAmount: any; discountEnabled?: boolean; discountType?: string; discountValue?: any; payments?: EventPayment[]; paidAmount?: any;
}) => {
  const total = Number(e.totalAmount) || 0;
  let discount = 0;
  if (e.discountEnabled) {
    const v = Number(e.discountValue) || 0;
    discount = e.discountType === 'percent' ? (total * v) / 100 : v;
  }
  discount = Math.min(Math.max(discount, 0), total);
  const net = total - discount;
  const paid = e.payments
    ? e.payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0)
    : Number(e.paidAmount) || 0;
  const dues = Math.max(0, net - paid);
  return { total, discount, net, paid, dues };
};

const getStatus = (ev: any): 'upcoming' | 'ongoing' | 'completed' => {
  const t = todayStr();
  if (ev.endDate < t) return 'completed';
  if (ev.date <= t) return 'ongoing';
  return 'upcoming';
};

const newId = (p: string) => `${p}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

const emptyForm = (): EventForm => ({
  name: '', date: '', company: '', contact: '', address: '',
  services: [emptyService('', '1')],
  totalAmount: '', discountEnabled: false, discountType: 'percent', discountValue: '',
  paidAmount: '', paymentMode: 'Cash',
});

function emptyService(date: string, days: string): EventService {
  return { id: newId('SRV'), name: '', startDate: date, days, trainers: [''] };
}

// Event ends when its last service ends. Event days = date .. end date (inclusive).
const calcEventSpan = (date: string, services: { startDate: string; days: string | number }[]) => {
  let end = date || '';
  for (const s of services) {
    const e = calcEndDate(s.startDate, s.days);
    if (e && (!end || e > end)) end = e;
  }
  const days = date && end ? Math.round((parseDate(end).getTime() - parseDate(date).getTime()) / 86400000) + 1 : 0;
  return { endDate: end, days };
};

// ---------------------------------------------------------------------------
// Event form (used for both "Create" and "Edit")
// ---------------------------------------------------------------------------
function EventFormFields({
  form, setForm, isEdit, existingPaid,
}: {
  form: EventForm; setForm: (f: EventForm) => void; isEdit: boolean; existingPaid: number;
}) {
  const set = (patch: Partial<EventForm>) => setForm({ ...form, ...patch });
  const span = calcEventSpan(form.date, form.services);

  const totals = calcTotals({
    totalAmount: form.totalAmount,
    discountEnabled: form.discountEnabled,
    discountType: form.discountType,
    discountValue: form.discountValue,
    paidAmount: isEdit ? existingPaid : form.paidAmount,
  });

  const updateService = (id: string, patch: Partial<EventService>) =>
    set({ services: form.services.map((s) => (s.id === id ? { ...s, ...patch } : s)) });

  // When the event date is picked, services that have no start date yet follow it
  const changeDate = (date: string) =>
    set({ date, services: form.services.map((s) => (s.startDate ? s : { ...s, startDate: date })) });

  // Service amount is automatic: Total Amount split equally across services
  const perService = form.services.length ? totals.total / form.services.length : 0;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label>Event Name *</Label>
          <Input value={form.name} onChange={(e) => set({ name: e.target.value })} placeholder="Event name" />
        </div>
        <div>
          <Label>Date *</Label>
          <Input type="date" value={form.date} onChange={(e) => changeDate(e.target.value)} />
        </div>
        <div>
          <Label>Company / Organization</Label>
          <Input value={form.company} onChange={(e) => set({ company: e.target.value })} placeholder="Company / Organization name" />
        </div>
        <div>
          <Label>Contact No *</Label>
          <Input
            value={form.contact}
            onChange={(e) => set({ contact: e.target.value.replace(/\D/g, '').slice(0, 10) })}
            placeholder="10-digit mobile"
            maxLength={10}
          />
        </div>
        <div className="md:col-span-2">
          <Label>Address</Label>
          <Input value={form.address} onChange={(e) => set({ address: e.target.value })} placeholder="Address" />
        </div>
      </div>

      {/* Service (mandatory) — days are set here */}
      <div className="border rounded-lg p-3 bg-orange-50/50 space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <Label className="text-base">Service *</Label>
          {span.endDate && (
            <span className="text-xs text-gray-600">
              Event: {fmtDate(form.date)} → {fmtDate(span.endDate)} ({span.days} day{span.days > 1 ? 's' : ''})
            </span>
          )}
        </div>

        {form.services.map((s, idx) => (
          <div key={s.id} className="bg-white border rounded-lg p-3 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">Service {idx + 1}</span>
              {form.services.length > 1 && (
                <Button type="button" size="sm" variant="outline" onClick={() => set({ services: form.services.filter((x) => x.id !== s.id) })}>
                  <Trash2 className="w-3 h-3 text-red-500" />
                </Button>
              )}
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="col-span-2 md:col-span-4">
                <Label>Service Name</Label>
                <Input value={s.name} onChange={(e) => updateService(s.id, { name: e.target.value })} placeholder="Service name" />
              </div>
              <div>
                <Label>Start Date</Label>
                <Input type="date" value={s.startDate} onChange={(e) => updateService(s.id, { startDate: e.target.value })} />
              </div>
              <div>
                <Label>Days</Label>
                <Input
                  type="number"
                  min={1}
                  value={s.days}
                  onChange={(e) => updateService(s.id, { days: e.target.value.replace(/\D/g, '') })}
                />
              </div>
              <div>
                <Label>End Date</Label>
                <div className="h-9 px-3 flex items-center rounded-md bg-gray-100 text-gray-700 text-sm">
                  {fmtDate(calcEndDate(s.startDate, s.days))}
                </div>
              </div>
              <div>
                <Label>Amount</Label>
                <div className="h-9 px-3 flex items-center rounded-md bg-gray-100 text-gray-700 text-sm">{money(perService)}</div>
              </div>
              <div className="col-span-2 md:col-span-4">
                <Label>Trainer / Artist</Label>
                <div className="space-y-2">
                  {s.trainers.map((t, i) => (
                    <div key={i} className="flex gap-2">
                      <Input
                        value={t}
                        onChange={(e) =>
                          updateService(s.id, { trainers: s.trainers.map((x, j) => (j === i ? e.target.value : x)) })
                        }
                        placeholder="Trainer / artist name"
                      />
                      {s.trainers.length > 1 && (
                        <Button
                          type="button" size="sm" variant="outline"
                          onClick={() => updateService(s.id, { trainers: s.trainers.filter((_, j) => j !== i) })}
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button
                    type="button" size="sm" variant="ghost" className="text-orange-600 h-7 px-1"
                    onClick={() => updateService(s.id, { trainers: [...s.trainers, ''] })}
                  >
                    <Plus className="w-3 h-3 mr-1" />Add trainer
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}

        <Button type="button" size="sm" variant="outline" onClick={() => set({ services: [...form.services, emptyService(form.date, '1')] })}>
          <Plus className="w-3 h-3 mr-1" />Add another service
        </Button>
      </div>

      {/* Amounts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label>Total Amount *</Label>
          <Input
            type="number"
            min={0}
            value={form.totalAmount}
            onChange={(e) => set({ totalAmount: e.target.value })}
            placeholder="Total amount"
          />
        </div>

        <div>
          <Label>Discount <span className="text-xs text-gray-500">(optional)</span></Label>
          {!form.discountEnabled ? (
            <Button type="button" variant="outline" className="w-full" onClick={() => set({ discountEnabled: true })}>
              <Plus className="w-4 h-4 mr-2" />Add Discount
            </Button>
          ) : (
            <div className="flex gap-2">
              <div className="flex rounded-md border overflow-hidden shrink-0">
                <button
                  type="button"
                  onClick={() => set({ discountType: 'percent' })}
                  className={`px-3 flex items-center gap-1 text-sm ${form.discountType === 'percent' ? 'bg-orange-500 text-white' : 'bg-white'}`}
                >
                  <Percent className="w-3 h-3" />%
                </button>
                <button
                  type="button"
                  onClick={() => set({ discountType: 'amount' })}
                  className={`px-3 flex items-center gap-1 text-sm ${form.discountType === 'amount' ? 'bg-orange-500 text-white' : 'bg-white'}`}
                >
                  <IndianRupee className="w-3 h-3" />Amount
                </button>
              </div>
              <Input
                type="number"
                min={0}
                value={form.discountValue}
                onChange={(e) => set({ discountValue: e.target.value })}
                placeholder={form.discountType === 'percent' ? 'Discount %' : 'Discount amount'}
              />
              <Button type="button" variant="outline" onClick={() => set({ discountEnabled: false, discountValue: '' })}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}
          {form.discountEnabled && totals.discount > 0 && (
            <p className="text-xs text-green-700 mt-1">Discount: {money(totals.discount)} → Payable: {money(totals.net)}</p>
          )}
        </div>

        {isEdit ? (
          <div>
            <Label>Paid Amount</Label>
            <div className="h-9 px-3 flex items-center rounded-md bg-gray-100 text-gray-700">{money(existingPaid)}</div>
            <p className="text-xs text-gray-500 mt-1">Naya payment "Payments" button se add karein.</p>
          </div>
        ) : (
          <div>
            <Label>Paid Amount</Label>
            <Input
              type="number"
              min={0}
              value={form.paidAmount}
              onChange={(e) => set({ paidAmount: e.target.value })}
              placeholder="Amount received now"
            />
          </div>
        )}

        <div>
          <Label>Dues Amount</Label>
          <div className={`h-9 px-3 flex items-center rounded-md font-semibold ${totals.dues > 0 ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-700'}`}>
            {money(totals.dues)}
          </div>
        </div>

        {!isEdit && (
          <div>
            <Label>Payment Mode</Label>
            <Select value={form.paymentMode} onValueChange={(v) => set({ paymentMode: v })}>
              <SelectTrigger><SelectValue placeholder="Select mode" /></SelectTrigger>
              <SelectContent>
                {PAYMENT_MODES.map((m) => (<SelectItem key={m} value={m}>{m}</SelectItem>))}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------
export function EventsManagement() {
  const { businessName, businessLogo, businessAddress, businessPhone } = useBusinessName();
  const [events, setEvents] = useState<any[]>([]);
  const [tab, setTab] = useState('create');
  const [search, setSearch] = useState('');

  const [form, setForm] = useState<EventForm>(emptyForm());
  const [saving, setSaving] = useState(false);

  const [editing, setEditing] = useState<any>(null);
  const [editForm, setEditForm] = useState<EventForm>(emptyForm());

  const [deleteTarget, setDeleteTarget] = useState<any>(null);

  const [savedEvent, setSavedEvent] = useState<any>(null); // shows PDF/WhatsApp after saving

  const [payEvent, setPayEvent] = useState<any>(null);
  const [payForm, setPayForm] = useState({ amount: '', date: todayStr(), mode: 'Cash', note: '' });

  useEffect(() => { loadEvents(); }, []);

  const loadEvents = async () => {
    const data = await getAllEvents();
    setEvents(data);
    // keep open dialogs in sync with fresh data
    setPayEvent((cur: any) => (cur ? data.find((e: any) => e.id === cur.id) || null : cur));
  };

  // ---- derived lists ------------------------------------------------------
  const upcoming = useMemo(
    () => events.filter((e) => getStatus(e) !== 'completed').sort((a, b) => a.date.localeCompare(b.date)),
    [events]
  );
  const history = useMemo(() => {
    const q = search.trim().toLowerCase();
    return events
      .filter((e) => getStatus(e) === 'completed')
      .filter((e) => !q || [e.name, e.company, e.contact].some((v) => String(v || '').toLowerCase().includes(q)))
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [events, search]);
  const unpaid = useMemo(() => events.filter((e) => e.dues > 0).sort((a, b) => a.date.localeCompare(b.date)), [events]);
  const totalUnpaid = unpaid.reduce((s, e) => s + e.dues, 0);

  // ---- build the record to store -------------------------------------------
  const validate = (f: EventForm, existingPaid: number) => {
    if (!f.name.trim()) return 'Event name daalein';
    if (!f.date) return 'Event date select karein';
    if (f.contact.length !== 10) return 'Valid 10-digit contact number daalein';
    if (!Number(f.totalAmount) || Number(f.totalAmount) <= 0) return 'Total amount daalein';
    if (f.services.length === 0) return 'Kam se kam ek service add karein';
    for (const s of f.services) {
      if (!s.name.trim()) return 'Service name daalein';
      if (!s.startDate) return 'Service ki start date select karein';
      if (!Number(s.days) || Number(s.days) < 1) return 'Service ke days daalein (minimum 1)';
    }
    const t = calcTotals({
      totalAmount: f.totalAmount, discountEnabled: f.discountEnabled, discountType: f.discountType,
      discountValue: f.discountValue, paidAmount: existingPaid,
    });
    if (f.discountEnabled && f.discountType === 'percent' && Number(f.discountValue) > 100) return 'Discount 100% se zyada nahi ho sakta';
    if (f.discountEnabled && f.discountType === 'amount' && Number(f.discountValue) > t.total) return 'Discount total amount se zyada nahi ho sakta';
    if (t.paid > t.net) return 'Paid amount payable amount se zyada nahi ho sakta';
    return '';
  };

  const buildRecord = (f: EventForm, base?: any) => {
    const span = calcEventSpan(f.date, f.services);
    const payments: EventPayment[] = base?.payments ? [...base.payments] : [];
    if (!base && Number(f.paidAmount) > 0) {
      payments.push({ id: newId('PAY'), amount: Number(f.paidAmount), date: todayStr(), mode: f.paymentMode, note: 'Initial payment' });
    }
    const t = calcTotals({
      totalAmount: f.totalAmount, discountEnabled: f.discountEnabled, discountType: f.discountType,
      discountValue: f.discountValue, payments,
    });
    return {
      id: base?.id || newId('EVT'),
      invoiceNo: base?.invoiceNo || `INV-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`,
      createdAt: base?.createdAt || new Date().toISOString(),
      name: f.name.trim(),
      date: f.date,
      company: f.company.trim(),
      contact: f.contact,
      address: f.address.trim(),
      days: span.days,
      endDate: span.endDate,
      services: f.services.map((s) => ({
        id: s.id, name: s.name.trim(), startDate: s.startDate, days: Number(s.days),
        endDate: calcEndDate(s.startDate, s.days),
        trainers: s.trainers.map((x) => x.trim()).filter(Boolean),
      })),
      totalAmount: t.total,
      discountEnabled: f.discountEnabled && t.discount > 0,
      discountType: f.discountType,
      discountValue: Number(f.discountValue) || 0,
      discountAmount: t.discount,
      netAmount: t.net,
      payments,
      paidAmount: t.paid,
      dues: t.dues,
    };
  };

  const handleCreate = async () => {
    const err = validate(form, Number(form.paidAmount) || 0);
    if (err) { toast.error(err); return; }
    setSaving(true);
    try {
      const record = buildRecord(form);
      await saveEvent(record);
      await loadEvents();
      setSavedEvent(record);
      setForm(emptyForm());
      toast.success('Event saved!');
    } catch (e) {
      console.error(e);
      toast.error('Event save nahi ho paaya');
    } finally {
      setSaving(false);
    }
  };

  const openEdit = (ev: any) => {
    setEditing(ev);
    setEditForm({
      id: ev.id, name: ev.name, date: ev.date, company: ev.company || '', contact: ev.contact,
      address: ev.address || '',
      // older events saved without a service get one built from the event itself
      services: (ev.services || []).length > 0
        ? ev.services.map((s: any) => ({
            id: s.id, name: s.name, startDate: s.startDate, days: String(s.days),
            trainers: s.trainers && s.trainers.length ? s.trainers : [''],
          }))
        : [{ id: newId('SRV'), name: ev.name, startDate: ev.date, days: String(ev.days || 1), trainers: [''] }],
      totalAmount: String(ev.totalAmount),
      discountEnabled: !!ev.discountEnabled,
      discountType: ev.discountType || 'percent',
      discountValue: ev.discountValue ? String(ev.discountValue) : '',
      paidAmount: '', paymentMode: 'Cash',
    });
  };

  const handleEditSave = async () => {
    if (!editing) return;
    const err = validate(editForm, editing.paidAmount);
    if (err) { toast.error(err); return; }
    try {
      const record = buildRecord(editForm, editing);
      await saveEvent(record);
      await loadEvents();
      setEditing(null);
      toast.success('Event updated!');
    } catch (e) {
      console.error(e);
      toast.error('Update fail ho gaya');
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteEvent(deleteTarget.id);
      setPayEvent((cur: any) => (cur && cur.id === deleteTarget.id ? null : cur));
      setDeleteTarget(null);
      await loadEvents();
      toast.success('Event delete ho gaya');
    } catch (e) {
      console.error(e);
      toast.error('Event delete nahi ho paaya');
    }
  };

  // ---- payments ------------------------------------------------------------
  const openPayments = (ev: any) => {
    setPayEvent(ev);
    setPayForm({ amount: '', date: todayStr(), mode: 'Cash', note: '' });
  };

  const handleAddPayment = async () => {
    if (!payEvent) return;
    const amt = Number(payForm.amount);
    if (!amt || amt <= 0) { toast.error('Amount daalein'); return; }
    if (amt > payEvent.dues) { toast.error(`Amount dues (${money(payEvent.dues)}) se zyada nahi ho sakta`); return; }
    const payments = [...(payEvent.payments || []), {
      id: newId('PAY'), amount: amt, date: payForm.date, mode: payForm.mode, note: payForm.note.trim(),
    }];
    const paid = payments.reduce((s: number, p: any) => s + p.amount, 0);
    const updated = { ...payEvent, payments, paidAmount: paid, dues: Math.max(0, payEvent.netAmount - paid) };
    try {
      await saveEvent(updated);
      await loadEvents();
      setPayForm({ amount: '', date: todayStr(), mode: 'Cash', note: '' });
      toast.success(updated.dues === 0 ? 'Payment complete! Event fully paid.' : 'Payment added!');
    } catch (e) {
      console.error(e);
      toast.error('Payment save nahi hua');
    }
  };

  // ---- invoice PDF + WhatsApp ------------------------------------------------
  const handleInvoice = async (ev: any) => {
    const payments: EventPayment[] = [...(ev.payments || [])].sort((a, b) => a.date.localeCompare(b.date));
    const statusText = ev.dues <= 0 ? 'PAID' : ev.paidAmount > 0 ? 'PARTIALLY PAID' : 'UNPAID';
    const statusColor = ev.dues <= 0 ? '#16a34a' : '#dc2626';
    const perService = (ev.services || []).length ? ev.totalAmount / ev.services.length : 0;

    const serviceRows = (ev.services || []).length
      ? ev.services.map((s: any, i: number) => `<tr>
          <td>${i + 1}</td><td>${esc(s.name)}</td><td>${fmtDate(s.startDate)}</td><td>${s.days}</td>
          <td>${fmtDate(s.endDate)}</td><td>${esc((s.trainers || []).join(', ') || '-')}</td>
          <td style="text-align:right">${money(perService)}</td></tr>`).join('')
      : `<tr><td>1</td><td>${esc(ev.name)}</td><td>${fmtDate(ev.date)}</td><td>${ev.days}</td>
          <td>${fmtDate(ev.endDate)}</td><td>-</td><td style="text-align:right">${money(ev.totalAmount)}</td></tr>`;

    const paymentRows = payments.length
      ? payments.map((p, i) => `<tr><td>${i + 1}</td><td>${fmtDate(p.date)}</td><td>${esc(p.mode)}</td>
          <td>${esc(p.note || '-')}</td><td style="text-align:right">${money(p.amount)}</td></tr>`).join('')
      : `<tr><td colspan="5" style="text-align:center;color:#888">No payment received yet</td></tr>`;

    const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
    <style>
      body{font-family:Arial,sans-serif;padding:28px;color:#222;font-size:11pt;}
      .header{background:#E8630A;padding:15px;text-align:center;color:white;border-radius:6px;}
      table{width:100%;border-collapse:collapse;margin-top:10px;}
      th,td{border:1px solid #ddd;padding:7px;text-align:left;font-size:10pt;}
      th{background:#FCE6D4;}
      .meta{display:flex;justify-content:space-between;gap:20px;margin-top:16px;}
      .box{flex:1;border:1px solid #ddd;border-radius:6px;padding:10px;font-size:10pt;line-height:1.6;}
      .box h4{margin:0 0 6px 0;color:#E8630A;}
      .totals{width:320px;margin-left:auto;margin-top:12px;}
      .totals td{border:none;border-bottom:1px solid #eee;}
      h3{margin:18px 0 0 0;color:#E8630A;font-size:12pt;}
    </style></head><body>
    ${buildBrandingHeader({ businessName, businessLogo, businessAddress }, 'INVOICE')}
    <div class="meta">
      <div class="box">
        <h4>Billed To</h4>
        <b>${esc(ev.company || ev.name)}</b><br/>
        Contact: ${esc(ev.contact)}<br/>
        ${ev.address ? `Address: ${esc(ev.address)}` : ''}
      </div>
      <div class="box">
        <h4>Invoice Details</h4>
        Invoice No: <b>${esc(ev.invoiceNo)}</b><br/>
        Invoice Date: ${fmtDate(ev.createdAt.slice(0, 10))}<br/>
        Event: <b>${esc(ev.name)}</b><br/>
        Event Date: ${fmtDate(ev.date)} to ${fmtDate(ev.endDate)} (${ev.days} day${ev.days > 1 ? 's' : ''})<br/>
        Status: <b style="color:${statusColor}">${statusText}</b>
      </div>
    </div>

    <h3>Services</h3>
    <table>
      <tr><th>#</th><th>Description</th><th>Start Date</th><th>Days</th><th>End Date</th><th>Trainer / Artist</th><th style="text-align:right">Amount</th></tr>
      ${serviceRows}
    </table>

    <table class="totals">
      <tr><td>Total Amount</td><td style="text-align:right">${money(ev.totalAmount)}</td></tr>
      ${ev.discountAmount > 0 ? `<tr><td>Discount${ev.discountType === 'percent' ? ` (${ev.discountValue}%)` : ''}</td><td style="text-align:right">- ${money(ev.discountAmount)}</td></tr>` : ''}
      <tr><td><b>Net Payable</b></td><td style="text-align:right"><b>${money(ev.netAmount)}</b></td></tr>
      <tr><td>Paid Amount</td><td style="text-align:right;color:#16a34a">${money(ev.paidAmount)}</td></tr>
      <tr><td><b>Balance Due</b></td><td style="text-align:right;color:${ev.dues > 0 ? '#dc2626' : '#16a34a'}"><b>${money(ev.dues)}</b></td></tr>
    </table>

    <h3>Payment History</h3>
    <table>
      <tr><th>#</th><th>Date</th><th>Mode</th><th>Note</th><th style="text-align:right">Amount</th></tr>
      ${paymentRows}
    </table>

    ${buildBrandingFooter({ businessName, businessPhone }, 'payment')}
    </body></html>`;

    await printDocument(html, `${ev.name}_Invoice`);
  };

  // Only opens the client's WhatsApp chat — admin sends the downloaded PDF manually
  const handleWhatsApp = (ev: any) => {
    window.open(`https://wa.me/91${ev.contact}`, '_blank');
  };

  // ---- shared table ----------------------------------------------------------
  const renderTable = (list: any[], emptyText: string) => (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Event</TableHead>
            <TableHead>Client</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Days</TableHead>
            <TableHead>Total</TableHead>
            <TableHead>Discount</TableHead>
            <TableHead>Paid</TableHead>
            <TableHead>Dues</TableHead>
            <TableHead>Payment</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {list.length > 0 ? list.map((ev) => {
            const st = getStatus(ev);
            return (
              <TableRow key={ev.id}>
                <TableCell>
                  <div className="font-medium">{ev.name}</div>
                  {(ev.services || []).length > 0 && (
                    <div className="text-xs text-gray-500">{ev.services.map((s: any) => s.name).join(', ')}</div>
                  )}
                  {st === 'ongoing' && <span className="text-xs bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded">Ongoing</span>}
                </TableCell>
                <TableCell>
                  <div>{ev.company || '-'}</div>
                  <div className="text-xs text-gray-500">{ev.contact}</div>
                </TableCell>
                <TableCell>
                  {fmtDate(ev.date)}
                  {ev.days > 1 && <div className="text-xs text-gray-500">to {fmtDate(ev.endDate)}</div>}
                </TableCell>
                <TableCell>{ev.days}</TableCell>
                <TableCell>{money(ev.totalAmount)}</TableCell>
                <TableCell>{ev.discountAmount > 0 ? money(ev.discountAmount) : '-'}</TableCell>
                <TableCell className="text-green-700">{money(ev.paidAmount)}</TableCell>
                <TableCell className={ev.dues > 0 ? 'text-red-600 font-semibold' : ''}>{money(ev.dues)}</TableCell>
                <TableCell>
                  {ev.dues > 0 ? (
                    <Button size="sm" className="bg-red-500 hover:bg-red-600 text-white h-7" onClick={() => openPayments(ev)}>
                      Unpaid
                    </Button>
                  ) : (
                    <button
                      onClick={() => openPayments(ev)}
                      className="inline-flex items-center gap-1 text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full"
                      title="Payment history"
                    >
                      <CheckCircle2 className="w-3 h-3" />Paid
                    </button>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex flex-col gap-1 items-start">
                    <div className="flex gap-1">
                      <Button size="sm" variant="outline" onClick={() => openEdit(ev)} title="Edit"><Edit className="w-3 h-3" /></Button>
                      <Button size="sm" variant="outline" onClick={() => handleInvoice(ev)} title="Invoice PDF"><FileText className="w-3 h-3 text-blue-600" /></Button>
                      <Button size="sm" variant="outline" onClick={() => handleWhatsApp(ev)} title="WhatsApp"><MessageCircle className="w-3 h-3 text-green-600" /></Button>
                    </div>
                    <Button size="sm" variant="outline" className="border-red-300 text-red-600 hover:bg-red-50" onClick={() => setDeleteTarget(ev)} title="Delete">
                      <Trash2 className="w-3 h-3 mr-1" />Delete
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            );
          }) : (
            <TableRow><TableCell colSpan={10} className="text-center text-gray-500 py-8">{emptyText}</TableCell></TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl">Events</h1>

      {/* Unpaid alert — always on top so admin can collect pending payments */}
      {unpaid.length > 0 && (
        <Card className="border-red-300 bg-red-50">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-red-700 text-base">
              <AlertTriangle className="w-5 h-5" />
              Unpaid Events ({unpaid.length}) — Total Dues {money(totalUnpaid)}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {unpaid.map((ev) => (
                <div key={ev.id} className="flex items-center justify-between gap-3 bg-white rounded-lg px-3 py-2 border border-red-100">
                  <div className="min-w-0">
                    <div className="font-medium truncate">{ev.name} <span className="text-xs text-gray-500">({fmtDate(ev.date)})</span></div>
                    <div className="text-xs text-gray-500">{ev.company || 'Client'} • {ev.contact}</div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-red-600 font-semibold">{money(ev.dues)}</span>
                    <Button size="sm" variant="outline" onClick={() => handleWhatsApp(ev)} title="WhatsApp"><MessageCircle className="w-3 h-3 text-green-600" /></Button>
                    <Button size="sm" className="bg-red-500 hover:bg-red-600 text-white" onClick={() => openPayments(ev)}>Receive</Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="w-full grid grid-cols-3 h-auto rounded-none">
          <TabsTrigger value="create" className="flex items-center gap-1.5 py-2.5"><CalendarPlus className="w-4 h-4" /> Create Events</TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-1.5 py-2.5"><History className="w-4 h-4" /> Events History ({events.filter((e) => getStatus(e) === 'completed').length})</TabsTrigger>
          <TabsTrigger value="upcoming" className="flex items-center gap-1.5 py-2.5"><CalendarClock className="w-4 h-4" /> Upcoming Events ({upcoming.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="create">
          <Card>
            <CardHeader><CardTitle>Create Event</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <EventFormFields form={form} setForm={setForm} isEdit={false} existingPaid={0} />
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setForm(emptyForm())}>Clear</Button>
                <Button onClick={handleCreate} disabled={saving}>{saving ? 'Saving...' : 'Save Event'}</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center gap-3">
                <CardTitle>Events History</CardTitle>
                <Input className="max-w-xs" placeholder="Search name / company / contact" value={search} onChange={(e) => setSearch(e.target.value)} />
              </div>
            </CardHeader>
            <CardContent>{renderTable(history, 'Abhi tak koi event complete nahi hua')}</CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upcoming">
          <Card>
            <CardHeader><CardTitle>Upcoming Events</CardTitle></CardHeader>
            <CardContent>{renderTable(upcoming, 'Koi upcoming event nahi hai')}</CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Event delete karein?</AlertDialogTitle>
            <AlertDialogDescription>
              Kya aap sach mein is event ko delete karna chahte hain?
              {deleteTarget ? ` (${deleteTarget.name})` : ''}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-500 hover:bg-red-600 text-white" onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* After save: invoice + WhatsApp */}
      <Dialog open={!!savedEvent} onOpenChange={(o) => !o && setSavedEvent(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle>Event Saved</DialogTitle></DialogHeader>
          {savedEvent && (
            <div className="space-y-4">
              <div className="text-sm space-y-1 bg-orange-50 rounded-lg p-3">
                <div><b>{savedEvent.name}</b> — {savedEvent.company || 'Client'}</div>
                <div>Date: {fmtDate(savedEvent.date)} to {fmtDate(savedEvent.endDate)}</div>
                <div>Total: {money(savedEvent.totalAmount)} | Paid: {money(savedEvent.paidAmount)} | Dues: <span className={savedEvent.dues > 0 ? 'text-red-600 font-semibold' : ''}>{money(savedEvent.dues)}</span></div>
              </div>
              <p className="text-xs text-gray-500">Pehle PDF download karein, phir WhatsApp chat kholkar client ko manually bhej dein.</p>
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" onClick={() => handleInvoice(savedEvent)}><FileText className="w-4 h-4 mr-2 text-blue-600" />Invoice PDF</Button>
                <Button className="bg-[#25D366] hover:bg-[#1fb857] text-white" onClick={() => handleWhatsApp(savedEvent)}><MessageCircle className="w-4 h-4 mr-2" />WhatsApp</Button>
              </div>
              <Button className="w-full" variant="ghost" onClick={() => { setSavedEvent(null); setTab('upcoming'); }}>Upcoming Events dekhein</Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit dialog */}
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="sm:max-w-4xl w-[95vw] max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Edit Event</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-4">
              <EventFormFields form={editForm} setForm={setEditForm} isEdit existingPaid={editing.paidAmount} />
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
                <Button onClick={handleEditSave}>Save Changes</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Payments dialog: collect dues + full history */}
      <Dialog open={!!payEvent} onOpenChange={(o) => !o && setPayEvent(null)}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Payments — {payEvent?.name}</DialogTitle></DialogHeader>
          {payEvent && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-2 text-center text-sm">
                <div className="bg-gray-50 rounded-lg p-2"><div className="text-gray-500 text-xs">Payable</div><div className="font-semibold">{money(payEvent.netAmount)}</div></div>
                <div className="bg-green-50 rounded-lg p-2"><div className="text-gray-500 text-xs">Paid</div><div className="font-semibold text-green-700">{money(payEvent.paidAmount)}</div></div>
                <div className={`${payEvent.dues > 0 ? 'bg-red-50' : 'bg-green-50'} rounded-lg p-2`}><div className="text-gray-500 text-xs">Dues</div><div className={`font-semibold ${payEvent.dues > 0 ? 'text-red-600' : 'text-green-700'}`}>{money(payEvent.dues)}</div></div>
              </div>

              <div>
                <Label className="mb-2 block">Payment History</Label>
                <div className="border rounded-lg divide-y text-sm">
                  {(payEvent.payments || []).length > 0 ? payEvent.payments.map((p: EventPayment, i: number) => (
                    <div key={p.id} className="flex items-center justify-between px-3 py-2">
                      <div>
                        <div className="font-medium">
                          {i === 0 ? '1st' : i === 1 ? '2nd' : i === 2 ? '3rd' : `${i + 1}th`} payment • {fmtDate(p.date)}
                        </div>
                        <div className="text-xs text-gray-500">{p.mode}{p.note ? ` • ${p.note}` : ''}</div>
                      </div>
                      <div className="font-semibold text-green-700">{money(p.amount)}</div>
                    </div>
                  )) : (
                    <div className="px-3 py-4 text-center text-gray-500">Abhi tak koi payment nahi hua</div>
                  )}
                </div>
              </div>

              {payEvent.dues > 0 ? (
                <div className="border rounded-lg p-3 space-y-3 bg-orange-50/50">
                  <Label className="text-base">Receive Payment</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label>Amount *</Label>
                      <Input type="number" min={0} value={payForm.amount} onChange={(e) => setPayForm({ ...payForm, amount: e.target.value })} placeholder={`Max ${money(payEvent.dues)}`} />
                    </div>
                    <div>
                      <Label>Date</Label>
                      <Input type="date" value={payForm.date} onChange={(e) => setPayForm({ ...payForm, date: e.target.value })} />
                    </div>
                    <div>
                      <Label>Payment Mode</Label>
                      <Select value={payForm.mode} onValueChange={(v) => setPayForm({ ...payForm, mode: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>{PAYMENT_MODES.map((m) => (<SelectItem key={m} value={m}>{m}</SelectItem>))}</SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Note</Label>
                      <Input value={payForm.note} onChange={(e) => setPayForm({ ...payForm, note: e.target.value })} placeholder="Optional" />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setPayForm({ ...payForm, amount: String(payEvent.dues) })}>Full Dues</Button>
                    <Button className="flex-1" onClick={handleAddPayment}>Add Payment</Button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-green-700 bg-green-50 rounded-lg p-3 text-sm">
                  <CheckCircle2 className="w-4 h-4" />Payment complete — koi dues baaki nahi hai.
                </div>
              )}

              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={() => handleInvoice(payEvent)}><FileText className="w-4 h-4 mr-2 text-blue-600" />Invoice PDF</Button>
                <Button variant="outline" className="flex-1" onClick={() => handleWhatsApp(payEvent)}><MessageCircle className="w-4 h-4 mr-2 text-green-600" />WhatsApp</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
