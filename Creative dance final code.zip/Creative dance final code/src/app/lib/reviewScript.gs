/* =========================================================
 *  GOOGLE REVIEW  (QR  ->  review page  ->  Google Review link)
 *  Ye hissa attendance script ke saath jud kar chalta hai (same script, same URL).
 *  Public link:  <web app url>?page=review
 *
 *  Flow:
 *   1) CMS apna config bhejta hai (action 'rev_config'): ON/OFF, Google Review link, keywords, Groq key.
 *      Ye sab Script Properties me rehta hai - Google Sheet ke cells me kuch nahi likha jata.
 *   2) Student QR scan karta hai -> star + keywords chunta hai -> revGenerate() Groq se chhota, naya review banata hai
 *      (key sirf yahin server par rehti hai, page / student ko kabhi nahi dikhti).
 *   3) Groq na chale / limit lag jaye to keywords se bana chhota template review dikhta hai (page khali nahi rehta).
 *   4) Student review edit karke Submit dabata hai -> text copy hota hai aur Google Review link khulta hai.
 *
 *  Sab naye functions / variables ka naam rev... / REV_... se shuru hota hai, taaki attendance / admission /
 *  enquiry ke naam se na takraein.
 *
 *  NAYI PERMISSION: Is hisse ko Groq se baat karne ke liye "UrlFetchApp" chahiye. Pehli baar code paste karne ke baad
 *  Apps Script me function list se  revAuthorize  chuno -> Run -> Allow karo. Uske baad Deploy -> Manage deployments
 *  -> Edit -> New version -> Deploy.
 * ========================================================= */

var REV_GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';
var REV_GROQ_MODELS_URL = 'https://api.groq.com/openai/v1/models';
var REV_MODELS = ['llama-3.1-8b-instant', 'llama-3.3-70b-versatile']; // pehla na chale to doosra try hota hai
var REV_RATE_PER_MIN = 25;     // poore page par ek minute me max AI review (Groq free limit ke andar)
var REV_DAY_CAP = 1500;        // poore din me max AI review; usse zyada par template review milta hai
var REV_SID_CAP = 12;          // ek student (page session) 30 minute me max itni baar review bana sakta hai
var REV_MAX_KEYWORDS = 20;     // admin ke max keywords
var REV_PICK_MAX = 6;          // student max itne keywords chun sakta hai
var REV_HTML = __REV_HTML__;

/* ---------------------------------------------------------
 *  CONFIG  (Script Properties: 'revCfg' = ON/OFF + link + keywords,  'revKey' = Groq key)
 * --------------------------------------------------------- */
function revStr_(v, max) {
  var s = String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
  return s.slice(0, max);
}

function revEmptyCfg_() { return { open: false, link: '', keywords: [] }; }

function revCfg_() {
  var cache = CacheService.getScriptCache();
  var c = cache.get('revcfg');
  if (c) { try { return JSON.parse(c); } catch (e) {} }
  var cfg = revEmptyCfg_();
  try {
    var raw = PropertiesService.getScriptProperties().getProperty('revCfg');
    if (raw) cfg = JSON.parse(raw);
  } catch (e) {}
  try { cache.put('revcfg', JSON.stringify(cfg), 300); } catch (e) {}
  return cfg;
}

function revKey_() {
  var cache = CacheService.getScriptCache();
  var c = cache.get('revkey');
  if (c !== null) return c === 'none' ? '' : c;
  var k = PropertiesService.getScriptProperties().getProperty('revKey') || '';
  try { cache.put('revkey', k || 'none', 600); } catch (e) {}
  return k;
}

function revValidLink_(link) {
  return /^https:\/\/[^\s]+$/i.test(link) && link.length <= 500;
}

function revSaveConfig_(body) {
  var link = revStr_(body.link, 500);
  if (link && !revValidLink_(link)) return { success: false, error: 'Google Review link https:// se shuru hona chahiye.' };

  var keywords = [];
  var seen = {};
  var src = body.keywords || [];
  for (var i = 0; i < src.length && keywords.length < REV_MAX_KEYWORDS; i++) {
    var k = revStr_(src[i], 40);
    if (k && !seen[k.toLowerCase()]) { seen[k.toLowerCase()] = true; keywords.push(k); }
  }

  var props = PropertiesService.getScriptProperties();
  props.setProperty('revCfg', JSON.stringify({ open: body.open === true, link: link, keywords: keywords }));
  CacheService.getScriptCache().remove('revcfg');

  // Groq key: nayi aayi to badal do, clearKey aaye to hata do, kuch na aaye to purani key rehti hai
  if (body.clearKey === true) {
    props.deleteProperty('revKey');
    CacheService.getScriptCache().remove('revkey');
  } else if (typeof body.groqKey === 'string' && body.groqKey.trim()) {
    var key = body.groqKey.trim();
    if (!/^[A-Za-z0-9_\-]{20,200}$/.test(key)) return { success: false, error: 'Groq key ka format sahi nahi hai.' };
    props.setProperty('revKey', key);
    CacheService.getScriptCache().remove('revkey');
  }
  return { success: true, hasKey: !!revKey_() };
}

/* ---------------------------------------------------------
 *  PUBLIC PAGE  (google.script.run se: revInit, revGenerate)
 *  Ye functions koi bhi chala sakta hai, isliye inme sirf public cheezein hain (key kabhi nahi).
 * --------------------------------------------------------- */
function revPage_() {
  return HtmlService.createHtmlOutput(REV_HTML)
    .setTitle('Review')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function revInit() {
  var cfg = revCfg_();
  var base = getConfigCached_();
  var open = cfg.open === true && !!cfg.link;
  if (!open) return { open: false, businessName: base.businessName, logo: getLogoCached_() };
  return { open: true, businessName: base.businessName, logo: getLogoCached_(), link: cfg.link, keywords: cfg.keywords, pickMax: REV_PICK_MAX };
}

// Student ke chune hue keywords me se sirf wahi lete hain jo admin ki list me hain
function revPickKeywords_(picked, allowed) {
  var out = [];
  var low = {};
  for (var i = 0; i < allowed.length; i++) low[allowed[i].toLowerCase()] = allowed[i];
  var src = (picked && picked.length) ? picked : [];
  for (var j = 0; j < src.length && out.length < REV_PICK_MAX; j++) {
    var m = low[String(src[j]).toLowerCase()];
    if (m && out.indexOf(m) < 0) out.push(m);
  }
  if (out.length === 0 && allowed.length > 0) {
    // kuch nahi chuna: admin ki list me se 3 random
    var pool = allowed.slice();
    while (out.length < 3 && pool.length > 0) out.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
  }
  return out;
}

function revGenerate(data) {
  try {
    var cfg = revCfg_();
    if (!cfg.open || !cfg.link) return { ok: false, message: 'Review page abhi band hai.' };
    if (!data || typeof data !== 'object') return { ok: false, message: 'Request sahi nahi hai.' };
    var stars = Math.round(Number(data.stars));
    if (!(stars >= 1 && stars <= 5)) return { ok: false, message: 'Star chunein.' };

    var cache = CacheService.getScriptCache();
    var sid = String(data.sid || '').replace(/[^a-zA-Z0-9]/g, '').slice(0, 24) || 'anon';
    var sk = 'revsid_' + sid;
    var used = Number(cache.get(sk) || 0);
    if (used >= REV_SID_CAP) return { ok: false, message: 'Aapne kaafi review bana liye. Inme se kisi ko edit karke use karein.' };
    cache.put(sk, String(used + 1), 1800);

    var kws = revPickKeywords_(data.keywords, cfg.keywords);
    var biz = getConfigCached_().businessName || 'this place';
    var text = '';
    var source = 'ai';

    var key = revKey_();
    if (key && revAllowAi_(cache)) {
      try { text = revAi_(key, stars, kws, biz, revRecent_()); } catch (e) { text = ''; }
    }
    if (!text) { text = revFallback_(stars, kws, biz); source = 'template'; }
    revRemember_(text);
    return { ok: true, text: text, source: source };
  } catch (err) {
    return { ok: false, message: 'Kuch gadbad ho gayi. Dobara try karein.' };
  }
}

// Minute aur din ki limit (bot / spam se Groq ki limit khatam na ho)
function revAllowAi_(cache) {
  var minKey = 'revrate_' + Math.floor(Date.now() / 60000);
  var n = Number(cache.get(minKey) || 0);
  if (n >= REV_RATE_PER_MIN) return false;
  var dayKey = 'revday_' + today_();
  var d = Number(cache.get(dayKey) || 0);
  if (d >= REV_DAY_CAP) return false;
  cache.put(minKey, String(n + 1), 120);
  cache.put(dayKey, String(d + 1), 86400);
  return true;
}

/* ---------------------------------------------------------
 *  AI (Groq)  - har baar alag review: alag style + pichle reviews ki shuruaat se bachna
 * --------------------------------------------------------- */
var REV_STYLES = [
  'Start by describing how the experience felt.',
  'Start with the first thing you noticed or liked.',
  'Start by mentioning the activity or class you attended.',
  'Start by mentioning the trainers or staff.',
  'Start with a short, simple verdict.',
  'Start by mentioning the atmosphere of the place.',
  'Start with how long or why you chose this place.'
];

// Business name har review me ek baar aata hai (kabhi shuruaat me, kabhi chhoti tareef ki line me, kabhi beech me)
var REV_BIZ_POS = [
  'Mention the business name once inside a short praise line, like "<business> is the best place for <keyword>" or "<business> gives really good <keyword>".',
  'Begin the review with the business name.',
  'Mention the business name once in the middle of the review, naturally.',
  'End the review with a short line praising the business by name, like "Thank you <business>, keep it up."',
  'Mention the business name once, as in "I am happy with <business>".'
];
var REV_BIZ_NEUTRAL = [
  'Mention the business name once, naturally.',
  'Begin the review with the business name.',
  'Mention the business name once in the middle of the review.'
];

var REV_TONES = {
  5: 'Warm and enthusiastic. The customer is very happy.',
  4: 'Positive and satisfied. May include one small honest nuance, but no complaint.',
  3: 'Balanced and honest: some good things and some things that could be better.',
  2: 'Polite but disappointed. Say some things need improvement. No insults.',
  1: 'Unhappy but respectful and factual. Say the experience did not meet expectations. No insults, no false accusations.'
};

function revAi_(key, stars, kws, biz, recent) {
  var system = 'You write short, natural Google reviews that a real customer could post. Rules: '
    + 'first person, as a customer; simple everyday English; 4 to 5 sentences, between 80 and 90 words in total; '
    + 'always mention the business name exactly once, exactly as given; weave the given keywords in naturally and never list them; '
    + 'do not invent facts such as staff names, prices, dates or offers; '
    + 'no emojis, no hashtags, no quotation marks, no markdown; output only the review text.';
  var user = 'Business: ' + biz + '\n'
    + 'Star rating: ' + stars + ' out of 5\n'
    + 'Tone: ' + REV_TONES[stars] + '\n'
    + 'Keywords (topics of the review): ' + (kws.length ? kws.join(', ') : 'general experience') + '\n'
    + 'Style: ' + REV_STYLES[Math.floor(Math.random() * REV_STYLES.length)] + '\n'
    + 'Business name: ' + (stars >= 4 ? REV_BIZ_POS : REV_BIZ_NEUTRAL)[Math.floor(Math.random() * (stars >= 4 ? REV_BIZ_POS : REV_BIZ_NEUTRAL).length)] + '\n'
    + (recent.length ? 'Do not start with the same opening words as any of these: ' + recent.join(' | ') + '\n' : '')
    + 'Random seed: ' + Math.floor(Math.random() * 100000);

  for (var m = 0; m < REV_MODELS.length; m++) {
    var res = UrlFetchApp.fetch(REV_GROQ_URL, {
      method: 'post',
      contentType: 'application/json',
      headers: { Authorization: 'Bearer ' + key },
      muteHttpExceptions: true,
      payload: JSON.stringify({
        model: REV_MODELS[m],
        temperature: 1,
        top_p: 0.95,
        max_tokens: 230,
        messages: [{ role: 'system', content: system }, { role: 'user', content: user }]
      })
    });
    var code = res.getResponseCode();
    if (code === 401 || code === 403) return '';           // key galat / band - doosra model bhi nahi chalega
    if (code !== 200) continue;                            // 429 / model band: agla model
    var out = '';
    try { out = JSON.parse(res.getContentText()).choices[0].message.content; } catch (e) { out = ''; }
    out = revClean_(out);
    if (out) return out;
  }
  return '';
}

function revClean_(t) {
  var s = String(t || '').replace(/[\r\n]+/g, ' ').replace(/[*_`#>]/g, '').replace(/^["'\u201c\u2018]+|["'\u201d\u2019]+$/g, '').replace(/\s+/g, ' ').trim();
  var words = s.split(' ').length;
  if (words < 40 || s.length > 750) return '';   // bahut chhota / bahut lamba ho to agla model ya template
  return s;
}

// Pichle kuch reviews ki shuruaat (cache me) - AI ko batate hain ki inse alag shuru kare
function revRecent_() {
  try { return JSON.parse(CacheService.getScriptCache().get('revrecent') || '[]'); } catch (e) { return []; }
}
function revRemember_(text) {
  try {
    var list = revRecent_();
    list.push(String(text).split(' ').slice(0, 5).join(' '));
    if (list.length > 6) list = list.slice(list.length - 6);
    CacheService.getScriptCache().put('revrecent', JSON.stringify(list), 3600);
  } catch (e) {}
}

/* ---------------------------------------------------------
 *  TEMPLATE REVIEW (backup)  - Groq na chale to bhi student ko review milta hai
 * --------------------------------------------------------- */
var REV_PARTS = {
  5: {
    open: [
      'I had a wonderful experience at {biz} and I am really glad I chose this place for my {kw} journey.',
      '{biz} is the best place for {kw}. From the very first day, the whole experience felt welcoming and well organised.',
      'Absolutely loved my time at {biz}. The {kw} sessions are energetic, well planned and genuinely enjoyable every single time.',
      'Highly recommend {biz} to anyone looking for good {kw}. The overall experience has been better than I expected.'
    ],
    mid: [
      'The trainers are patient, friendly and always ready to guide us properly, which makes a big difference in how confident I feel.',
      'The classes are planned really well and the routines keep things fresh, so I never get bored and always look forward to the next session.',
      'The environment is clean, positive and motivating, and everyone is treated with the same care and attention.',
      'I have noticed real improvement in my energy and confidence since I started, and the team supports every step of the way.'
    ],
    close: [
      'Thank you {biz} for such great service. Keep up the amazing work!',
      'Totally worth it and I would happily suggest {biz} to all my friends and family.',
      'Great service, great people and a great atmosphere. Thank you {biz}.'
    ]
  },
  4: {
    open: [
      'I had a good experience at {biz} and I am happy with the {kw} classes so far.',
      '{biz} is a nice place for {kw}. Overall the experience has been positive and I feel satisfied with my decision.',
      'Happy with my time at {biz}. The {kw} sessions are well conducted and the overall vibe is friendly.'
    ],
    mid: [
      'The trainers are helpful and explain things clearly, and the classes are organised in a way that is easy to follow for beginners too.',
      'The environment is clean and positive, and I feel comfortable coming here regularly without any hesitation.',
      'I have seen steady progress in my routine and the team has been supportive whenever I needed any guidance.',
      'The timings and schedule suit me well, and the staff is polite and responsive to questions.'
    ],
    close: [
      'Good service overall and I would recommend {biz} to others.',
      'Looking forward to continuing my classes here. Thank you {biz}.',
      'A solid choice for {kw} and I am quite satisfied.'
    ]
  },
  3: {
    open: [
      'My experience at {biz} was okay overall, with some good points and some areas that can be better.',
      '{biz} offers decent {kw} sessions, though I felt the experience was average and has room to grow.',
      'I had a mixed experience at {biz}. Some parts of the {kw} classes were good while others felt ordinary.'
    ],
    mid: [
      'The trainers are polite and try to help, but I felt a bit more personal attention would make the classes more useful.',
      'The classes are fine and the basics are covered, but better planning and more variety in the sessions would help a lot.',
      'The place is decent and manageable, though a few small things like coordination and timing could be improved.',
      'I can see the potential here, and with some improvements the overall experience can easily become much better.'
    ],
    close: [
      'I hope {biz} works on these points. Average for now.',
      'It was an okay visit and I may give {biz} another try once things improve.',
      'Decent place, but I expected a little more from {biz}.'
    ]
  },
  2: {
    open: [
      'My experience at {biz} was below what I expected, and I was a little disappointed with the {kw} classes.',
      'I wanted to like {biz}, but unfortunately the overall experience did not meet my expectations.',
      'Some things at {biz}, especially the {kw} sessions, need real improvement in my opinion.'
    ],
    mid: [
      'The classes felt rushed and I did not get enough personal guidance, which made it difficult to follow along properly.',
      'Better organisation and clearer communication would make a big difference to the overall experience for everyone.',
      'The sessions did not feel consistent and the quality seemed to vary from one day to another, which was a little frustrating.',
      'I feel that the staff could be more attentive and responsive when students have questions or concerns.'
    ],
    close: [
      'I hope {biz} takes this feedback positively and improves.',
      'There is potential, but it needs work before I can recommend {biz}.',
      'Not the best experience for me, but I wish {biz} all the best.'
    ]
  },
  1: {
    open: [
      'Unfortunately my experience at {biz} did not meet my expectations at all, especially the {kw} classes.',
      'I was not happy with {biz}, and I felt the {kw} sessions needed a lot more effort and care.',
      'My visit to {biz} was disappointing, and I honestly expected much better from the {kw} classes.'
    ],
    mid: [
      'The sessions felt poorly organised and I did not receive the attention or guidance that I was hoping for.',
      'Communication could be much clearer, and I felt my questions needed better answers, which made the whole experience quite frustrating.',
      'The quality of the classes was below my expectations, and it was difficult for me to see real value in the experience.',
      'I think there are several basic things that need to be fixed before students can have a good experience here.'
    ],
    close: [
      'I hope {biz} reviews this feedback and makes improvements.',
      'Sadly, I cannot recommend {biz} at this point.',
      'I would request {biz} to work on these issues seriously.'
    ]
  }
};

function revJoin_(list) {
  if (!list.length) return 'classes';
  if (list.length === 1) return list[0];
  return list.slice(0, -1).join(', ') + ' and ' + list[list.length - 1];
}

function revPick_(arr, skip) {
  var i = Math.floor(Math.random() * arr.length);
  if (skip !== undefined && arr.length > 1) { while (i === skip) i = Math.floor(Math.random() * arr.length); }
  return i;
}

// Opening + 2 alag beech ki lines + closing = lagbhag 70-90 words
function revFallback_(stars, kws, biz) {
  var p = REV_PARTS[stars] || REV_PARTS[5];
  var m1 = revPick_(p.mid);
  var m2 = revPick_(p.mid, m1);
  var t = [p.open[revPick_(p.open)], p.mid[m1], p.mid[m2], p.close[revPick_(p.close)]].join(' ');
  return t.replace(/\{biz\}/g, function () { return biz; }).replace(/\{kw\}/g, function () { return revJoin_(kws); });
}

/* ---------------------------------------------------------
 *  CMS ACTIONS  (ADMIN_KEY ke saath - doGet / doPost me pehle hi check ho chuka hota hai)
 * --------------------------------------------------------- */
function revGet_(p) {
  if (p.action === 'rev_status') {
    var cfg = revCfg_();
    return { success: true, hasKey: !!revKey_(), open: cfg.open === true, hasLink: !!cfg.link };
  }
  // Script se Groq tak raasta khula hai ya nahi (key sahi hai ya nahi) - sirf models ki list maangta hai
  if (p.action === 'rev_test') {
    var key = revKey_();
    if (!key) return { success: true, ok: false, reason: 'nokey' };
    var res = UrlFetchApp.fetch(REV_GROQ_MODELS_URL, { method: 'get', headers: { Authorization: 'Bearer ' + key }, muteHttpExceptions: true });
    var code = res.getResponseCode();
    return { success: true, ok: code === 200, code: code };
  }
  return { success: false, error: 'unknown action' };
}

function revPost_(body) {
  if (body.action === 'rev_config') return revSaveConfig_(body);
  return { success: false, error: 'unknown action' };
}

/* ---------------------------------------------------------
 *  EK BAAR CHALANE KE LIYE  (Apps Script editor me function list se revAuthorize chuno -> Run -> Allow)
 *  Isse script ko Groq se baat karne ki permission mil jati hai.
 * --------------------------------------------------------- */
function revAuthorize() {
  var res = UrlFetchApp.fetch(REV_GROQ_MODELS_URL, { method: 'get', muteHttpExceptions: true });
  return 'OK - permission mil gayi (' + res.getResponseCode() + '). Ab Deploy -> Manage deployments -> New version.';
}
