// Shared helper for all PDF/print outputs (Admission Receipt, Payment Receipt,
// Teacher Payment Report, Student List) so that Business Settings (name, logo,
// address, contact number) show consistently everywhere, and so file names
// are auto-filled with the student/teacher's name when saving.

export interface BrandingInfo {
  businessName: string;
  businessLogo?: string;
  businessAddress?: string;
  businessPhone?: string;
}

// Header shown at the top of every PDF: logo on the side + business name (+ address)
export function buildBrandingHeader(branding: BrandingInfo, subtitle: string): string {
  const { businessName, businessLogo, businessAddress } = branding;
  const logoImg = businessLogo
    ? `<img src="${businessLogo}" alt="Logo" style="width: 56px; height: 56px; object-fit: cover; border-radius: 8px; background: white; margin-right: 14px;" />`
    : '';
  return `
    <div class="header" style="display: flex; align-items: center; justify-content: center; gap: 4px;">
      ${logoImg}
      <div>
        <h1 style="margin:0; color:#ffffff; font-weight:bold;">${businessName}</h1>
        <p style="margin: 5px 0 0 0; color:#ffffff;">${subtitle}</p>
        ${businessAddress ? `<p style="margin: 3px 0 0 0; font-size: 9pt; color:#FFE3CC;">${businessAddress}</p>` : ''}
      </div>
    </div>
  `;
}

// Footer shown at the bottom of every PDF: thank-you line + contact number.
// variant 'enroll' (default) is used everywhere except Payment Receipt, which uses 'payment'.
export function buildBrandingFooter(branding: BrandingInfo, variant: 'enroll' | 'payment' = 'enroll'): string {
  const { businessName, businessPhone } = branding;
  const thankYouLines = variant === 'payment'
    ? `<p style="margin: 0; font-weight: bold; color: #E8630A;">Thank you for your payment</p>
       <p style="margin: 3px 0 0 0; font-weight: bold; color: #333;">${businessName}</p>`
    : `<p style="margin: 0; font-weight: bold; color: #E8630A;">Thank you for enrolling in ${businessName}!</p>`;
  return `
    <div class="footer" style="text-align: center; margin-top: 20px; padding-top: 12px; border-top: 1px solid #eee; font-size: 9.5pt; color: #333;">
      ${thankYouLines}
      ${businessPhone ? `<p style="margin: 4px 0 0 0;">For inquiries, contact: ${businessPhone}</p>` : ''}
    </div>
  `;
}

// Cleans a name so it's safe to use as a file name (no slashes, quotes, etc.)
function safeFileName(name: string): string {
  return (name || 'Document').trim().replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, '_');
}

// Prints/saves the given HTML document. In the desktop (Electron) app this opens
// a native "Save As" dialog with the file name already filled in (e.g. the
// student's name) — no native print dialog with a blank name field. In a
// regular browser it falls back to window.print() with the document title set
// to the same name, which most browsers use to suggest a file name.
export async function printDocument(html: string, suggestedName: string, options?: { fitOnePage?: boolean }): Promise<void> {
  const desktopApp = (window as any).desktopApp;

  if (desktopApp?.isElectron && desktopApp?.printToPDF) {
    const result = await desktopApp.printToPDF(html, safeFileName(suggestedName), options);
    if (!result?.success && !result?.canceled) {
      console.error('printToPDF failed:', result?.error);
    }
    return;
  }

  // Browser fallback
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;
  const titledHtml = html.includes('<title>')
    ? html
    : html.replace('<head>', `<head><title>${safeFileName(suggestedName)}</title>`);
  printWindow.document.write(titledHtml);
  printWindow.document.close();
  printWindow.focus();
  setTimeout(() => {
    printWindow.print();
  }, 250);
}
