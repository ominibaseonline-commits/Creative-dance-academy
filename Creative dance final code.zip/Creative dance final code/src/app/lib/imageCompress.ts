// Student photo auto-compress: har photo ko JPEG me badal ke TARGET size (default 10 KB) ke andar la deta hai.
// Pehle sabse bada (sharp) size try karta hai, jab tak 10 KB se bada ho tab tak dimension + quality kam karta hai.

export const PHOTO_MAX_BYTES = 10 * 1024; // 10 KB

// data URL ka actual byte size (base64 header ke bina)
export function dataUrlBytes(dataUrl: string): number {
  const i = dataUrl.indexOf(',');
  const b64 = i >= 0 ? dataUrl.slice(i + 1) : dataUrl;
  const pad = b64.endsWith('==') ? 2 : b64.endsWith('=') ? 1 : 0;
  return Math.floor((b64.length * 3) / 4) - pad;
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Photo could not be read'));
    img.src = src;
  });
}

function fileToDataUrl(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = () => reject(new Error('Photo could not be read'));
    r.readAsDataURL(file);
  });
}

function render(img: HTMLImageElement, maxDim: number, quality: number): string {
  const w0 = img.naturalWidth || img.width;
  const h0 = img.naturalHeight || img.height;
  const scale = Math.min(1, maxDim / Math.max(w0, h0));
  const w = Math.max(1, Math.round(w0 * scale));
  const h = Math.max(1, Math.round(h0 * scale));
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas not supported');
  ctx.fillStyle = '#fff'; // PNG transparency black na ho jaye
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(img, 0, 0, w, h);
  return canvas.toDataURL('image/jpeg', quality);
}

// Dimension ki list (bade se chhota). Har dimension par best quality dhundhta hai jo target ke andar aaye.
const DIMS = [480, 400, 340, 290, 250, 215, 185, 160, 140, 120];
const Q_MIN = 0.4; // isse neeche quality girne se pehle dimension chhota karte hain (photo saaf rahe)
const Q_MAX = 0.9;

export async function compressPhotoToTarget(input: string | Blob, maxBytes: number = PHOTO_MAX_BYTES, maxDim: number = DIMS[0]): Promise<string> {
  const src = typeof input === 'string' ? input : await fileToDataUrl(input);
  const img = await loadImage(src);

  const dims = DIMS.filter((d) => d <= maxDim);
  if (!dims.length) dims.push(DIMS[DIMS.length - 1]);
  for (const dim of dims) {
    // Is dimension par minimum quality bhi bada hai? To agle chhote dimension par jao
    if (dataUrlBytes(render(img, dim, Q_MIN)) > maxBytes) continue;
    // Binary search: target ke andar sabse achhi quality
    let lo = Q_MIN;
    let hi = Q_MAX;
    let best = render(img, dim, lo);
    for (let i = 0; i < 7; i++) {
      const mid = (lo + hi) / 2;
      const out = render(img, dim, mid);
      if (dataUrlBytes(out) <= maxBytes) { best = out; lo = mid; } else { hi = mid; }
    }
    return best;
  }

  // Last resort: sabse chhota dimension, quality aur kam karte jao
  const smallest = dims[dims.length - 1];
  for (let q = Q_MIN; q >= 0.05; q -= 0.05) {
    const out = render(img, smallest, q);
    if (dataUrlBytes(out) <= maxBytes) return out;
  }
  return render(img, smallest, 0.05);
}
