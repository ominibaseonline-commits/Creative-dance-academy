// Helper function to force re-migration
// Use this if data order is incorrect

export const forceMigration = async () => {
  // Clear migration flag
  localStorage.removeItem('migrated_to_indexeddb');
  
  // Clear IndexedDB
  const DB_NAME = 'MayuriAcademyDB';
  await new Promise<void>((resolve, reject) => {
    const request = indexedDB.deleteDatabase(DB_NAME);
    request.onsuccess = () => {
      console.log('✅ IndexedDB cleared');
      resolve();
    };
    request.onerror = () => {
      console.error('❌ Failed to clear IndexedDB');
      reject(request.error);
    };
  });
  
  console.log('✅ Migration reset complete. Please reload the page.');
  alert('Migration reset complete. Page will reload now.');
  window.location.reload();
};
