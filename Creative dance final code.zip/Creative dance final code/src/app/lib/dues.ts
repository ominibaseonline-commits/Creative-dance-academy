// Admission dues vs Monthly (renewal) dues.
//
//  admissionDues : balance left from the admission payment
//  monthlyDues   : balance left after a fees / renewal payment
//  dues          : always admissionDues + monthlyDues (so every old screen keeps working)
//
// Students saved before this change have no split fields. For them we guess from history:
// no payment record yet => it is still the admission balance, otherwise it is a monthly balance.

export interface DuesSplit {
  admission: number;
  monthly: number;
}

export function splitDues(student: any, hasPayments: boolean): DuesSplit {
  if (student?.admissionDues !== undefined || student?.monthlyDues !== undefined) {
    return {
      admission: Math.max(0, Number(student.admissionDues) || 0),
      monthly: Math.max(0, Number(student.monthlyDues) || 0),
    };
  }
  const d = Math.max(0, Number(student?.dues) || 0);
  return hasPayments ? { admission: 0, monthly: d } : { admission: d, monthly: 0 };
}
