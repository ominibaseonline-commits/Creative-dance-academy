// Flexi classes — for students who attend on alternate days / a fixed number of classes.
// Admin enters only "how many classes". Classes taken ("Li Hui") are counted from the
// attendance records (check-ins) from the day the package was added.
//
//   total  : classes in the package
//   taken  : days with a check-in on/after startDate
//   left   : max(0, total - taken)
//   extra  : max(0, taken - total)  -> shown as "1 extra class" (English)

import { getSetting, saveSetting } from './indexedDB';
import { fetchAttendance, getCachedAttendance, getCachedAttendanceDates } from './attendance';

export interface FlexiPlan {
  regNo: string;
  total: number;
  startDate: string; // YYYY-MM-DD
  updatedAt: string;
}

export interface FlexiUsage {
  total: number;
  taken: number;
  left: number;
  extra: number;
}

const KEY = 'flexiPlans';
const localToday = () => new Date().toLocaleDateString('en-CA');
const norm = (reg: any) => String(reg ?? '').toLowerCase();

export async function getFlexiPlans(): Promise<Record<string, FlexiPlan>> {
  return ((await getSetting(KEY)) || {}) as Record<string, FlexiPlan>;
}

async function savePlans(plans: Record<string, FlexiPlan>) {
  await saveSetting(KEY, plans);
  window.dispatchEvent(new CustomEvent('flexiUpdated'));
}

/** mode "add": classes are added to the running package. mode "new": fresh package starting today. */
export async function saveFlexiPlan(regNo: string, classes: number, mode: 'add' | 'new' = 'new'): Promise<FlexiPlan> {
  const n = Math.max(1, Math.floor(Number(classes) || 0));
  const plans = await getFlexiPlans();
  const key = norm(regNo);
  const old = plans[key];
  const plan: FlexiPlan =
    old && mode === 'add'
      ? { ...old, total: old.total + n, updatedAt: new Date().toISOString() }
      : { regNo: String(regNo), total: n, startDate: localToday(), updatedAt: new Date().toISOString() };
  plans[key] = plan;
  await savePlans(plans);
  return plan;
}

export async function removeFlexiPlan(regNo: string) {
  const plans = await getFlexiPlans();
  delete plans[norm(regNo)];
  await savePlans(plans);
}

export const planFor = (plans: Record<string, FlexiPlan>, regNo: any): FlexiPlan | undefined => plans[norm(regNo)];

/** "3 classes left" / "1 class left" / "0 classes left" / "1 extra class" — always English. */
export function flexiLabel(u: FlexiUsage): { text: string; tone: 'ok' | 'zero' | 'extra' } {
  const s = (n: number) => (n === 1 ? '' : 'es');
  if (u.extra > 0) return { text: `${u.extra} extra class${s(u.extra)}`, tone: 'extra' };
  if (u.left === 0) return { text: '0 classes left', tone: 'zero' };
  return { text: `${u.left} class${s(u.left)} left`, tone: 'ok' };
}

const dayList = (from: string, to: string, cap = 400): string[] => {
  const out: string[] = [];
  const [y, m, d] = from.split('-').map(Number);
  const cur = new Date(y, m - 1, d);
  const end = new Date(to + 'T00:00:00');
  while (cur <= end && out.length < cap) {
    out.push(cur.toLocaleDateString('en-CA'));
    cur.setDate(cur.getDate() + 1);
  }
  return out;
};

/**
 * Classes taken for every flexi student. Uses the attendance already saved on this computer
 * and downloads (once) only the days that are missing since the earliest package started.
 */
export async function computeFlexiUsage(plans: Record<string, FlexiPlan>): Promise<Record<string, FlexiUsage>> {
  const list = Object.values(plans);
  if (list.length === 0) return {};
  const today = localToday();
  const minStart = list.reduce((m, p) => (p.startDate < m ? p.startDate : m), today);
  const days = dayList(minStart, today);

  const have = new Set(await getCachedAttendanceDates());
  const missing = days.filter((d) => !have.has(d));
  const queue = [...missing];
  const worker = async () => {
    while (queue.length) {
      const d = queue.shift()!;
      try { await fetchAttendance(d); } catch { /* offline / not connected: count what we have */ }
    }
  };
  await Promise.all([worker(), worker(), worker()]);

  const byDay: Record<string, Record<string, { checkIn: string }>> = {};
  for (const d of days) {
    const c = await getCachedAttendance(d);
    if (c) byDay[d] = c.records as any;
  }

  const out: Record<string, FlexiUsage> = {};
  list.forEach((p) => {
    let taken = 0;
    days.forEach((d) => {
      if (d < p.startDate) return;
      if (byDay[d]?.[norm(p.regNo)]?.checkIn) taken++;
    });
    out[norm(p.regNo)] = { total: p.total, taken, left: Math.max(0, p.total - taken), extra: Math.max(0, taken - p.total) };
  });
  return out;
}
