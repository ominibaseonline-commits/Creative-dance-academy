/**
 * ============================================================
 *  OMINIBASE CMS — QR ATTENDANCE (Google Apps Script)
 * ============================================================
 *  Ye ek hi script ye saare kaam karti hai:
 *   1) Student ka attendance page (QR scan karke yahi khulta hai)
 *   2) CMS ke saath data sync (students + attendance report)
 *   3) Staff mobile panel  ->  <web app url>?mode=staff  (PIN se khulta hai, CMS se link + PIN milta hai)
 *   4) Online Admission form  ->  <web app url>?page=admission   (CMS: Settings -> Online Admission)
 *   5) QR Enquiry form        ->  <web app url>?page=enquiry     (CMS: Settings -> Enquiry Settings -> QR Enquiry)
 *   6) Event registration form -> <web app url>?page=event&id=<eventId>  (CMS: Settings -> Event Forms, phir Events section)
 *  Teeno extra hisse isi script ke neeche jude hote hain - alag script / alag URL / alag deploy ki zarurat nahi.
 *
 *  SETUP (sirf ek baar):
 *   1. Naya Google Sheet banao  ->  Extensions  ->  Apps Script
 *   2. Is poore code ko paste karo (purana code hata do) -> Save
 *   3. Upar function list se  setupAttendance  chuno -> Run -> permission Allow karo
 *   4. Deploy -> New deployment -> Type: Web app
 *        Execute as : Me
 *        Who has access : Anyone
 *      -> Deploy -> "Web app URL" copy karo
 *   5. CMS -> Settings -> Management & Setup -> neeche Attendance Setup me URL paste karke Connect karo
 *
 *  NOTE: Script me kabhi bhi change karo toh Deploy -> Manage deployments -> Edit -> New version -> Deploy.
 *  NOTE: Sheet sirf beech ka rasta hai. Attendance data sirf 7 din rehta hai (roz raat ko apne aap delete). Poora record CMS ke local storage me rehta hai.
 *        Naye code ke baad setupAttendance ek baar dobara Run karein (roz raat ki safai ka timer banane ke liye).
 * ============================================================
 */

// CMS apne aap yahan secret key bhar deta hai. Ise mat badlo.
var ADMIN_KEY = '__ADMIN_KEY__';

var TZ = 'Asia/Kolkata';
var SHEET_STUDENTS = 'Students';
var SHEET_ATT = 'Attendance';
var SHEET_CFG = 'Config';
var MAX_WRONG = 5;        // itne galat last-4 ke baad lock
var LOCK_SECONDS = 600;   // 10 minute lock
var KEEP_DAYS = 7;        // Google Sheet me attendance sirf itne din rehti hai, usse purana data apne aap delete ho jata hai

var STUDENT_HEADERS = ['RegNo', 'Name', 'Last4', 'Expiry', 'Dues', 'Status', 'Batch', 'Location', 'Category', 'AdmDues', 'MonDues', 'Flexi'];
var ATT_HEADERS = ['Key', 'Date', 'RegNo', 'Name', 'CheckIn', 'CheckOut', 'Batch', 'MarkedBy'];
var NO_BATCH = '__none__';
var STAFF_MAX_WRONG = 10;      // itne galat PIN ke baad staff panel lock
var STAFF_LOCK_SECONDS = 600;  // 10 minute lock

/* ---------------------------------------------------------
 *  SETUP
 * --------------------------------------------------------- */
function setupAttendance() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ensureSheet_(ss, SHEET_STUDENTS, STUDENT_HEADERS);
  ensureSheet_(ss, SHEET_ATT, ATT_HEADERS);
  var cfg = ss.getSheetByName(SHEET_CFG) || ss.insertSheet(SHEET_CFG);
  if (cfg.getLastRow() === 0) cfg.getRange(1, 1, 1, 2).setValues([['Key', 'Value']]);
  cfg.getRange('B:B').setNumberFormat('@');
  try { installCleanupTrigger_(); } catch (e) {} // roz raat purana data hatane ka timer
  return 'OK';
}

function ensureSheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name) || ss.insertSheet(name);
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold');
    sh.setFrozenRows(1);
  } else {
    // Purani sheet me naye columns ke header bhi aa jaayein
    sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold');
  }
  // Sab kuch text format me, taaki 000123 ya dates badle nahi
  sh.getRange(1, 1, sh.getMaxRows(), headers.length).setNumberFormat('@');
  return sh;
}

/* ---------------------------------------------------------
 *  HTTP ENTRY POINTS
 * --------------------------------------------------------- */
function doGet(e) {
  var p = (e && e.parameter) || {};
  if (p.action) {
    if (p.key !== ADMIN_KEY) return json_({ success: false, error: 'unauthorized' });
    try {
      if (p.action === 'ping') return json_({ success: true, version: 1 });
      // Bahut halka check: CMS sirf ye number dekhta hai, list tabhi mangta hai jab ye badla ho
      if (p.action === 'version') return json_({ success: true, attVer: getAttVer_(), subm: submittedList_(today_()) });
      // Live update: "since" ke baad ki sirf nayi check-in/out entries (bahut chhota jawab, ~50ms)
      if (p.action === 'delta') return json_(adminDelta_(Number(p.since) || 0));
      if (p.action === 'list') return json_(adminList_(p.date));
      if (String(p.action).indexOf('adm_') === 0) return json_(admGet_(p)); // ONLINE ADMISSION hook
      if (String(p.action).indexOf('qenq_') === 0) return json_(qenqGet_(p)); // QR ENQUIRY hook
      if (String(p.action).indexOf('rev_') === 0) return json_(revGet_(p)); // GOOGLE REVIEW hook
      if (String(p.action).indexOf('evt_') === 0) return json_(evtGet_(p)); // EVENTS hook
      return json_({ success: false, error: 'unknown action' });
    } catch (err) {
      return json_({ success: false, error: String(err) });
    }
  }
  if (p.page === 'admission') return admPage_(); // ONLINE ADMISSION hook
  if (p.page === 'enquiry') return qenqPage_(); // QR ENQUIRY hook
  if (p.page === 'review') return revPage_(); // GOOGLE REVIEW hook
  if (p.page === 'event') return evtPage_(p.id); // EVENTS hook: ?page=event&id=<eventId>
  if (p.mode === 'staff') {
    return HtmlService.createHtmlOutput(STAFF_HTML)
      .setTitle('Staff Attendance')
      .addMetaTag('viewport', 'width=device-width, initial-scale=1')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }
  return HtmlService.createHtmlOutput(PAGE_HTML)
    .setTitle('Attendance')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function doPost(e) {
  var body;
  try {
    body = JSON.parse(e.postData.contents);
  } catch (err) {
    return json_({ success: false, error: 'bad request' });
  }
  if (!body || body.key !== ADMIN_KEY) return json_({ success: false, error: 'unauthorized' });

  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    if (body.action === 'setup') { setupAttendance(); return json_({ success: true }); }
    if (body.action === 'config') return json_(saveConfig_(body));
    if (body.action === 'sync') return json_(syncStudents_(body));
    if (body.action === 'staff') return json_(saveStaff_(body));
    if (body.action === 'mark') return json_(adminMark_(body));
    if (body.action === 'markout') return json_(adminMarkOut_(body));
    if (body.action === 'submit') return json_(submitBatch_(body));
    if (String(body.action).indexOf('adm_') === 0) return json_(admPost_(body)); // ONLINE ADMISSION hook
    if (String(body.action).indexOf('qenq_') === 0) return json_(qenqPost_(body)); // QR ENQUIRY hook
    if (String(body.action).indexOf('rev_') === 0) return json_(revPost_(body)); // GOOGLE REVIEW hook
    if (String(body.action).indexOf('evt_') === 0) return json_(evtPost_(body)); // EVENTS hook
    return json_({ success: false, error: 'unknown action' });
  } catch (err) {
    return json_({ success: false, error: String(err) });
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/* ---------------------------------------------------------
 *  VERSION COUNTERS (fast reads, kam load)
 *  attVer : har check-in / check-out par +1  -> CMS bina list mange pata kar leta hai kuch naya aaya ya nahi
 *  stVer  : har student sync par badalta hai -> purana cached student data apne aap invalid ho jata hai
 * --------------------------------------------------------- */
var TAIL_ROWS = 6000; // aaj ki entries hamesha sheet ke neeche hoti hain, isliye sirf last rows dhundte hain

// Free Google account me "Properties read/write" ki limit sirf 50,000/din hai.
// Isliye counters ko pehle Cache se padhte hain (Cache par aisi daily limit nahi) aur
// Properties (jo cache saaf hone par bhi bacha rehta hai) sirf likhne / cache miss par chhute hain.
function getProp_(name, fallback) {
  var cache = CacheService.getScriptCache();
  var c = cache.get('p_' + name);
  if (c !== null) return c;
  var v = PropertiesService.getScriptProperties().getProperty(name);
  if (v === null) v = fallback;
  try { cache.put('p_' + name, v, 21600); } catch (e) {}
  return v;
}
function setProp_(name, value) {
  PropertiesService.getScriptProperties().setProperty(name, value);
  try { CacheService.getScriptCache().put('p_' + name, value, 21600); } catch (e) {}
}

function getAttVer_() {
  return Number(getProp_('attVer', '0'));
}
function bumpAttVer_() {
  var next = Number(getProp_('attVer', '0')) + 1;
  setProp_('attVer', String(next));
  return next;
}

// Last kuch events ka chhota log (cache me). CMS isse bina poori list mange nayi entries utha leta hai.
var LOG_MAX = 150;
function logEvent_(ver, regNo, checkIn, checkOut, day) {
  var cache = CacheService.getScriptCache();
  var log = [];
  try { log = JSON.parse(cache.get('attlog') || '[]'); } catch (e) { log = []; }
  log.push({ v: ver, r: String(regNo), i: checkIn || '', o: checkOut || '', d: day || today_() });
  if (log.length > LOG_MAX) log = log.slice(log.length - LOG_MAX);
  try { cache.put('attlog', JSON.stringify(log), 21600); } catch (e) {}
}

function adminDelta_(since) {
  var ver = getAttVer_();
  var subm = submittedList_(today_()); // CMS ko batata hai kaun si batch submit ho chuki hai (staff phone se bhi)
  if (since === ver) return { success: true, attVer: ver, events: [], subm: subm };
  if (since > ver) return { success: true, attVer: ver, full: true, subm: subm };
  var log = [];
  try { log = JSON.parse(CacheService.getScriptCache().get('attlog') || '[]'); } catch (e) { log = []; }
  var evs = log.filter(function (e) { return e.v > since; });
  // Log me har version maujood hona chahiye, warna CMS ko poori list mangni padegi
  if (evs.length !== ver - since) return { success: true, attVer: ver, full: true, subm: subm };
  return { success: true, attVer: ver, events: evs, subm: subm };
}
function getStVer_() {
  return getProp_('stVer', '0');
}
function bumpStVer_() {
  setProp_('stVer', String(new Date().getTime()));
}

// Column ki sirf aakhri maxRows rows (sheet ke absolute rows ke saath)
function tailRange_(sh, col, maxRows) {
  var last = sh.getLastRow();
  var start = Math.max(2, last - maxRows + 1);
  return sh.getRange(start, col, last - start + 1, 1);
}

/* ---------------------------------------------------------
 *  CONFIG (business name, logo, switches)
 * --------------------------------------------------------- */
function cfgSheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_CFG);
  if (!sh) { setupAttendance(); sh = ss.getSheetByName(SHEET_CFG); }
  return sh;
}

function readConfig_() {
  var sh = cfgSheet_();
  var out = {};
  var last = sh.getLastRow();
  if (last < 2) return out;
  var vals = sh.getRange(2, 1, last - 1, 2).getValues();
  for (var i = 0; i < vals.length; i++) out[String(vals[i][0])] = String(vals[i][1]);
  return out;
}

function saveConfig_(body) {
  var sh = cfgSheet_();
  var current = readConfig_();
  var next = {
    businessName: body.businessName || '',
    logo: body.logo || '',
    enableCheckout: body.enableCheckout ? '1' : '0',
    blockExpired: body.blockExpired ? '1' : '0'
  };
  // Dusri keys (jaise staff panel ki list) bachi rehni chahiye
  for (var ck in current) if (!next.hasOwnProperty(ck)) next[ck] = current[ck];
  var rows = [];
  for (var k in next) rows.push([k, next[k]]);
  sh.getRange(2, 1, Math.max(sh.getLastRow() - 1, 1), 2).clearContent();
  sh.getRange(2, 1, rows.length, 2).setValues(rows);
  CacheService.getScriptCache().remove('cfg');
  CacheService.getScriptCache().remove('logo');
  return { success: true };
}

function getConfigCached_() {
  var cache = CacheService.getScriptCache();
  var c = cache.get('cfg');
  if (c) { try { return JSON.parse(c); } catch (e) {} }
  var cfg = readConfig_();
  var slim = {
    businessName: cfg.businessName || 'Attendance',
    enableCheckout: cfg.enableCheckout === '1',
    blockExpired: cfg.blockExpired === '1'
  };
  // Logo bada ho sakta hai (cache limit 100KB) — alag se bhejte hain
  try { cache.put('cfg', JSON.stringify(slim), 300); } catch (e) {}
  return slim;
}

/* ---------------------------------------------------------
 *  STUDENT SYNC (CMS -> Sheet)
 *  upserts: [[reg,name,last4,expiry,dues,status,batch,location,category], ...]
 *  removed: [reg, ...]
 *  reset:true  -> pehle sab saaf, phir upserts likho
 *  append:true -> bina duplicate check ke seedha neeche jodo (reset ke baad ke chunks)
 * --------------------------------------------------------- */
function syncStudents_(body) {
  var res = syncStudentsInner_(body);
  bumpStVer_(); // naya data aaya -> purana student cache band
  return res;
}

function syncStudentsInner_(body) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_STUDENTS);
  if (!sh) { setupAttendance(); sh = ss.getSheetByName(SHEET_STUDENTS); }
  var width = STUDENT_HEADERS.length;
  var upserts = (body.upserts || []).map(normRow_);
  var removed = body.removed || [];

  if (body.reset) {
    var lr = sh.getLastRow();
    if (lr > 1) sh.getRange(2, 1, lr - 1, width).clearContent();
    if (upserts.length) writeBlock_(sh, 2, upserts);
    return { success: true, count: upserts.length };
  }

  if (body.append) {
    if (upserts.length) writeBlock_(sh, sh.getLastRow() + 1, upserts);
    return { success: true, count: upserts.length };
  }

  var last = sh.getLastRow();
  var data = last > 1 ? sh.getRange(2, 1, last - 1, width).getValues() : [];
  var index = {};
  for (var i = 0; i < data.length; i++) index[String(data[i][0]).toLowerCase()] = i;

  var changedRows = {};
  var added = [];
  for (var u = 0; u < upserts.length; u++) {
    var row = upserts[u];
    var key = String(row[0]).toLowerCase();
    if (index.hasOwnProperty(key)) { data[index[key]] = row; changedRows[index[key]] = true; }
    else { added.push(row); }
  }

  var removeIdx = {};
  var removeCount = 0;
  for (var r = 0; r < removed.length; r++) {
    var rk = String(removed[r]).toLowerCase();
    if (index.hasOwnProperty(rk)) { removeIdx[index[rk]] = true; removeCount++; }
  }

  var changedCount = Object.keys(changedRows).length;
  if (removeCount > 0 || changedCount > 50) {
    // Poora block ek saath dobara likho
    var finalRows = [];
    for (var d = 0; d < data.length; d++) if (!removeIdx[d]) finalRows.push(data[d]);
    for (var a = 0; a < added.length; a++) finalRows.push(added[a]);
    if (last > 1) sh.getRange(2, 1, last - 1, width).clearContent();
    if (finalRows.length) writeBlock_(sh, 2, finalRows);
  } else {
    for (var c in changedRows) sh.getRange(Number(c) + 2, 1, 1, width).setValues([data[c]]);
    if (added.length) writeBlock_(sh, last + 1, added);
  }
  return { success: true, updated: changedCount, added: added.length, removed: removeCount };
}

function normRow_(r) {
  var out = [];
  for (var i = 0; i < STUDENT_HEADERS.length; i++) out.push(r[i] === undefined || r[i] === null ? '' : r[i]);
  out[0] = String(out[0]);
  out[2] = String(out[2]);
  out[3] = String(out[3]);
  out[4] = Number(out[4]) || 0;
  out[9] = Number(out[9]) || 0;
  out[10] = Number(out[10]) || 0;
  out[11] = String(out[11] || '');
  return out;
}

function writeBlock_(sh, startRow, rows) {
  var need = startRow + rows.length - 1 - sh.getMaxRows();
  if (need > 0) sh.insertRowsAfter(sh.getMaxRows(), need + 500);
  var rng = sh.getRange(startRow, 1, rows.length, STUDENT_HEADERS.length);
  rng.setNumberFormat('@');
  rng.setValues(rows);
  // Dues numeric rehne do
  sh.getRange(startRow, 5, rows.length, 1).setNumberFormat('0');
  sh.getRange(startRow, 10, rows.length, 2).setNumberFormat('0');
}

/* ---------------------------------------------------------
 *  ADMIN: din ki attendance list (CMS padhta hai)
 * --------------------------------------------------------- */
function adminList_(date) {
  var day = date || today_();
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_ATT);
  if (!sh || sh.getLastRow() < 2) return { success: true, date: day, records: [], subm: submittedList_(today_()) };
  var dateCol = day === today_() ? tailRange_(sh, 2, TAIL_ROWS) : sh.getRange(2, 2, sh.getLastRow() - 1, 1);
  var finder = dateCol.createTextFinder(day).matchEntireCell(true);
  var found = finder.findAll();
  var records = [];
  if (found.length) {
    var rows = found.map(function (f) { return f.getRow(); });
    var minR = Math.min.apply(null, rows), maxR = Math.max.apply(null, rows);
    var block = sh.getRange(minR, 1, maxR - minR + 1, ATT_HEADERS.length).getValues();
    for (var i = 0; i < block.length; i++) {
      if (String(block[i][1]) !== day) continue;
      records.push({ regNo: String(block[i][2]), checkIn: String(block[i][4] || ''), checkOut: String(block[i][5] || '') });
    }
  }
  return { success: true, date: day, records: records, subm: submittedList_(today_()) };
}

/* ---------------------------------------------------------
 *  STUDENT-FACING API (google.script.run se call hota hai)
 * --------------------------------------------------------- */
function today_() { return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd'); }
function nowTime_() { return Utilities.formatDate(new Date(), TZ, 'hh:mm a'); }

function getLogoCached_() {
  var cache = CacheService.getScriptCache();
  var c = cache.get('logo');
  if (c !== null) return c === 'none' ? '' : c;
  var logo = readConfig_().logo || '';
  try { cache.put('logo', logo || 'none', 21600); } catch (e) {}
  return logo;
}

function apiInit() {
  var cfg = getConfigCached_();
  return { businessName: cfg.businessName, logo: getLogoCached_(), enableCheckout: cfg.enableCheckout };
}

function findStudent_(regNo) {
  var reg = String(regNo || '').trim();
  if (!reg) return null;
  // Sirf wahi student dhundte hain jo scan kar raha hai, aur result cache me rakhte hain.
  // CMS se naya data aate hi stVer badalta hai, to cache apne aap naya ho jata hai.
  var cache = CacheService.getScriptCache();
  var ck = 'st_' + getStVer_() + '_' + reg.toLowerCase();
  try {
    var hit = cache.get(ck);
    if (hit) return hit === 'null' ? null : JSON.parse(hit);
  } catch (e) {}
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_STUDENTS);
  if (!sh || sh.getLastRow() < 2) return null;
  var cell = sh.getRange(2, 1, sh.getLastRow() - 1, 1).createTextFinder(reg).matchEntireCell(true).matchCase(false).findNext();
  var out = null;
  if (cell) {
    var v = sh.getRange(cell.getRow(), 1, 1, STUDENT_HEADERS.length).getValues()[0];
    out = { regNo: String(v[0]), name: String(v[1]), last4: String(v[2]), expiry: String(v[3]), dues: Number(v[4]) || 0, status: String(v[5] || 'active'), batch: String(v[6] || ''), location: String(v[7] || ''), category: String(v[8] || ''), adm: Number(v[9]) || 0, mon: Number(v[10]) || 0, flexi: String(v[11] || '') };
  }
  try { cache.put(ck, out ? JSON.stringify(out) : 'null', 21600); } catch (e) {}
  return out;
}

// Step 1: reg no -> sirf naam
function apiLookup(regNo) {
  var s = findStudent_(regNo);
  if (!s) return { found: false, message: 'Ye Reg No nahi mila. Dobara check karein.' };
  return { found: true, name: s.name, regNo: s.regNo };
}

function checkLocked_(reg) {
  var n = Number(CacheService.getScriptCache().get('bad_' + reg) || 0);
  return n >= MAX_WRONG;
}
function addWrong_(reg) {
  var cache = CacheService.getScriptCache();
  var n = Number(cache.get('bad_' + reg) || 0) + 1;
  cache.put('bad_' + reg, String(n), LOCK_SECONDS);
  return n;
}

function auth_(regNo, last4) {
  var s = findStudent_(regNo);
  if (!s) return { ok: false, message: 'Ye Reg No nahi mila.' };
  if (checkLocked_(s.regNo)) return { ok: false, message: 'Bahut zyada galat koshish. 10 minute baad dobara try karein.' };
  if (!s.last4) return { ok: false, message: 'Aapka mobile number record me nahi hai. Owner se baat karein.' };
  var given = String(last4 || '').replace(/\D/g, '');
  if (given.length !== 4 || given !== s.last4) {
    var n = addWrong_(s.regNo);
    var left = MAX_WRONG - n;
    return { ok: false, message: left > 0 ? 'Phone number ke last 4 digit galat hain.' : 'Bahut zyada galat koshish. 10 minute baad dobara try karein.' };
  }
  CacheService.getScriptCache().remove('bad_' + s.regNo);
  return { ok: true, student: s };
}

function todayRecord_(regNo, day) {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_ATT);
  if (!sh || sh.getLastRow() < 2) return null;
  var key = (day || today_()) + '|' + String(regNo).toLowerCase();
  var cell = tailRange_(sh, 1, TAIL_ROWS).createTextFinder(key).matchEntireCell(true).matchCase(false).findNext();
  if (!cell) return null;
  var v = sh.getRange(cell.getRow(), 1, 1, ATT_HEADERS.length).getValues()[0];
  return { row: cell.getRow(), checkIn: String(v[4] || ''), checkOut: String(v[5] || '') };
}

function daysLeft_(expiry) {
  if (!expiry || !/^\d{4}-\d{2}-\d{2}/.test(expiry)) return null;
  var t = today_().split('-');
  var e = expiry.substring(0, 10).split('-');
  var a = Date.UTC(Number(t[0]), Number(t[1]) - 1, Number(t[2]));
  var b = Date.UTC(Number(e[0]), Number(e[1]) - 1, Number(e[2]));
  return Math.round((b - a) / 86400000);
}

function fmtDate_(iso) {
  if (!iso || iso.length < 10) return '';
  return iso.substring(8, 10) + '/' + iso.substring(5, 7) + '/' + iso.substring(0, 4);
}

// Step 2: reg no + last 4 -> poori detail
function apiVerify(regNo, last4) {
  var a = auth_(regNo, last4);
  if (!a.ok) return { ok: false, message: a.message };
  var s = a.student;
  var cfg = getConfigCached_();
  var rec = todayRecord_(s.regNo);

  // Aaj ka attendance pehle ho chuka hai -> sirf time dikhao
  if (rec && rec.checkIn) {
    return {
      ok: true, name: s.name, regNo: s.regNo, already: true,
      checkIn: rec.checkIn, checkOut: rec.checkOut,
      canCheckOut: cfg.enableCheckout && !rec.checkOut
    };
  }

  var status = s.status.toLowerCase();
  var left = daysLeft_(s.expiry);
  var notice = null;
  if (left !== null && left < 0) notice = { type: 'expired', text: 'Session Expired — Renewal Now' };
  else if (left !== null && left <= 3) notice = { type: 'soon', text: left === 0 ? 'Aapka session aaj expire ho raha hai' : 'Aapka session ' + left + ' din me expire ho jayega' };

  var blockedMsg = '';
  if (status === 'blocked') blockedMsg = 'Aapka account blocked hai. Owner se baat karein.';
  else if (status === 'pushed') blockedMsg = 'Aapka membership abhi paused hai. Owner se baat karein.';
  else if (cfg.blockExpired && left !== null && left < 0) blockedMsg = 'Aapka session expire ho chuka hai. Renewal ke liye owner se baat karein.';
  else if (isSubmitted_(s.batch)) blockedMsg = 'Aapke batch ki attendance submit ho chuki hai. Ab attendance nahi lag sakti.';

  return {
    ok: true, name: s.name, regNo: s.regNo, already: false,
    batch: s.batch, expiry: fmtDate_(s.expiry), dues: s.dues,
    notice: notice, blockedMsg: blockedMsg, canCheckIn: !blockedMsg
  };
}

// Step 3: attendance mark ('in' / 'out')
function apiMark(regNo, last4, action) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
  } catch (e) {
    return { ok: false, message: 'Server busy hai, dobara try karein.' };
  }
  try {
    var a = auth_(regNo, last4);
    if (!a.ok) return { ok: false, message: a.message };
    var s = a.student;
    var cfg = getConfigCached_();
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sh = ss.getSheetByName(SHEET_ATT);
    if (!sh) { setupAttendance(); sh = ss.getSheetByName(SHEET_ATT); }
    var rec = todayRecord_(s.regNo);
    var time = nowTime_();

    if (action === 'out') {
      if (!cfg.enableCheckout) return { ok: false, message: 'Check-out abhi chalu nahi hai.' };
      if (!rec || !rec.checkIn) return { ok: false, message: 'Pehle check-in karna zaroori hai.' };
      if (rec.checkOut) return { ok: true, already: true, checkIn: rec.checkIn, checkOut: rec.checkOut };
      sh.getRange(rec.row, 6).setNumberFormat('@').setValue(time);
      logEvent_(bumpAttVer_(), s.regNo, rec.checkIn, time);
      return { ok: true, checkIn: rec.checkIn, checkOut: time };
    }

    // check-in
    return checkInCore_(s, cfg, 'qr', false);
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}

// Check-in ka asli kaam (QR, admin aur staff teeno yahi use karte hain). Lock bahar se liya hota hai.
//  by              : 'qr' / 'admin' / 'staff:<naam>'  (Attendance sheet ke MarkedBy column me jaata hai)
//  overrideExpired : true = admin expired student ko bhi mark kar sakta hai (blockExpired ignore)
//  opts            : { day, time } = staff phone me jab attendance li gayi thi (net slow ho to sheet me der se aati hai)
function checkInCore_(s, cfg, by, overrideExpired, opts) {
  opts = opts || {};
  var day = opts.day || today_();
  var time = opts.time || nowTime_();
  maybeCleanup_();
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_ATT);
  if (!sh) { setupAttendance(); sh = ss.getSheetByName(SHEET_ATT); }
  var rec = todayRecord_(s.regNo, day);
  if (rec && rec.checkIn) return { ok: true, already: true, checkIn: rec.checkIn, checkOut: rec.checkOut };

  // Batch submit ho chuki hai (CMS se ya staff se) -> QR, admin, staff, kahin se bhi attendance nahi lagegi.
  // (Jo pehle se present hain unka 'already' upar se hi laut jata hai, isliye dobara bhejna safe hai.)
  if (isSubmitted_(s.batch, day)) return { ok: false, locked: true, message: 'Is batch ki attendance submit ho chuki hai. Ab attendance nahi lag sakti.' };

  var status = String(s.status || 'active').toLowerCase();
  var left = daysLeft_(s.expiry);
  if (status === 'blocked' || status === 'pushed') return { ok: false, message: 'Attendance nahi lag sakti. Owner se baat karein.' };
  if (!overrideExpired && cfg.blockExpired && left !== null && left < 0) return { ok: false, message: 'Session expire ho chuka hai. Owner se baat karein.' };

  var row = sh.getLastRow() + 1;
  var rng = sh.getRange(row, 1, 1, ATT_HEADERS.length);
  rng.setNumberFormat('@');
  rng.setValues([[day + '|' + s.regNo.toLowerCase(), day, s.regNo, s.name, time, '', s.batch, by]]);
  logEvent_(bumpAttVer_(), s.regNo, time, '', day);
  return { ok: true, checkIn: time, expired: left !== null && left < 0 };
}

// CMS (admin) se seedha check-in. doPost me script lock pehle se liya hota hai.
function adminMark_(body) {
  var s = findStudent_(body.regNo);
  if (!s) return { success: true, ok: false, message: 'Ye Reg No sheet me nahi mila. Pehle Sync Students Now karein.' };
  var r = checkInCore_(s, getConfigCached_(), 'admin', true);
  r.success = true;
  r.name = s.name;
  return r;
}

// Check-out ka asli kaam (admin aur staff dono). Lock bahar se liya hota hai.
function checkOutCore_(s) {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_ATT);
  var rec = todayRecord_(s.regNo);
  if (!rec || !rec.checkIn) return { ok: false, message: 'Pehle check-in karna zaroori hai.' };
  if (rec.checkOut) return { ok: true, already: true, checkIn: rec.checkIn, checkOut: rec.checkOut };
  var time = nowTime_();
  sh.getRange(rec.row, 6).setNumberFormat('@').setValue(time);
  logEvent_(bumpAttVer_(), s.regNo, rec.checkIn, time);
  return { ok: true, checkIn: rec.checkIn, checkOut: time };
}

// CMS (admin) se seedha check-out
function adminMarkOut_(body) {
  var s = findStudent_(body.regNo);
  if (!s) return { success: true, ok: false, message: 'Ye Reg No sheet me nahi mila. Pehle Sync Students Now karein.' };
  if (!getConfigCached_().enableCheckout) return { success: true, ok: false, message: 'Check-out abhi chalu nahi hai.' };
  var r = checkOutCore_(s);
  r.success = true;
  r.name = s.name;
  return r;
}

/* ---------------------------------------------------------
 *  SUBMIT: admin Daily Attendance se batch submit karta hai.
 *  Submit ke baad us din us batch ki attendance QR / admin / staff, kahin se nahi lagti (staff submit bhi isi lock ko lagata hai).
 * --------------------------------------------------------- */
function submittedList_(day) {
  try { return JSON.parse(getProp_('subm_' + day, '[]')); } catch (e) { return []; }
}
function isSubmitted_(batch, day) {
  return submittedList_(day || today_()).indexOf(batchKey_(batch)) >= 0;
}
function markSubmitted_(batch, day) {
  var d = day || today_();
  var list = submittedList_(d);
  var key = batchKey_(batch);
  if (list.indexOf(key) < 0) {
    list.push(key);
    setProp_('subm_' + d, JSON.stringify(list));
  }
}
function submitBatch_(body) {
  var day = String(body.date || today_());
  var batch = batchKey_(body.batch);
  markSubmitted_(batch, day);
  return { success: true, ok: true, date: day, batch: batch };
}

// Staff panel aur CMS dono ka submit EK hi lock use karte hain: kisi ne bhi submit kiya to us din us batch ki
// attendance QR / admin / staff, kahin se nahi lagegi. CMS Daily Attendance me bhi 'Submitted' dikhta hai.
function isStaffSubmitted_(batch, day) { return isSubmitted_(batch, day); }
function lockStaffBatch_(batch, day) { markSubmitted_(batch, day); }

/* ---------------------------------------------------------
 *  STAFF PANEL  (<web app url>?mode=staff)
 *  Admin CMS se staff ka naam + PIN + batch access bhejta hai (PIN yahan sirf hash hokar rakha jaata hai).
 *  Staff PIN daalta hai -> apne batches ke students dekhta hai -> Absent par tap karke Present mark karta hai.
 * --------------------------------------------------------- */
var STAFF_HTML = __STAFF_HTML__;

function hashPin_(id, pin) {
  var bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, ADMIN_KEY + '|' + id + '|' + pin, Utilities.Charset.UTF_8);
  var out = '';
  for (var i = 0; i < bytes.length; i++) out += ('0' + (bytes[i] & 0xff).toString(16)).slice(-2);
  return out;
}

function writeConfigKey_(key, value) {
  var sh = cfgSheet_();
  var last = sh.getLastRow();
  if (last >= 2) {
    var keys = sh.getRange(2, 1, last - 1, 1).getValues();
    for (var i = 0; i < keys.length; i++) {
      if (String(keys[i][0]) === key) { sh.getRange(i + 2, 2).setValue(value); return; }
    }
  }
  sh.getRange(last + 1, 1, 1, 2).setValues([[key, value]]);
}

function saveStaff_(body) {
  var src = body.staff || [];
  var list = [];
  var seen = {};
  for (var i = 0; i < src.length; i++) {
    var m = src[i];
    var pin = String(m.pin || '').replace(/\D/g, '');
    if (pin.length < 4 || pin.length > 8) return { success: false, error: 'PIN 4 se 8 digit ka hona chahiye' };
    if (seen[pin]) return { success: false, error: 'Do staff ka PIN same nahi ho sakta' };
    seen[pin] = true;
    list.push({
      id: String(m.id),
      name: String(m.name || 'Staff'),
      h: hashPin_(String(m.id), pin),
      all: !!m.all,
      batches: m.all ? [] : (m.batches || []).map(String)
    });
  }
  writeConfigKey_('staffCfg', JSON.stringify({ enabled: !!body.enabled, staff: list }));
  CacheService.getScriptCache().remove('staffcfg');
  return { success: true, count: list.length };
}

function getStaffCfg_() {
  var cache = CacheService.getScriptCache();
  var c = cache.get('staffcfg');
  if (c) { try { return JSON.parse(c); } catch (e) {} }
  var cfg = { enabled: false, staff: [] };
  try { var raw = readConfig_().staffCfg; if (raw) cfg = JSON.parse(raw); } catch (e) {}
  try { cache.put('staffcfg', JSON.stringify(cfg), 300); } catch (e) {}
  return cfg;
}

function staffAuth_(pin) {
  var cache = CacheService.getScriptCache();
  var bad = Number(cache.get('badstaff') || 0);
  if (bad >= STAFF_MAX_WRONG) return { ok: false, message: 'Bahut zyada galat PIN. 10 minute baad dobara try karein.' };
  var cfg = getStaffCfg_();
  if (!cfg.enabled) return { ok: false, message: 'Staff panel abhi band hai. Owner se baat karein.' };
  var p = String(pin || '').replace(/\D/g, '');
  if (p) {
    for (var i = 0; i < cfg.staff.length; i++) {
      if (hashPin_(cfg.staff[i].id, p) === cfg.staff[i].h) {
        if (bad) cache.remove('badstaff');
        return { ok: true, staff: cfg.staff[i] };
      }
    }
  }
  try { cache.put('badstaff', String(bad + 1), STAFF_LOCK_SECONDS); } catch (e) {}
  return { ok: false, message: 'PIN galat hai.' };
}

function batchKey_(v) {
  var b = String(v || '').trim();
  return b || NO_BATCH;
}

function readAllStudents_() {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_STUDENTS);
  if (!sh || sh.getLastRow() < 2) return [];
  return sh.getRange(2, 1, sh.getLastRow() - 1, STUDENT_HEADERS.length).getValues();
}

// [{b: batch, n: students}] — CMS se naya sync aate hi (stVer badalta hai) cache apne aap naya ho jata hai
function getBatchList_() {
  var cache = CacheService.getScriptCache();
  var ck = 'sbl_' + getStVer_();
  try { var hit = cache.get(ck); if (hit) return JSON.parse(hit); } catch (e) {}
  var rows = readAllStudents_();
  var counts = {};
  for (var i = 0; i < rows.length; i++) {
    if (!String(rows[i][0])) continue;
    var k = batchKey_(rows[i][6]);
    counts[k] = (counts[k] || 0) + 1;
  }
  var out = [];
  for (var key in counts) out.push({ b: key, n: counts[key] });
  try { cache.put(ck, JSON.stringify(out), 21600); } catch (e) {}
  return out;
}

function allowedBatches_(m, list) {
  if (m.all) return list;
  var counts = {};
  for (var i = 0; i < list.length; i++) counts[list[i].b] = list[i].n;
  var out = [];
  for (var j = 0; j < m.batches.length; j++) out.push({ b: m.batches[j], n: counts[m.batches[j]] || 0 });
  return out;
}

function isAllowed_(m, batch, list) {
  var a = allowedBatches_(m, list);
  for (var i = 0; i < a.length; i++) if (a[i].b === batch) return true;
  return false;
}

function getBatchStudents_(batch) {
  var cache = CacheService.getScriptCache();
  var ck = 'sb_' + getStVer_() + '_' + batch;
  try { var hit = cache.get(ck); if (hit) return JSON.parse(hit); } catch (e) {}
  var rows = readAllStudents_();
  var out = [];
  for (var i = 0; i < rows.length; i++) {
    var r = rows[i];
    if (!String(r[0]) || batchKey_(r[6]) !== batch) continue;
    out.push({
      r: String(r[0]), n: String(r[1]), e: String(r[3] || '').substring(0, 10),
      a: Number(r[9]) || 0, m: Number(r[10]) || 0,
      s: String(r[5] || 'active').toLowerCase(), f: String(r[11] || '')
    });
  }
  try { cache.put(ck, JSON.stringify(out), 21600); } catch (e) {}
  return out;
}

// Aaj ki check-ins: regNo(lowercase) -> time
function todayMap_(outMap) {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_ATT);
  var map = {};
  if (!sh || sh.getLastRow() < 2) return map;
  var last = sh.getLastRow();
  var start = Math.max(2, last - TAIL_ROWS + 1);
  var vals = sh.getRange(start, 1, last - start + 1, ATT_HEADERS.length).getValues();
  var day = today_();
  for (var i = 0; i < vals.length; i++) {
    if (String(vals[i][1]) !== day) continue;
    map[String(vals[i][2]).toLowerCase()] = String(vals[i][4] || '');
    if (outMap) outMap[String(vals[i][2]).toLowerCase()] = String(vals[i][5] || '');
  }
  return map;
}

// Flexi students ki ab tak ki classes.
// Flexi cell = "total|startDate|base". base = purane (7 din se pehle ke) din jo CMS apne local record se gin kar bhejta hai,
// kyunki sheet se purana attendance delete ho jata hai. Sheet me jo din bache hain unhe yahan gina jata hai.
function flexiTaken_(students) {
  var starts = {}, taken = {};
  var minStart = '';
  for (var i = 0; i < students.length; i++) {
    var parts = String(students[i].f || '').split('|');
    if (parts.length >= 2 && parts[1]) {
      var rk = students[i].r.toLowerCase();
      starts[rk] = parts[1];
      taken[rk] = Number(parts[2]) || 0;
      if (!minStart || parts[1] < minStart) minStart = parts[1];
    }
  }
  if (!minStart) return taken;
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_ATT);
  if (!sh || sh.getLastRow() < 2) return taken;
  var last = sh.getLastRow();
  var from = Math.max(2, last - 20000 + 1);
  var vals = sh.getRange(from, 2, last - from + 1, 2).getValues(); // Date, RegNo
  for (var j = 0; j < vals.length; j++) {
    var reg = String(vals[j][1]).toLowerCase();
    if (starts.hasOwnProperty(reg) && String(vals[j][0]) >= starts[reg]) taken[reg] = (taken[reg] || 0) + 1;
  }
  return taken;
}

// Staff login screen par business name + logo dikhane ke liye (PIN se pehle). Sirf wahi public info jo student QR page par bhi dikhti hai.
function apiStaffBrand() {
  var cfg = getConfigCached_();
  return { businessName: cfg.businessName, logo: getLogoCached_() };
}

function apiStaffLogin(pin) {
  var a = staffAuth_(pin);
  if (!a.ok) return a;
  var cfg = getConfigCached_();
  var allowed = allowedBatches_(a.staff, getBatchList_());
  return { ok: true, name: a.staff.name, businessName: cfg.businessName, logo: getLogoCached_(), batches: allowed };
}

function apiStaffList(pin, batch) {
  var a = staffAuth_(pin);
  if (!a.ok) return a;
  if (!isAllowed_(a.staff, String(batch), getBatchList_())) return { ok: false, message: 'Is batch ka access nahi hai.' };
  var students = getBatchStudents_(String(batch));
  var outs = {};
  var att = todayMap_(outs);
  var cfg = getConfigCached_();
  var taken = flexiTaken_(students);
  var out = [];
  for (var i = 0; i < students.length; i++) {
    var s = students[i];
    var key = s.r.toLowerCase();
    var row = { r: s.r, n: s.n, e: s.e, a: s.a, m: s.m, s: s.s, t: att[key] || '', o: outs[key] || '' };
    var parts = String(s.f || '').split('|');
    if (parts.length >= 2) { row.ft = Number(parts[0]) || 0; row.fk = taken[key] || 0; }
    out.push(row);
  }
  return { ok: true, batch: String(batch), date: today_(), today: today_(), students: out, locked: isStaffSubmitted_(batch), co: !!cfg.enableCheckout };
}

function apiStaffMark(pin, regNo, action) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
  } catch (e) {
    return { ok: false, message: 'Server busy hai, dobara try karein.' };
  }
  try {
    var a = staffAuth_(pin);
    if (!a.ok) return a;
    var s = findStudent_(regNo);
    if (!s) return { ok: false, message: 'Student nahi mila.' };
    if (!isAllowed_(a.staff, batchKey_(s.batch), getBatchList_())) return { ok: false, message: 'Is student ke batch ka access nahi hai.' };
    if (action === 'out') {
      if (!getConfigCached_().enableCheckout) return { ok: false, message: 'Check-out abhi chalu nahi hai.' };
      return checkOutCore_(s);
    }
    if (isStaffSubmitted_(batchKey_(s.batch))) return { ok: false, message: 'Is batch ki attendance submit ho chuki hai.' };
    return checkInCore_(s, getConfigCached_(), 'staff:' + a.staff.name, false);
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}

// Staff panel ka Submit: chune hue students ka check-in ek saath sheet me likhta hai (chhote chunks me aata hai).
// day / times = staff ke phone ka asli din + time (net slow ho to sheet tak der se pahunchta hai, par time wahi rehta hai).
// last = true wale aakhri chunk ke baad batch lock ho jata hai. Chunk dobara aaye to 'already' hi milta hai.
function apiStaffSubmit(pin, batch, regs, last, id, day, times) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(25000);
  } catch (e) {
    return { ok: false, message: 'Server busy hai, dobara try karein.' };
  }
  try {
    var a = staffAuth_(pin);
    if (!a.ok) return a;
    var b = batchKey_(batch);
    if (!isAllowed_(a.staff, b, getBatchList_())) return { ok: false, message: 'Is batch ka access nahi hai.' };
    var list = regs || [];
    var useDay = day ? okDay_(day) : today_();
    if (!useDay) {
      var stale = [];
      for (var x = 0; x < list.length; x++) stale.push({ r: String(list[x]), m: 'Din bahut purana ho gaya, attendance nahi lagi.' });
      return { ok: true, done: [], failed: stale, locked: false };
    }
    var wasLocked = isSubmitted_(b, useDay);
    var cfg = getConfigCached_();
    var done = [], failed = [];
    for (var i = 0; i < list.length; i++) {
      var s = findStudent_(list[i]);
      if (!s || batchKey_(s.batch) !== b) { failed.push({ r: String(list[i]), m: 'Student is batch me nahi mila.' }); continue; }
      var t = okTime_(times && times[list[i]]);
      var r = checkInCore_(s, cfg, 'staff:' + a.staff.name, false, { day: useDay, time: t });
      if (r.ok) done.push({ r: s.regNo, t: r.checkIn, already: !!r.already });
      else failed.push({ r: s.regNo, m: r.message || 'Attendance nahi lagi.' });
    }
    // Batch pehle se submit thi aur ek bhi student nahi laga -> ye kisi aur ka submit tha
    if (wasLocked && !done.length && failed.length) return { ok: false, locked: true, message: 'Is batch ki attendance pehle hi submit ho chuki hai.' };
    var locked = false;
    if (last) { lockStaffBatch_(b, useDay); locked = true; }
    return { ok: true, done: done, failed: failed, locked: locked };
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}

/* ---------------------------------------------------------
 *  STAFF PHONE SE AAYA DIN / TIME CHECK
 * --------------------------------------------------------- */
function cutoffDay_() {
  return Utilities.formatDate(new Date(new Date().getTime() - KEEP_DAYS * 86400000), TZ, 'yyyy-MM-dd');
}
function okDay_(d) {
  d = String(d || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return '';
  if (d > today_()) return '';       // phone ki ghadi aage thi
  if (d < cutoffDay_()) return '';   // sheet me itna purana data rakhte hi nahi
  return d;
}
function okTime_(t) {
  t = String(t || '').trim();
  return /^\d{2}:\d{2} (AM|PM)$/.test(t) ? t : '';
}

/* ---------------------------------------------------------
 *  7 DIN BAAD AUTO DELETE
 *  Google Sheet sirf beech ka rasta hai (staff phone / QR -> sheet -> CMS). CMS har entry apne local storage me
 *  turant save kar leta hai, isliye sheet me KEEP_DAYS se purana attendance data rakhne ki zaroorat nahi.
 *  Roz raat ko timer chalta hai; timer na bhi ho to din ki pehli attendance ke saath bhi safai ho jati hai.
 * --------------------------------------------------------- */
function cleanupOldAttendance_() {
  var cutoff = cutoffDay_();
  var removedRows = 0;
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_ATT);
  if (sh && sh.getLastRow() >= 2) {
    var last = sh.getLastRow();
    var dates = sh.getRange(2, 2, last - 1, 1).getValues();
    var runs = [], start = -1;
    for (var i = 0; i < dates.length; i++) {
      var d = String(dates[i][0] || '');
      var old = d !== '' && d < cutoff;
      if (old && start < 0) start = i;
      if (!old && start >= 0) { runs.push([start, i - 1]); start = -1; }
    }
    if (start >= 0) runs.push([start, dates.length - 1]);
    for (var r = runs.length - 1; r >= 0; r--) {
      var count = runs[r][1] - runs[r][0] + 1;
      // Sheet me kam se kam ek non-frozen row bachni chahiye, warna delete fail ho jata hai
      if (sh.getMaxRows() - count < 2) sh.insertRowsAfter(sh.getMaxRows(), 50);
      sh.deleteRows(runs[r][0] + 2, count);
      removedRows += count;
    }
  }
  // Purane din ke submit-lock bhi hata do
  try {
    var props = PropertiesService.getScriptProperties();
    var keys = props.getKeys();
    for (var k = 0; k < keys.length; k++) {
      var m = /^(?:subm_|ssubm_)(\d{4}-\d{2}-\d{2})$/.exec(keys[k]);
      if (m && m[1] < cutoff) props.deleteProperty(keys[k]);
    }
  } catch (e) {}
  try { qenqCleanup_(); } catch (e) {} // QR ENQUIRY: Sheet se 7 din purani enquiry bhi hatao (CMS ka data nahi chhuta)
  try { evtCleanup_(); } catch (e) {}  // EVENTS: Sheet se 7 din purani registrations bhi hatao (CMS ka data nahi chhuta)
  return removedRows;
}

function maybeCleanup_() {
  try {
    var day = today_();
    if (getProp_('cleanDay', 'x') === day) return;
    setProp_('cleanDay', day);
    cleanupOldAttendance_();
  } catch (e) {}
}

// Timer ka kaam: roz raat ~3 baje
function dailyCleanup() {
  var lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try { cleanupOldAttendance_(); } finally { try { lock.releaseLock(); } catch (x) {} }
}

function installCleanupTrigger_() {
  var ts = ScriptApp.getProjectTriggers();
  for (var i = 0; i < ts.length; i++) if (ts[i].getHandlerFunction() === 'dailyCleanup') return 'exists';
  ScriptApp.newTrigger('dailyCleanup').timeBased().everyDays(1).atHour(3).inTimezone(TZ).create();
  return 'created';
}

/* ---------------------------------------------------------
 *  STUDENT PAGE (HTML)
 *  Note: yahan backtick / ${} use nahi kiye, taaki template string na tute.
 * --------------------------------------------------------- */
var PAGE_HTML = '' +
'<!DOCTYPE html><html><head><meta charset="utf-8">' +
'<meta name="viewport" content="width=device-width, initial-scale=1">' +
'<style>' +
'*{box-sizing:border-box;margin:0;padding:0}' +
'body{font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:#FCE6D4;min-height:100vh;display:flex;justify-content:center;padding:16px;color:#222}' +
'.wrap{width:100%;max-width:420px}' +
'.head{background:#FF8C42;color:#fff;border-radius:16px 16px 0 0;padding:22px 16px;text-align:center}' +
'.head img{width:64px;height:64px;border-radius:12px;object-fit:cover;background:#fff;margin-bottom:8px}' +
'.head h1{font-size:19px;font-weight:700}' +
'.head p{font-size:13px;opacity:.9;margin-top:4px}' +
'.card{background:#fff;border-radius:0 0 16px 16px;padding:20px 16px;box-shadow:0 4px 14px rgba(0,0,0,.08)}' +
'label{display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:#444}' +
'input{width:100%;padding:13px 14px;font-size:17px;border:1.5px solid #ddd;border-radius:10px;outline:none}' +
'input:focus{border-color:#FF8C42}' +
'button{width:100%;margin-top:12px;padding:14px;font-size:16px;font-weight:700;border:0;border-radius:10px;background:#FF8C42;color:#fff;cursor:pointer}' +
'button:disabled{opacity:.6}' +
'button.sec{background:#fff;color:#555;border:1.5px solid #ddd;font-weight:600}' +
'button.out{background:#2563eb}' +
'.err{background:#fef2f2;color:#b91c1c;border:1px solid #fecaca;padding:10px 12px;border-radius:10px;font-size:14px;margin-top:12px}' +
'.who{display:flex;align-items:center;gap:12px;background:#FFF3E8;border-radius:12px;padding:12px;margin-bottom:14px}' +
'.av{width:44px;height:44px;border-radius:50%;background:#FF8C42;color:#fff;font-weight:700;font-size:18px;display:flex;align-items:center;justify-content:center;flex-shrink:0}' +
'.who b{font-size:16px;display:block}.who span{font-size:13px;color:#666}' +
'.row{display:flex;justify-content:space-between;padding:9px 0;border-bottom:1px solid #f0f0f0;font-size:14px}' +
'.row span:first-child{color:#777}.row span:last-child{font-weight:600}' +
'.dues{color:#dc2626}' +
'.exp{background:#dc2626;color:#fff;border-radius:10px;padding:12px;text-align:center;font-weight:700;margin-top:12px}' +
'.soon{background:#fff7ed;color:#c2410c;border:1px solid #fed7aa;border-radius:10px;padding:12px;text-align:center;font-weight:600;margin-top:12px}' +
'.ok{background:#f0fdf4;color:#15803d;border:1px solid #bbf7d0;border-radius:12px;padding:16px;text-align:center;margin-top:12px}' +
'.ok .big{font-size:30px}.ok b{display:block;font-size:17px;margin-top:4px}.ok span{font-size:14px}' +
'.hide{display:none}' +
'</style></head><body><div class="wrap">' +
'<div class="head"><img id="logo" class="hide"><h1 id="biz">Attendance</h1><p>QR Attendance</p></div>' +
'<div class="card" id="card"></div></div>' +
'<script>' +
'var S={reg:"",name:"",last4:"",flags:{enableCheckout:false}};' +
'function $(i){return document.getElementById(i)}' +
'function esc(t){var d=document.createElement("div");d.textContent=t==null?"":String(t);return d.innerHTML}' +
'function err(m){var e=$("err");if(e){e.textContent=m;e.classList.remove("hide")}}' +
'function clr(){var e=$("err");if(e)e.classList.add("hide")}' +
'function busy(b,on,txt){b.disabled=on;if(txt)b.textContent=txt}' +
'function fail(){err("Network problem. Dobara try karein.")}' +
'function init(){google.script.run.withSuccessHandler(function(c){' +
'  $("biz").textContent=c.businessName||"Attendance";document.title=c.businessName||"Attendance";' +
'  if(c.logo){$("logo").src=c.logo;$("logo").classList.remove("hide")}' +
'  S.flags=c;stepReg();}).withFailureHandler(function(){stepReg()}).apiInit()}' +
'function stepReg(){' +
'  $("card").innerHTML=\'<label>Registration No</label><input id="reg" placeholder="Apna Reg No daalein" autocomplete="off" autocapitalize="none">\'+' +
'  \'<div id="err" class="err hide"></div><button id="go">Search</button>\';' +
'  var r=$("reg");r.value=S.reg||"";r.focus();' +
'  r.onkeydown=function(e){if(e.key==="Enter")doLookup()};$("go").onclick=doLookup}' +
'function doLookup(){clr();var v=$("reg").value.trim();if(!v){err("Reg No daalein");return}' +
'  var b=$("go");busy(b,true,"Searching...");' +
'  google.script.run.withSuccessHandler(function(r){busy(b,false,"Search");' +
'    if(!r.found){err(r.message);return}S.reg=r.regNo;S.name=r.name;stepPhone()}).withFailureHandler(function(){busy(b,false,"Search");fail()}).apiLookup(v)}' +
'function who(){return \'<div class="who"><div class="av">\'+esc((S.name||"?").charAt(0).toUpperCase())+\'</div><div><b>\'+esc(S.name)+\'</b><span>Reg No: \'+esc(S.reg)+\'</span></div></div>\'}' +
'function stepPhone(){' +
'  $("card").innerHTML=who()+\'<label>Phone number ke last 4 digit</label><input id="p4" inputmode="numeric" maxlength="4" placeholder="XXXX" autocomplete="off">\'+' +
'  \'<div id="err" class="err hide"></div><button id="vf">Verify</button><button class="sec" id="back">Dusra Reg No</button>\';' +
'  var p=$("p4");p.focus();p.oninput=function(){p.value=p.value.replace(/\\D/g,"")};' +
'  p.onkeydown=function(e){if(e.key==="Enter")doVerify()};$("vf").onclick=doVerify;' +
'  $("back").onclick=function(){S.reg="";stepReg()}}' +
'function doVerify(){clr();var v=$("p4").value;if(v.length!==4){err("4 digit daalein");return}' +
'  S.last4=v;var b=$("vf");busy(b,true,"Checking...");' +
'  google.script.run.withSuccessHandler(function(r){busy(b,false,"Verify");' +
'    if(!r.ok){err(r.message);return}stepDetails(r)}).withFailureHandler(function(){busy(b,false,"Verify");fail()}).apiVerify(S.reg,S.last4)}' +
'function timeBox(r){var h=\'<div class="row"><span>Check-in</span><span>\'+esc(r.checkIn)+\'</span></div>\';' +
'  if(r.checkOut)h+=\'<div class="row"><span>Check-out</span><span>\'+esc(r.checkOut)+\'</span></div>\';return h}' +
'function stepDetails(r){' +
'  var h=who();' +
'  if(r.already){' +
'    h+=\'<div class="ok"><div class="big">&#9989;</div><b>Aaj ki attendance lag chuki hai</b></div>\'+timeBox(r);' +
'    if(r.canCheckOut)h+=\'<div id="err" class="err hide"></div><button class="out" id="mark">Check Out</button>\';' +
'    h+=\'<button class="sec" id="done">Done</button>\';$("card").innerHTML=h;' +
'    if(r.canCheckOut)$("mark").onclick=function(){doMark("out")};$("done").onclick=reset;return}' +
'  if(r.batch)h+=\'<div class="row"><span>Batch</span><span>\'+esc(r.batch)+\'</span></div>\';' +
'  if(r.expiry)h+=\'<div class="row"><span>Session Expiry</span><span>\'+esc(r.expiry)+\'</span></div>\';' +
'  if(r.dues>0)h+=\'<div class="row"><span>Pending Dues</span><span class="dues">&#8377;\'+esc(r.dues)+\'</span></div>\';' +
'  if(r.notice&&r.notice.type==="expired")h+=\'<div class="exp">\'+esc(r.notice.text)+\'</div>\';' +
'  if(r.notice&&r.notice.type==="soon")h+=\'<div class="soon">\'+esc(r.notice.text)+\'</div>\';' +
'  if(r.blockedMsg)h+=\'<div class="err">\'+esc(r.blockedMsg)+\'</div><button class="sec" id="done">Done</button>\';' +
'  else h+=\'<div id="err" class="err hide"></div><button id="mark">Check In</button>\';' +
'  $("card").innerHTML=h;if(!r.blockedMsg)$("mark").onclick=function(){doMark("in")};' +
'  if(r.blockedMsg)$("done").onclick=reset}' +
'function doMark(a){clr();var b=$("mark");busy(b,true,"Please wait...");' +
'  google.script.run.withSuccessHandler(function(r){' +
'    if(!r.ok){busy(b,false,a==="in"?"Check In":"Check Out");err(r.message);return}' +
'    var t=a==="in"?"Check-in ho gaya!":"Check-out ho gaya!";var tm=a==="in"?r.checkIn:r.checkOut;' +
'    if(r.already){t="Aaj ki attendance lag chuki hai";tm=r.checkIn}' +
'    $("card").innerHTML=who()+\'<div class="ok"><div class="big">&#9989;</div><b>\'+esc(t)+\'</b><span>Time: \'+esc(tm)+\'</span></div><button class="sec" id="done">Done</button>\';' +
'    $("done").onclick=reset}).withFailureHandler(function(){busy(b,false,a==="in"?"Check In":"Check Out");fail()}).apiMark(S.reg,S.last4,a)}' +
'function reset(){S.reg="";S.name="";S.last4="";stepReg()}' +
'init();' +
'</script></body></html>';
