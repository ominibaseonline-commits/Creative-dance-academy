// Theme: colour theme + light/dark mode + dashboard layout (which sections show, and in what order).
// Saved in this computer's localStorage and applied before the first screen is drawn (see main.tsx).
//
// How it works: Tailwind v4 colours are CSS variables. The whole CMS uses the "orange" scale as its accent,
// so a colour theme just swaps --color-orange-50..900 + --brand + --app-bg. Dark mode adds the `dark`
// class on <html>; styles/themes.css holds the dark colours.

export type ThemeMode = 'light' | 'dark';

export interface ColorTheme {
  id: string;
  name: string;
  brand: string; // sidebar header / main buttons
  bg: string;    // page background (light mode)
  hue: number;   // accent colour family (HSL hue)
  sat: number;   // accent saturation (%)
}

export const DEFAULT_THEME_ID = 'orange';

export const COLOR_THEMES: ColorTheme[] = [
  { id: 'orange',  name: 'Sunrise Orange', brand: '#FF8C42', bg: '#FCE6D4', hue: 24,  sat: 90 },
  { id: 'ocean',   name: 'Ocean Blue',     brand: '#3B82F6', bg: '#E0ECFD', hue: 217, sat: 90 },
  { id: 'emerald', name: 'Emerald Green',  brand: '#10B981', bg: '#DCF3E8', hue: 160, sat: 80 },
  { id: 'purple',  name: 'Royal Purple',   brand: '#8B5CF6', bg: '#EAE3FC', hue: 258, sat: 85 },
  { id: 'rose',    name: 'Rose Pink',      brand: '#EC4899', bg: '#FCE4EF', hue: 330, sat: 80 },
  { id: 'teal',    name: 'Lagoon Teal',    brand: '#14B8A6', bg: '#D9F2EF', hue: 173, sat: 80 },
  { id: 'crimson', name: 'Crimson Red',    brand: '#EF4444', bg: '#FBE2E2', hue: 0,   sat: 80 },
  { id: 'indigo',  name: 'Midnight Indigo', brand: '#6366F1', bg: '#E4E5FB', hue: 239, sat: 80 },
  { id: 'gold',    name: 'Golden Amber',   brand: '#F59E0B', bg: '#FCEFCF', hue: 38,  sat: 92 },
  { id: 'slate',   name: 'Graphite',       brand: '#64748B', bg: '#E6EAEF', hue: 215, sat: 20 },
];

export interface ThemePrefs {
  mode: ThemeMode;
  colorTheme: string;
}

export const DEFAULT_THEME_PREFS: ThemePrefs = { mode: 'light', colorTheme: DEFAULT_THEME_ID };

const THEME_KEY = 'ominibase_theme_v1';
const LAYOUT_KEY = 'ominibase_dashboard_layout_v1';

export function getThemePrefs(): ThemePrefs {
  try {
    const raw = JSON.parse(localStorage.getItem(THEME_KEY) || 'null');
    const mode: ThemeMode = raw?.mode === 'dark' ? 'dark' : 'light';
    const colorTheme = COLOR_THEMES.some((t) => t.id === raw?.colorTheme) ? raw.colorTheme : DEFAULT_THEME_ID;
    return { mode, colorTheme };
  } catch {
    return { ...DEFAULT_THEME_PREFS };
  }
}

// Lightness (%) of each accent shade. In dark mode the light tints become dark tints and
// the dark text shades become light, so the same Tailwind classes stay readable.
const LIGHT_L: Record<number, number> = { 50: 96, 100: 92, 200: 85, 300: 75, 400: 64, 500: 54, 600: 45, 700: 38, 800: 31, 900: 25 };
const DARK_L: Record<number, number> = { 50: 15, 100: 20, 200: 27, 300: 36, 400: 58, 500: 55, 600: 58, 700: 72, 800: 80, 900: 88 };
const SHADES = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900];

function accentScale(hue: number, sat: number, dark: boolean): Record<string, string> {
  const out: Record<string, string> = {};
  for (const shade of SHADES) {
    const l = (dark ? DARK_L : LIGHT_L)[shade];
    const s = dark ? Math.round(sat * 0.6) : shade <= 200 ? Math.min(100, sat + 5) : sat;
    out[`--color-orange-${shade}`] = `hsl(${hue} ${s}% ${l}%)`;
  }
  return out;
}

const ORANGE_VARS = SHADES.map((s) => `--color-orange-${s}`);
const OTHER_VARS = ['--brand', '--brand-hover', '--app-bg', '--surface'];

/** Puts the theme on the page. Safe to call any number of times. */
export function applyTheme(prefs: ThemePrefs): void {
  const root = document.documentElement;
  const t = COLOR_THEMES.find((x) => x.id === prefs.colorTheme) || COLOR_THEMES[0];
  const dark = prefs.mode === 'dark';
  const isDefault = t.id === DEFAULT_THEME_ID;

  root.classList.toggle('dark', dark);
  root.setAttribute('data-theme', t.id);
  root.style.colorScheme = dark ? 'dark' : 'light';

  // Start clean, then set only what this theme/mode changes (default light = the original look, untouched)
  [...ORANGE_VARS, ...OTHER_VARS].forEach((v) => root.style.removeProperty(v));

  if (!isDefault || dark) {
    const scale = accentScale(t.hue, t.sat, dark);
    Object.entries(scale).forEach(([k, v]) => root.style.setProperty(k, v));
  }
  if (!isDefault) {
    root.style.setProperty('--brand', t.brand);
    root.style.setProperty('--brand-hover', `color-mix(in srgb, ${t.brand} 86%, black)`);
  }
  if (dark) {
    const tint = Math.min(t.sat, 25);
    root.style.setProperty('--app-bg', `hsl(${t.hue} ${tint}% 8%)`);
    root.style.setProperty('--surface', `hsl(${t.hue} ${Math.round(tint * 0.6)}% 13%)`);
  } else if (!isDefault) {
    root.style.setProperty('--app-bg', t.bg);
  }
}

export function saveThemePrefs(prefs: ThemePrefs): void {
  try { localStorage.setItem(THEME_KEY, JSON.stringify(prefs)); } catch { /* storage full/blocked: theme still applies for this session */ }
  applyTheme(prefs);
}

/** Call once at startup, before the first render. */
export function initTheme(): void {
  applyTheme(getThemePrefs());
}

// ---------------- dashboard layout ----------------

export type DashSectionId = 'stats' | 'attendance' | 'enquiry' | 'batch';

export const DASH_SECTIONS: { id: DashSectionId; label: string; hint: string }[] = [
  { id: 'stats', label: 'Stats Cards', hint: 'Total Students, Income, Dues, Expiry' },
  { id: 'attendance', label: "Today's Attendance", hint: 'Present / Absent / Pending + batch chart' },
  { id: 'enquiry', label: 'Enquiries Overview', hint: 'New, follow-ups, recent enquiries' },
  { id: 'batch', label: "Today's Batch Activity", hint: 'Live batch cards' },
];

export interface DashboardLayout {
  order: DashSectionId[];
  hidden: DashSectionId[];
}

export const DEFAULT_DASHBOARD_LAYOUT: DashboardLayout = {
  order: DASH_SECTIONS.map((s) => s.id),
  hidden: [],
};

export function getDashboardLayout(): DashboardLayout {
  const ids = DASH_SECTIONS.map((s) => s.id);
  try {
    const raw = JSON.parse(localStorage.getItem(LAYOUT_KEY) || 'null');
    const saved: DashSectionId[] = Array.isArray(raw?.order) ? raw.order.filter((x: any) => ids.includes(x)) : [];
    // keep the saved order, and add any section that is missing at its default place
    const order = [...saved, ...ids.filter((id) => !saved.includes(id))] as DashSectionId[];
    const hidden: DashSectionId[] = Array.isArray(raw?.hidden) ? raw.hidden.filter((x: any) => ids.includes(x)) : [];
    return { order, hidden };
  } catch {
    return { order: [...DEFAULT_DASHBOARD_LAYOUT.order], hidden: [] };
  }
}

export function saveDashboardLayout(layout: DashboardLayout): void {
  try { localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout)); } catch { /* ignore */ }
}
