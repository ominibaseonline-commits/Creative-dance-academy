// Batch time labels look like "4:30 To 6:00 Pm", "9:00 To 10:00 Pm (Govind Sir)",
// "7:35 To 8:35 AM Guitar ( Sat & Sun )" or 24h style "15:00 - 16:30".
// The AM/PM usually appears only after the END time, so the start time has to inherit it.
// Returns minutes from midnight of the START time, so batches sort morning -> night.

const TIME_RE = /(\d{1,2})(?::(\d{2}))?\s*(AM|PM)?/gi;

export function batchSortKey(label: string): number {
  const text = String(label || '');
  const found: { h: number; m: number; mer: string }[] = [];
  let match: RegExpExecArray | null;
  TIME_RE.lastIndex = 0;
  while ((match = TIME_RE.exec(text)) && found.length < 2) {
    found.push({ h: Number(match[1]), m: Number(match[2] || 0), mer: (match[3] || '').toUpperCase() });
  }
  if (found.length === 0) return Number.MAX_SAFE_INTEGER;

  const to24 = (t: { h: number; m: number }, mer: string) => {
    if (t.h >= 13) return t.h * 60 + t.m; // already 24h
    let h = t.h % 12;
    if (mer === 'PM') h += 12;
    return h * 60 + t.m;
  };

  const start = found[0];
  const end = found[1];
  // Meridiem on the start time itself, otherwise the one written after the end time
  const endMer = end?.mer || '';
  if (start.mer) return to24(start, start.mer);
  if (!endMer) return to24(start, ''); // no AM/PM anywhere: treat as written (24h or AM)

  const endMin = to24(end, endMer);
  let startMin = to24(start, endMer);
  // "11:00 To 1:00 Pm" -> start must be 11 AM, not 11 PM
  if (startMin > endMin) startMin -= 12 * 60;
  return startMin;
}

export type BatchStatus = 'live' | 'upcoming' | 'closed' | 'today';

/** Where a batch is right now: LIVE (inside its time), UPCOMING (not started) or CLOSED (over). 'today' = time label could not be read. */
export function batchStatus(batchTime: string, now: Date = new Date()): BatchStatus {
  const raw = String(batchTime || '');
  const range = raw.includes(' - ') ? raw.split(' - ') : raw.split(/\s+[Tt][Oo]\s+/);
  if (range.length !== 2) return 'today';
  const cur = now.getHours() * 60 + now.getMinutes();
  const parse = (s: string, fallback?: string) => {
    const m = s.trim().toUpperCase().match(/(\d+):(\d+)\s*(AM|PM)?/);
    if (!m) return 0;
    let h = parseInt(m[1]);
    const min = parseInt(m[2]);
    const p = m[3] || fallback;
    if (p === 'PM' && h !== 12) h += 12;
    if (p === 'AM' && h === 12) h = 0;
    return h * 60 + min;
  };
  const endPeriod = range[1].trim().toUpperCase().match(/(AM|PM)/)?.[1];
  const start = parse(range[0], endPeriod);
  const end = parse(range[1]);
  if (cur >= start && cur <= end) return 'live';
  if (cur < start) return 'upcoming';
  return 'closed';
}
