/* =========================================================
 *  ONLINE ADMISSION  (QR form  ->  Admissions tab  ->  CMS)
 *  Ye hissa attendance script ke saath jud kar chalta hai (same script, same URL).
 *  Public link:  <web app url>?page=admission
 *
 *  Flow:
 *   1) Student form bharta hai  -> admSubmit()  -> "Admissions" tab me row (Status = pending)
 *   2) CMS har 15-20 sec me adm_version dekhta hai, badla ho to adm_list leta hai
 *   3) CMS Approve dabata hai  -> adm_claim (sirf ek computer le sakta hai, 10 min me expire)
 *   4) Student CMS me save hone ke baad -> adm_delete (row physically delete)
 *
 *  Sab naye functions ka naam adm... se shuru hota hai, taaki attendance ke naam se na takraein.
 * ========================================================= */

var SHEET_ADM = 'Admissions';
var ADM_HEADERS = ['ReqId', 'Time', 'Status', 'Name', 'Mobile', 'Category', 'Batch', 'Location', 'ClaimBy', 'ClaimAt', 'Data'];
var ADM_CLAIM_MS = 10 * 60 * 1000;   // claim 10 minute me apne aap khatam
var ADM_MAX_PENDING = 500;           // isse zyada pending ho to nayi request nahi leta (sheet bhaari na ho)
var ADM_MAX_DATA = 8000;             // ek request ka data (characters) - cell limit se bahut neeche
var ADM_RATE_PER_MIN = 30;           // poore form par ek minute me max submissions
var ADM_MOBILE_TRIES = 3;            // ek mobile se 10 minute me max koshish
var ADM_HTML = __ADM_HTML__;

/* ---------------------------------------------------------
 *  SHEET + CONFIG
 * --------------------------------------------------------- */
function admSheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(SHEET_ADM) || ensureSheet_(ss, SHEET_ADM, ADM_HEADERS);
}

function admEmptyCfg_() {
  return { open: false, fields: [], options: { categories: [], batches: [], locations: [] } };
}

// Config sheet ki key "admCfg" me CMS ka bheja hua form layout + dropdown options rakha hota hai.
function admCfg_() {
  var cache = CacheService.getScriptCache();
  var c = cache.get('admcfg');
  if (c) { try { return JSON.parse(c); } catch (e) {} }
  var cfg = admEmptyCfg_();
  try { var raw = readConfig_().admCfg; if (raw) cfg = JSON.parse(raw); } catch (e) {}
  try { cache.put('admcfg', JSON.stringify(cfg), 300); } catch (e) {}
  return cfg;
}

function admStr_(v, max) {
  return String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
}

var ADM_TYPES = ['text', 'email', 'number', 'date', 'select', 'textarea', 'phone', 'yesno'];

function admSaveConfig_(body) {
  var fields = [];
  var src = body.fields || [];
  for (var i = 0; i < src.length && fields.length < 80; i++) {
    var f = src[i] || {};
    var id = String(f.id || '');
    if (!/^[A-Za-z0-9_]{1,40}$/.test(id)) continue;
    var type = ADM_TYPES.indexOf(f.type) >= 0 ? f.type : 'text';
    var opts = [];
    var so = f.options || [];
    for (var j = 0; j < so.length && opts.length < 30; j++) { var o = admStr_(so[j], 60); if (o) opts.push(o); }
    fields.push({
      id: id,
      label: admStr_(f.label, 60) || id,
      type: type,
      kind: f.kind === 'core' ? 'core' : 'custom',   // custom = extra + owner-made (student.customFields)
      required: f.required === true,
      width: f.width === 'full' || f.width === 'third' ? f.width : 'half',
      group: admStr_(f.group, 60),
      options: type === 'yesno' ? ['Yes', 'No'] : opts
    });
  }
  var o2 = body.options || {};
  var cats = [], batches = [], locs = [];
  var sc = o2.categories || [];
  for (var a = 0; a < sc.length && cats.length < 100; a++) {
    var subs = [];
    var ss = (sc[a] && sc[a].subs) || [];
    for (var b = 0; b < ss.length && subs.length < 100; b++) { var s = admStr_(ss[b], 80); if (s) subs.push(s); }
    var cn = admStr_(sc[a] && sc[a].name, 80);
    if (cn) cats.push({ name: cn, subs: subs });
  }
  var sb = o2.batches || [];
  for (var c = 0; c < sb.length && batches.length < 600; c++) {
    var bt = admStr_(sb[c] && sb[c].t, 80);
    if (bt) batches.push({ t: bt, c: admStr_(sb[c].c, 80), s: admStr_(sb[c].s, 80) });
  }
  var sl = o2.locations || [];
  for (var d = 0; d < sl.length && locs.length < 100; d++) { var l = admStr_(sl[d], 80); if (l) locs.push(l); }

  var cfg = { open: body.open === true, fields: fields, options: { categories: cats, batches: batches, locations: locs } };
  var json = JSON.stringify(cfg);
  if (json.length > 45000) return { success: false, error: 'Form ka config bahut bada ho gaya (category / batch list chhoti karein)' };
  writeConfigKey_('admCfg', json);
  CacheService.getScriptCache().remove('admcfg');
  admSheet_(); // tab pehle se bana ho
  return { success: true, ver: admVer_() };
}

/* ---------------------------------------------------------
 *  VERSION (CMS bina list mange pata kar leta hai kuch badla ya nahi)
 * --------------------------------------------------------- */
function admVer_() { return Number(getProp_('admVer', '0')); }
function admBump_() {
  var next = admVer_() + 1;
  setProp_('admVer', String(next));
  return next;
}

/* ---------------------------------------------------------
 *  PUBLIC PAGE  (google.script.run se: admInit, admSubmit)
 *  Ye functions koi bhi chala sakta hai, isliye inme sirf public cheezein hain.
 * --------------------------------------------------------- */
function admPage_() {
  return HtmlService.createHtmlOutput(ADM_HTML)
    .setTitle('Admission')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function admInit() {
  var cfg = admCfg_();
  var base = getConfigCached_();
  if (!cfg.open) return { open: false, businessName: base.businessName, logo: getLogoCached_() };
  return { open: true, businessName: base.businessName, logo: getLogoCached_(), fields: cfg.fields, options: cfg.options };
}

// Student ke bheje data ko layout ke hisaab se check + saaf karta hai.
function admValidate_(cfg, data) {
  var input = (data && data.f) || {};
  var core = {}, custom = {};
  var opt = cfg.options || {};
  var cat = admStr_(input.category, 80), sub = admStr_(input.subCategory, 80);
  var haveMobile = false, haveName = false;

  for (var i = 0; i < cfg.fields.length; i++) {
    var f = cfg.fields[i];
    var max = f.type === 'textarea' ? 1000 : 300;
    var v = admStr_(input[f.id], max);
    if (v === '') {
      if (f.required || f.id === 'name' || f.id === 'mobile') return { error: f.label + ' bharna zaroori hai.' };
      continue;
    }
    if (f.type === 'phone' && !/^\d{10}$/.test(v)) return { error: f.label + ' 10 digit ka hona chahiye.' };
    if (f.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return { error: f.label + ' sahi nahi hai.' };
    if (f.type === 'number' && isNaN(Number(v))) return { error: f.label + ' me sirf number likhein.' };
    if (f.type === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(v)) return { error: f.label + ' sahi date nahi hai.' };

    if (f.id === 'category') {
      if (!admFind_(opt.categories, function (x) { return x.name === v; })) return { error: f.label + ' sahi nahi hai.' };
    } else if (f.id === 'subCategory') {
      var cobj = admFind_(opt.categories, function (x) { return x.name === cat; });
      if (!cobj || cobj.subs.indexOf(v) < 0) return { error: f.label + ' sahi nahi hai.' };
    } else if (f.id === 'batchTime') {
      if (!admFind_(opt.batches, function (x) { return x.t === v && x.c === cat && x.s === sub; })) return { error: f.label + ' sahi nahi hai.' };
    } else if (f.id === 'location') {
      if ((opt.locations || []).indexOf(v) < 0) return { error: f.label + ' sahi nahi hai.' };
    } else if ((f.type === 'select' || f.type === 'yesno') && f.options.length && f.options.indexOf(v) < 0) {
      return { error: f.label + ' sahi nahi hai.' };
    }

    if (f.kind === 'core') core[f.id] = v; else custom[f.id] = v;
    if (f.id === 'mobile') haveMobile = true;
    if (f.id === 'name') haveName = true;
  }
  if (!haveMobile || !haveName) return { error: 'Naam aur Mobile zaroori hain.' };
  var payload = JSON.stringify({ core: core, custom: custom });
  if (payload.length > ADM_MAX_DATA) return { error: 'Form ka data bahut bada hai.' };
  return {
    name: core.name, mobile: core.mobile,
    category: core.category || '', batch: core.batchTime || '', location: core.location || '',
    payload: payload
  };
}

function admFind_(list, fn) {
  list = list || [];
  for (var i = 0; i < list.length; i++) if (fn(list[i])) return list[i];
  return null;
}

function admSubmit(data) {
  try {
    if (!data || typeof data !== 'object') return { ok: false, message: 'Request sahi nahi hai.' };
    if (data._hp) return { ok: true, ref: 'OK' };   // honeypot: bot ko "success" dikhao, par kuch save nahi hota
    var cfg = admCfg_();
    if (!cfg.open) return { ok: false, message: 'Admissions abhi band hain.' };

    var cache = CacheService.getScriptCache();
    var minKey = 'admrate_' + Math.floor(Date.now() / 60000);
    var n = Number(cache.get(minKey) || 0);
    if (n >= ADM_RATE_PER_MIN) return { ok: false, message: 'Abhi bahut zyada requests aa rahi hain. Thodi der baad try karein.' };
    cache.put(minKey, String(n + 1), 120);

    var v = admValidate_(cfg, data);
    if (v.error) return { ok: false, message: v.error };

    var mk = 'admmob_' + v.mobile;
    var tries = Number(cache.get(mk) || 0);
    if (tries >= ADM_MOBILE_TRIES) return { ok: false, message: 'Is number se bahut baar koshish ho chuki hai. 10 minute baad dobara try karein.' };
    cache.put(mk, String(tries + 1), 600);

    var lock = LockService.getScriptLock();
    if (!lock.tryLock(15000)) return { ok: false, message: 'Server busy hai. Dobara try karein.' };
    try {
      var sh = admSheet_();
      var last = sh.getLastRow();
      if (last - 1 >= ADM_MAX_PENDING) return { ok: false, message: 'Abhi bahut requests pending hain. Owner se sampark karein.' };
      if (last >= 2) {
        var dup = sh.getRange(2, 5, last - 1, 1).createTextFinder(v.mobile).matchEntireCell(true).findNext();
        if (dup) return { ok: false, message: 'Is mobile number se request pehle se pending hai.' };
      }
      var id = 'ADM-' + Utilities.formatDate(new Date(), TZ, 'yyMMddHHmmss') + '-' + Math.floor(1000 + Math.random() * 9000);
      var stamp = Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd'T'HH:mm:ss");
      sh.appendRow([id, stamp, 'pending', v.name, v.mobile, v.category, v.batch, v.location, '', '', v.payload]);
      admBump_();
      return { ok: true, ref: id };
    } finally {
      try { lock.releaseLock(); } catch (x) {}
    }
  } catch (err) {
    return { ok: false, message: 'Kuch gadbad ho gayi. Dobara try karein.' };
  }
}

/* ---------------------------------------------------------
 *  CMS ACTIONS  (ADMIN_KEY ke saath - doGet / doPost me pehle hi check ho chuka hota hai)
 * --------------------------------------------------------- */
function admGet_(p) {
  if (p.action === 'adm_version') return { success: true, ver: admVer_() };
  if (p.action === 'adm_list') return admList_();
  return { success: false, error: 'unknown action' };
}

function admPost_(body) {
  if (body.action === 'adm_config') return admSaveConfig_(body);
  if (body.action === 'adm_claim') return admClaim_(body);
  if (body.action === 'adm_unclaim') return admUnclaim_(body);
  if (body.action === 'adm_delete') return admDelete_(body);
  return { success: false, error: 'unknown action' };
}

function admList_() {
  var sh = admSheet_();
  var last = sh.getLastRow();
  var items = [];
  if (last >= 2) {
    var rows = sh.getRange(2, 1, last - 1, ADM_HEADERS.length).getValues();
    var now = Date.now();
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      if (String(r[2]) !== 'pending') continue;
      var data = { core: {}, custom: {} };
      try { data = JSON.parse(String(r[10])); } catch (e) {}
      var by = String(r[8] || '');
      var at = Number(r[9]) || 0;
      items.push({
        id: String(r[0]), time: String(r[1]),
        claimBy: by && now - at < ADM_CLAIM_MS ? by : '',
        data: data
      });
    }
  }
  return { success: true, ver: admVer_(), items: items };
}

function admFindRow_(id) {
  var sh = admSheet_();
  var key = String(id || '').trim();
  if (!key || sh.getLastRow() < 2) return 0;
  var cell = sh.getRange(2, 1, sh.getLastRow() - 1, 1).createTextFinder(key).matchEntireCell(true).findNext();
  return cell ? cell.getRow() : 0;
}

function admClaimState_(sh, row) {
  var v = sh.getRange(row, 9, 1, 2).getValues()[0];
  var by = String(v[0] || '');
  var at = Number(v[1]) || 0;
  return { by: by, active: !!by && Date.now() - at < ADM_CLAIM_MS };
}

function admClaim_(body) {
  var by = admStr_(body.by, 60);
  if (!by) return { success: false, error: 'by missing' };
  var row = admFindRow_(body.id);
  if (!row) return { success: true, ok: false, reason: 'gone' };
  var sh = admSheet_();
  var st = admClaimState_(sh, row);
  if (st.active && st.by !== by) return { success: true, ok: false, reason: 'taken' };
  sh.getRange(row, 9, 1, 2).setValues([[by, String(Date.now())]]);
  admBump_();
  return { success: true, ok: true };
}

function admUnclaim_(body) {
  var by = admStr_(body.by, 60);
  var row = admFindRow_(body.id);
  if (!row) return { success: true, ok: true };
  var sh = admSheet_();
  var st = admClaimState_(sh, row);
  if (st.by === by) {
    sh.getRange(row, 9, 1, 2).setValues([['', '']]);
    admBump_();
  }
  return { success: true, ok: true };
}

// Row physically delete hoti hai. Row pehle se na ho to bhi ok (retry queue ke liye safe).
// Agar koi aur computer us request ko abhi approve kar raha hai to delete nahi hota.
function admDelete_(body) {
  var by = admStr_(body.by, 60);
  var row = admFindRow_(body.id);
  if (!row) return { success: true, ok: true };
  var sh = admSheet_();
  var st = admClaimState_(sh, row);
  if (st.active && st.by !== by) return { success: true, ok: false, reason: 'claimed' };
  sh.deleteRow(row);
  admBump_();
  return { success: true, ok: true };
}

/* ---------------------------------------------------------
 *  SIRF TEST KE LIYE (CMS jodne se pehle page check karna ho to)
 *  Function list se admTestSetup chuno -> Run. Phir <web app url>?page=admission kholo.
 *  CMS jab apna config bhejta hai to ye test config apne aap badal jata hai.
 * --------------------------------------------------------- */
function admTestSetup() {
  admSaveConfig_({
    open: true,
    fields: [
      { id: 'name', label: 'Student Name', type: 'text', kind: 'core', required: true, width: 'third' },
      { id: 'gender', label: 'Gender', type: 'select', kind: 'core', required: true, width: 'full', options: ['Male', 'Female', 'Other'] },
      { id: 'dob', label: 'Date of Birth', type: 'date', kind: 'core', required: false, width: 'third' },
      { id: 'mobile', label: 'Mobile No', type: 'phone', kind: 'core', required: true, width: 'third' },
      { id: 'address', label: 'Address', type: 'text', kind: 'core', required: false, width: 'half' },
      { id: 'bloodGroup', label: 'Blood Group', type: 'select', kind: 'extra', required: false, width: 'half', group: 'Additional Information', options: ['A+', 'B+', 'O+'] },
      { id: 'category', label: 'Category', type: 'select', kind: 'core', required: true, width: 'third' },
      { id: 'subCategory', label: 'Sub-Category', type: 'select', kind: 'core', required: true, width: 'third' },
      { id: 'batchTime', label: 'Batch Time', type: 'select', kind: 'core', required: true, width: 'third' },
      { id: 'location', label: 'Location', type: 'select', kind: 'core', required: true, width: 'half' }
    ],
    options: {
      categories: [{ name: 'Dance', subs: ['Classical', 'Western'] }, { name: 'Fitness', subs: ['Zumba'] }],
      batches: [{ t: '07:00 AM To 08:00 AM', c: 'Dance', s: 'Classical' }, { t: '06:00 PM To 07:00 PM', c: 'Dance', s: 'Western' }, { t: '08:00 AM To 09:00 AM', c: 'Fitness', s: 'Zumba' }],
      locations: ['Main Branch', 'City Branch']
    }
  });
  return 'OK - ab ?page=admission kholo';
}
