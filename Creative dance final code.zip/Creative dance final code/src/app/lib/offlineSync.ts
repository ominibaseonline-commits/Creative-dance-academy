import { supabase, isSupabaseConnected, TABLES } from './supabase';

// Offline sync queue
interface SyncQueueItem {
  id: string;
  type: 'create' | 'update' | 'delete';
  table: string;
  data: any;
  timestamp: number;
}

// Get sync queue from localStorage
const getSyncQueue = (): SyncQueueItem[] => {
  try {
    const queue = localStorage.getItem('syncQueue');
    return queue ? JSON.parse(queue) : [];
  } catch {
    return [];
  }
};

// Save sync queue to localStorage
const saveSyncQueue = (queue: SyncQueueItem[]) => {
  localStorage.setItem('syncQueue', JSON.stringify(queue));
};

// Add operation to sync queue
export const addToSyncQueue = (type: 'create' | 'update' | 'delete', table: string, data: any) => {
  const queue = getSyncQueue();
  const queueItem: SyncQueueItem = {
    id: `${Date.now()}_${Math.random()}`,
    type,
    table,
    data,
    timestamp: Date.now()
  };
  queue.push(queueItem);
  saveSyncQueue(queue);
  console.log(`Added to sync queue: ${type} on ${table}`);
};

// Process sync queue - sync all pending changes to Supabase
export const processSyncQueue = async (): Promise<{ success: number; failed: number }> => {
  if (!isSupabaseConnected()) {
    console.log('Cannot process sync queue - Supabase not connected');
    return { success: 0, failed: 0 };
  }

  const queue = getSyncQueue();
  if (queue.length === 0) {
    console.log('Sync queue is empty');
    return { success: 0, failed: 0 };
  }

  console.log(`Processing ${queue.length} items in sync queue...`);
  
  let successCount = 0;
  let failedCount = 0;
  const failedItems: SyncQueueItem[] = [];

  for (const item of queue) {
    try {
      switch (item.type) {
        case 'create':
        case 'update':
          const { error: upsertError } = await supabase
            .from(item.table)
            .upsert(item.data);
          if (upsertError) throw upsertError;
          break;
        
        case 'delete':
          const { error: deleteError } = await supabase
            .from(item.table)
            .delete()
            .eq('id', item.data.id);
          if (deleteError) throw deleteError;
          break;
      }
      successCount++;
      console.log(`Synced: ${item.type} on ${item.table}`);
    } catch (error) {
      console.error(`Failed to sync item:`, error);
      failedItems.push(item);
      failedCount++;
    }
  }

  // Update queue with only failed items
  saveSyncQueue(failedItems);
  
  console.log(`Sync queue processed: ${successCount} success, ${failedCount} failed`);
  return { success: successCount, failed: failedCount };
};

// Clear sync queue
export const clearSyncQueue = () => {
  localStorage.setItem('syncQueue', JSON.stringify([]));
  console.log('Sync queue cleared');
};

// Get pending sync count
export const getPendingSyncCount = (): number => {
  return getSyncQueue().length;
};

// Save data with offline support
export const saveDataOffline = async (table: string, data: any, operation: 'create' | 'update' | 'delete' = 'update') => {
  // Always save to localStorage first (primary storage)
  const storageKey = table === TABLES.ADMIN_CREDENTIALS ? 'adminCredentials' : table;
  
  if (operation === 'delete') {
    // Delete from localStorage
    const items = JSON.parse(localStorage.getItem(storageKey) || '[]');
    const filtered = items.filter((item: any) => item.id !== data.id);
    localStorage.setItem(storageKey, JSON.stringify(filtered));
  } else {
    // Create or Update in localStorage
    if (Array.isArray(data)) {
      localStorage.setItem(storageKey, JSON.stringify(data));
    } else {
      const items = JSON.parse(localStorage.getItem(storageKey) || '[]');
      const index = items.findIndex((item: any) => item.id === data.id);
      if (index >= 0) {
        items[index] = data;
      } else {
        items.push(data);
      }
      localStorage.setItem(storageKey, JSON.stringify(items));
    }
  }

  console.log(`✅ Data saved to localStorage: ${table}`);

  // Try to sync to Supabase
  if (isSupabaseConnected()) {
    try {
      if (operation === 'delete') {
        const { error } = await supabase.from(table).delete().eq('id', data.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from(table).upsert(Array.isArray(data) ? data : [data]);
        if (error) throw error;
      }
      console.log(`✅ Data synced to Supabase: ${table}`);
      return { localStorage: true, supabase: true };
    } catch (error) {
      console.error(`❌ Failed to sync to Supabase, added to queue:`, error);
      addToSyncQueue(operation, table, data);
      return { localStorage: true, supabase: false };
    }
  } else {
    // Add to sync queue for later
    console.log(`📦 Added to sync queue (offline): ${table}`);
    addToSyncQueue(operation, table, data);
    return { localStorage: true, supabase: false };
  }
};

// Load data with offline support
export const loadDataOffline = async (table: string): Promise<any[]> => {
  const storageKey = table === TABLES.ADMIN_CREDENTIALS ? 'adminCredentials' : table;
  
  // Try to load from Supabase first if connected
  if (isSupabaseConnected()) {
    try {
      const { data, error } = await supabase.from(table).select('*');
      if (!error && data) {
        // Update localStorage with fresh data
        localStorage.setItem(storageKey, JSON.stringify(data));
        console.log(`✅ Data loaded from Supabase: ${table}`);
        return data;
      }
    } catch (error) {
      console.error(`Failed to load from Supabase, using localStorage:`, error);
    }
  }
  
  // Fallback to localStorage
  const localData = JSON.parse(localStorage.getItem(storageKey) || '[]');
  console.log(`✅ Data loaded from localStorage: ${table}`);
  return localData;
};

// Auto-sync on connection restore
export const autoSync = async () => {
  if (!isSupabaseConnected()) {
    return { synced: false, reason: 'Not connected' };
  }

  const pendingCount = getPendingSyncCount();
  if (pendingCount === 0) {
    return { synced: true, count: 0 };
  }

  console.log(`🔄 Auto-syncing ${pendingCount} pending changes...`);
  const result = await processSyncQueue();
  
  return {
    synced: true,
    success: result.success,
    failed: result.failed,
    total: pendingCount
  };
};
