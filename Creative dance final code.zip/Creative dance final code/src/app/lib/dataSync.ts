import { supabase, isSupabaseConnected as checkSupabaseConnection, TABLES } from './supabase';

// Re-export isSupabaseConnected
export const isSupabaseConnected = checkSupabaseConnection;

// Sync data from Supabase to localStorage
export const syncFromSupabase = async () => {
  if (!isSupabaseConnected()) {
    console.log('⚠️ Supabase not connected, using localStorage only');
    return false;
  }

  try {
    console.log('🔄 Syncing data from Supabase...');
    let syncedCount = 0;

    // Sync Students
    const { data: students, error: studentsError } = await supabase
      .from(TABLES.STUDENTS)
      .select('*');
    if (!studentsError && students) {
      localStorage.setItem('students', JSON.stringify(students));
      console.log(`✅ Synced ${students.length} students`);
      syncedCount++;
    }

    // Sync Payments
    const { data: payments, error: paymentsError } = await supabase
      .from(TABLES.PAYMENTS)
      .select('*');
    if (!paymentsError && payments) {
      localStorage.setItem('payments', JSON.stringify(payments));
      console.log(`✅ Synced ${payments.length} payments`);
      syncedCount++;
    }

    // Sync Teachers
    const { data: teachers, error: teachersError } = await supabase
      .from(TABLES.TEACHERS)
      .select('*');
    if (!teachersError && teachers) {
      localStorage.setItem('teachers', JSON.stringify(teachers));
      console.log(`✅ Synced ${teachers.length} teachers`);
      syncedCount++;
    }

    // Sync Batches
    const { data: batches, error: batchesError } = await supabase
      .from(TABLES.BATCHES)
      .select('*');
    if (!batchesError && batches) {
      localStorage.setItem('batches', JSON.stringify(batches));
      console.log(`✅ Synced ${batches.length} batches`);
      syncedCount++;
    }

    // Sync Locations
    const { data: locations, error: locationsError } = await supabase
      .from(TABLES.LOCATIONS)
      .select('*');
    if (!locationsError && locations) {
      localStorage.setItem('locations', JSON.stringify(locations));
      console.log(`✅ Synced ${locations.length} locations`);
      syncedCount++;
    }

    // Sync Admin Credentials
    const { data: adminCreds, error: adminError } = await supabase
      .from(TABLES.ADMIN_CREDENTIALS)
      .select('*')
      .limit(1)
      .single();
    if (!adminError && adminCreds) {
      localStorage.setItem('adminCredentials', JSON.stringify({
        email: adminCreds.email,
        password: adminCreds.password
      }));
      console.log('✅ Synced admin credentials');
      syncedCount++;
    } else {
      // If no admin creds in Supabase, use default
      const defaultCreds = {
        email: 'admin@1234',
        password: 'admin@1234'
      };
      localStorage.setItem('adminCredentials', JSON.stringify(defaultCreds));
    }

    console.log(`✅ Successfully synced ${syncedCount} tables from Supabase`);
    return true;
  } catch (error) {
    console.error('❌ Error syncing from Supabase:', error);
    return false;
  }
};

// Sync data from localStorage to Supabase
export const syncToSupabase = async (tableName: string, data: any) => {
  if (!isSupabaseConnected()) {
    console.log('Supabase not connected, saving to localStorage only');
    return false;
  }

  try {
    // For single record operations
    if (data.id) {
      const { error } = await supabase
        .from(tableName)
        .upsert(data);
      
      if (error) throw error;
    } else {
      // For bulk operations
      const { error } = await supabase
        .from(tableName)
        .upsert(data);
      
      if (error) throw error;
    }

    console.log(`Data synced to Supabase table: ${tableName}`);
    return true;
  } catch (error) {
    console.error(`Error syncing to Supabase table ${tableName}:`, error);
    return false;
  }
};

// Delete data from Supabase
export const deleteFromSupabase = async (tableName: string, id: string) => {
  if (!isSupabaseConnected()) {
    return false;
  }

  try {
    const { error } = await supabase
      .from(tableName)
      .delete()
      .eq('id', id);
    
    if (error) throw error;
    console.log(`Data deleted from Supabase table: ${tableName}`);
    return true;
  } catch (error) {
    console.error(`Error deleting from Supabase table ${tableName}:`, error);
    return false;
  }
};

// Sync all localStorage data to Supabase (for initial setup or backup)
export const syncAllToSupabase = async () => {
  if (!isSupabaseConnected()) {
    console.log('Supabase not connected');
    return false;
  }

  try {
    // Sync Students
    const students = JSON.parse(localStorage.getItem('students') || '[]');
    if (students.length > 0) {
      await syncToSupabase(TABLES.STUDENTS, students);
    }

    // Sync Payments
    const payments = JSON.parse(localStorage.getItem('payments') || '[]');
    if (payments.length > 0) {
      await syncToSupabase(TABLES.PAYMENTS, payments);
    }

    // Sync Teachers
    const teachers = JSON.parse(localStorage.getItem('teachers') || '[]');
    if (teachers.length > 0) {
      await syncToSupabase(TABLES.TEACHERS, teachers);
    }

    // Sync Batches
    const batches = JSON.parse(localStorage.getItem('batches') || '[]');
    if (batches.length > 0) {
      await syncToSupabase(TABLES.BATCHES, batches);
    }

    // Sync Locations
    const locations = JSON.parse(localStorage.getItem('locations') || '[]');
    if (locations.length > 0) {
      await syncToSupabase(TABLES.LOCATIONS, locations);
    }

    // Sync Admin Credentials
    const adminCreds = JSON.parse(localStorage.getItem('adminCredentials') || '{"email":"admin@1234","password":"admin@1234"}');
    await supabase
      .from(TABLES.ADMIN_CREDENTIALS)
      .upsert({ id: '1', email: adminCreds.email, password: adminCreds.password });

    console.log('All data synced to Supabase successfully');
    return true;
  } catch (error) {
    console.error('Error syncing all data to Supabase:', error);
    return false;
  }
};