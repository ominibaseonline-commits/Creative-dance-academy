// Mayuri Dance & Fitness Academy - POS System
// Version Information

export const VERSION_INFO = {
  version: '64.0',
  releaseDate: '2025-12-07',
  features: [
    'IndexedDB Storage Implementation',
    '50,000+ Students Capacity',
    '6-digit Registration Numbers (100000-999999)',
    'Photo Storage Support',
    '50GB+ Storage Capacity',
    'Automatic localStorage to IndexedDB Migration',
    'Complete Offline-First Architecture',
    'Fast Performance with Indexed Queries',
    'Export/Import with JSON Support',
    'WhatsApp Integration',
    'PDF Generation',
    'Multi-Device Support',
    'Sticky Columns in Tables',
    'Complete CRUD Operations',
  ],
  studentCapacity: '50,000+',
  storageType: 'IndexedDB',
  storageLimit: '50GB+',
  registrationRange: '100000-999999',
  appName: 'Mayuri Dance & Fitness Academy - POS System',
};

export const getVersionString = () => `Version ${VERSION_INFO.version}`;
export const getFullVersionInfo = () => `${VERSION_INFO.appName} - ${getVersionString()}`;
