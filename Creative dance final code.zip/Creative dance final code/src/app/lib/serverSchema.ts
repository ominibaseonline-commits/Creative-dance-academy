// Supabase server schema - run once in Supabase Dashboard -> SQL Editor.
// (Same SQL is also available as supabase/schema.sql in the project root.)
export const SERVER_SCHEMA_SQL = `-- =====================================================================
-- Ominibase CMS - Server schema
-- Supabase Dashboard -> SQL Editor -> New query -> paste -> Run (ek hi baar)
-- Safe to run again (idempotent).
-- =====================================================================

-- 1) Which license key owns this server (filled by the app on first connect)
create table if not exists public.app_meta (
  id          int primary key default 1 check (id = 1),
  license_key text not null,
  claimed_at  timestamptz not null default now()
);
alter table public.app_meta enable row level security;
-- (no policies on purpose: only the functions below can touch this table)

-- 2) All app data (students, payments, teachers, enquiries, events, settings ...)
create table if not exists public.app_data (
  store      text        not null,
  key        text        not null,
  value      jsonb,
  deleted    boolean     not null default false,
  updated_at timestamptz not null default now(),
  primary key (store, key)
);
create index if not exists app_data_updated_idx on public.app_data (updated_at, store, key);
alter table public.app_data enable row level security;

-- 3) updated_at is always set by the server clock (devices may have wrong time)
create or replace function public.app_data_touch() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

drop trigger if exists app_data_touch on public.app_data;
create trigger app_data_touch before insert or update on public.app_data
  for each row execute function public.app_data_touch();

-- 4) License check: request must carry header x-license-key == owner license key
create or replace function public.license_ok() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.app_meta m
    where m.id = 1
      and m.license_key = upper(trim(coalesce(
            nullif(current_setting('request.headers', true), '')::json ->> 'x-license-key', '')))
  );
$$;

drop policy if exists app_data_license on public.app_data;
create policy app_data_license on public.app_data
  for all to anon, authenticated
  using (public.license_ok())
  with check (public.license_ok());

grant select, insert, update, delete on public.app_data to anon, authenticated;

-- 5) status / claim helpers used by the "Connect Server" button
create or replace function public.server_status(p_key text) returns text
language plpgsql stable security definer set search_path = public as $$
declare k text;
begin
  select license_key into k from public.app_meta where id = 1;
  if k is null then return 'unclaimed'; end if;
  if k = upper(trim(coalesce(p_key, ''))) then return 'ok'; end if;
  return 'mismatch';
end $$;

create or replace function public.claim_server(p_key text) returns boolean
language plpgsql security definer set search_path = public as $$
declare v text := upper(trim(coalesce(p_key, '')));
begin
  if v = '' then return false; end if;
  insert into public.app_meta (id, license_key) values (1, v) on conflict (id) do nothing;
  return exists (select 1 from public.app_meta where id = 1 and license_key = v);
end $$;

revoke all on function public.server_status(text) from public;
revoke all on function public.claim_server(text)  from public;
grant execute on function public.server_status(text) to anon, authenticated;
grant execute on function public.claim_server(text)  to anon, authenticated;
grant execute on function public.license_ok()        to anon, authenticated;
`;
