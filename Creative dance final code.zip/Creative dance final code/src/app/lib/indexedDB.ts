// IndexedDB utility for storing large amounts of student data with photos
// Supports 50,000+ students with photos

const DB_NAME = 'MayuriAcademyDB';
const DB_VERSION = 7; // v5: added enquiries store (Enquiry section) | v6: added isolated event_* stores (Events Form module) | v7: added 'events' store (Book Events module)
const BOOK_EVENT_STORE = 'events'; // Book Events module (standalone, not linked to students/fees)
const STUDENT_STORE = 'students';
const BATCH_STORE = 'batches';
const LOCATION_STORE = 'locations';
const TEACHER_STORE = 'teachers';
const SETTINGS_STORE = 'settings';
const PAYMENT_STORE = 'payments';
const CATEGORY_STORE = 'categories'; // New store for categories
const TEACHER_PAYMENT_STORE = 'teacherPayments'; // New store for teacher payments
const CAMPAIGN_TEMPLATE_STORE = 'campaignTemplates'; // Admin-saved custom Campaign message templates
const ENQUIRY_STORE = 'enquiries'; // Enquiry section (Add Enquiry / Enquiry List / Follow-Up)

// Initialize IndexedDB
// Reuses a single cached connection across the whole app session instead of
// opening a brand-new (never-closed) connection on every read/write. Opening
// hundreds of connections over a day of use was the cause of the app
// gradually slowing down and becoming unresponsive to clicks/typing.
let dbInstance: IDBDatabase | null = null;

export const initDB = (): Promise<IDBDatabase> => {
  if (dbInstance) {
    return Promise.resolve(dbInstance);
  }

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      reject(request.error);
    };

    request.onsuccess = () => {
      dbInstance = request.result;
      // If the connection ever unexpectedly closes, clear the cache so the
      // next call opens a fresh one instead of reusing a dead reference.
      dbInstance.onclose = () => { dbInstance = null; };
      resolve(dbInstance);
    };

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Create object stores if they don't exist
      if (!db.objectStoreNames.contains(STUDENT_STORE)) {
        const studentStore = db.createObjectStore(STUDENT_STORE, { keyPath: 'regNo' });
        studentStore.createIndex('mobile', 'mobile', { unique: false });
        studentStore.createIndex('name', 'name', { unique: false });
        studentStore.createIndex('status', 'status', { unique: false });
        studentStore.createIndex('expiryDate', 'expiryDate', { unique: false });
      }

      if (!db.objectStoreNames.contains(BATCH_STORE)) {
        db.createObjectStore(BATCH_STORE, { keyPath: 'batchTime' });
      }

      if (!db.objectStoreNames.contains(LOCATION_STORE)) {
        db.createObjectStore(LOCATION_STORE, { keyPath: 'name' });
      }

      if (!db.objectStoreNames.contains(TEACHER_STORE)) {
        db.createObjectStore(TEACHER_STORE, { keyPath: 'id' });
      }

      if (!db.objectStoreNames.contains(SETTINGS_STORE)) {
        db.createObjectStore(SETTINGS_STORE, { keyPath: 'key' });
      }

      // Add payments store
      if (!db.objectStoreNames.contains(PAYMENT_STORE)) {
        const paymentStore = db.createObjectStore(PAYMENT_STORE, { keyPath: 'id', autoIncrement: true });
        paymentStore.createIndex('regNo', 'regNo', { unique: false });
        paymentStore.createIndex('paymentDate', 'paymentDate', { unique: false });
      }

      // Add categories store
      if (!db.objectStoreNames.contains(CATEGORY_STORE)) {
        db.createObjectStore(CATEGORY_STORE, { keyPath: 'id' });
      }

      // Add teacher payments store
      if (!db.objectStoreNames.contains(TEACHER_PAYMENT_STORE)) {
        const teacherPaymentStore = db.createObjectStore(TEACHER_PAYMENT_STORE, { keyPath: 'id', autoIncrement: true });
        teacherPaymentStore.createIndex('teacherId', 'teacherId', { unique: false });
        teacherPaymentStore.createIndex('paymentDate', 'paymentDate', { unique: false });
      }

      // Add campaign templates store (admin's custom saved Campaign messages)
      if (!db.objectStoreNames.contains(CAMPAIGN_TEMPLATE_STORE)) {
        db.createObjectStore(CAMPAIGN_TEMPLATE_STORE, { keyPath: 'id' });
      }

      // Add enquiries store (Enquiry section)
      if (!db.objectStoreNames.contains(ENQUIRY_STORE)) {
        db.createObjectStore(ENQUIRY_STORE, { keyPath: 'id' });
      }

      // Events module (isolated). Ye stores sirf src/app/events/* padhta/likhta hai.
      // Ye jaan-boojhkar exportAllData / Drive backup / Dashboard / Reports me NAHI hain.
      // Sirf wahi stores bante hain jo abhi nahi hain, isliye purana data kabhi nahi chhuta.
      if (!db.objectStoreNames.contains('event_events')) {
        db.createObjectStore('event_events', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('event_templates')) {
        db.createObjectStore('event_templates', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('event_submissions')) {
        const subs = db.createObjectStore('event_submissions', { keyPath: 'id' });
        subs.createIndex('event_id', 'event_id', { unique: false });
      }

      // Book Events module (client-customized, standalone — separate from the Events Form module above)
      if (!db.objectStoreNames.contains(BOOK_EVENT_STORE)) {
        db.createObjectStore(BOOK_EVENT_STORE, { keyPath: 'id' });
      }
    };
  });
};

// Generic function to add/update data
export const saveData = async (storeName: string, data: any, keepLiteCache = false): Promise<void> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([storeName], 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.put(data);

    request.onsuccess = () => {
      if (storeName === STUDENT_STORE && !keepLiteCache) invalidateStudentsLite();
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
};

// Generic function to get all data
export const getAllData = async (storeName: string): Promise<any[]> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([storeName], 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

// Generic function to get single data by key
export const getData = async (storeName: string, key: any): Promise<any> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([storeName], 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.get(key);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

// Generic function to delete data
export const deleteData = async (storeName: string, key: any): Promise<void> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([storeName], 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.delete(key);

    request.onsuccess = () => {
      if (storeName === STUDENT_STORE) invalidateStudentsLite();
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
};

// Function to clear all data from a store
export const clearStore = async (storeName: string): Promise<void> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([storeName], 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.clear();

    request.onsuccess = () => {
      if (storeName === STUDENT_STORE) invalidateStudentsLite();
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
};

// ---------------------------------------------------------------------------
// "Lite" student list (no photos) — built for 10,000+ students
// ---------------------------------------------------------------------------
// Problem: getAllStudents() returns every student WITH their base64 photo.
// With thousands of students that is hundreds of MB in memory on every visit
// to the Student List, and the list only needs text fields (photos are shown
// for just the 50-100 rows on the current page).
//
// getStudentsLite() reads students once, strips the photo (keeps a tiny
// `hasPhoto` flag), and keeps the result cached in memory. Saves/deletes patch
// the cache in place, so coming back to the list or editing a student is
// instant. Photos are fetched on demand with getStudentPhoto().
let liteCache: Map<string, any> | null = null;
let liteLoadPromise: Promise<any[]> | null = null;
let liteVersion = 0; // bumped whenever the cache is invalidated mid-load
const liteProgressListeners = new Set<(loaded: number, total: number) => void>();

// Small in-memory cache of recently shown photos (so paging back is instant)
const PHOTO_CACHE_MAX = 300;
const photoCache = new Map<string, string>();

const toLiteStudent = (student: any) => {
  const { photo, ...rest } = student;
  return { ...rest, hasPhoto: !!photo };
};

export const invalidateStudentsLite = () => {
  liteCache = null;
  liteVersion++;
  photoCache.clear();
};

const loadStudentsLiteOnce = async (): Promise<Map<string, any>> => {
  const db = await initDB();
  const total: number = await new Promise((resolve) => {
    const countReq = db.transaction([STUDENT_STORE], 'readonly').objectStore(STUDENT_STORE).count();
    countReq.onsuccess = () => resolve(countReq.result);
    countReq.onerror = () => resolve(0);
  });

  return new Promise((resolve, reject) => {
    const map = new Map<string, any>();
    const request = db.transaction([STUDENT_STORE], 'readonly').objectStore(STUDENT_STORE).openCursor();
    request.onsuccess = () => {
      const cursor = request.result;
      if (cursor) {
        map.set(cursor.key as string, toLiteStudent(cursor.value));
        if (map.size % 250 === 0) liteProgressListeners.forEach((fn) => fn(map.size, total));
        cursor.continue();
      } else {
        liteProgressListeners.forEach((fn) => fn(map.size, total));
        resolve(map);
      }
    };
    request.onerror = () => reject(request.error);
  });
};

export const getStudentsLite = async (onProgress?: (loaded: number, total: number) => void): Promise<any[]> => {
  const sorted = (m: Map<string, any>) =>
    Array.from(m.values()).sort((a: any, b: any) => (a.order || 0) - (b.order || 0));

  if (liteCache) return sorted(liteCache);

  if (onProgress) liteProgressListeners.add(onProgress);
  try {
    if (!liteLoadPromise) {
      liteLoadPromise = (async () => {
        // If data changes while we are loading, the result would be stale — load again.
        for (let attempt = 0; attempt < 3; attempt++) {
          const startVersion = liteVersion;
          const map = await loadStudentsLiteOnce();
          if (startVersion === liteVersion) {
            liteCache = map;
            return sorted(map);
          }
        }
        const map = await loadStudentsLiteOnce();
        liteCache = map;
        return sorted(map);
      })().finally(() => { liteLoadPromise = null; });
    }
    return await liteLoadPromise;
  } finally {
    if (onProgress) liteProgressListeners.delete(onProgress);
  }
};

// Warm the cache in the background (called once after login) so the Student
// List opens instantly instead of loading when the admin clicks it.
export const preloadStudentsLite = () => {
  getStudentsLite().catch((e) => console.error('Student preload failed:', e));
};

// One student's photo, loaded only when needed (rows currently on screen)
export const getStudentPhoto = async (regNo: string): Promise<string> => {
  if (photoCache.has(regNo)) return photoCache.get(regNo) as string;
  const student = await getData(STUDENT_STORE, regNo);
  const photo: string = student?.photo || '';
  if (photoCache.size >= PHOTO_CACHE_MAX) {
    const firstKey = photoCache.keys().next().value;
    if (firstKey !== undefined) photoCache.delete(firstKey);
  }
  photoCache.set(regNo, photo);
  return photo;
};

// Student specific functions
export const saveStudent = async (student: any) => {
  // Add timestamp and order index for serial display
  const studentWithMetadata = {
    ...student,
    createdAt: student.createdAt || new Date().toISOString(),
    order: student.order || Date.now()
  };
  await saveData(STUDENT_STORE, studentWithMetadata, true);
  // Keep the lite cache + photo cache in step with this one change (no full reload)
  photoCache.delete(studentWithMetadata.regNo);
  if (liteCache) liteCache.set(studentWithMetadata.regNo, toLiteStudent(studentWithMetadata));
  // Also sync to localStorage for backward compatibility
  await syncToLocalStorage();
};

export const getAllStudents = async () => {
  const students = await getAllData(STUDENT_STORE);
  // Sort by order (oldest first, newest last) - serial order
  return students.sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
};

export const getStudent = (regNo: string) => getData(STUDENT_STORE, regNo);

export const deleteStudent = async (regNo: string) => {
  const cacheBefore = liteCache;
  const versionBefore = liteVersion;
  await deleteData(STUDENT_STORE, regNo);
  // deleteData invalidates the cache; restore it minus this student so the list stays instant
  if (cacheBefore && liteVersion === versionBefore + 1) {
    cacheBefore.delete(regNo);
    liteCache = cacheBefore;
  }
  // Also sync to localStorage
  await syncToLocalStorage();
};

// Enquiry specific functions (Enquiry section)
export const saveEnquiry = (enquiry: any) => saveData(ENQUIRY_STORE, enquiry);
export const getAllEnquiries = () => getAllData(ENQUIRY_STORE);
export const deleteEnquiry = (id: string) => deleteData(ENQUIRY_STORE, id);

// Batch specific functions
export const saveBatch = async (batch: any) => {
  // Validate that batch has batchTime
  if (!batch.batchTime) {
    console.error('Batch missing batchTime:', batch);
    return;
  }
  
  // Add timestamp and order index for serial display
  const batchWithMetadata = {
    ...batch,
    createdAt: batch.createdAt || new Date().toISOString(),
    order: batch.order || Date.now()
  };
  await saveData(BATCH_STORE, batchWithMetadata);
  await syncBatchesToLocalStorage();
};

export const getAllBatches = async () => {
  const batches = await getAllData(BATCH_STORE);
  // Sort by order (oldest first, newest last) - serial order
  return batches.sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
};

export const deleteBatch = async (batchTime: string) => {
  await deleteData(BATCH_STORE, batchTime);
  await syncBatchesToLocalStorage();
};

// Location specific functions
export const saveLocation = async (location: any) => {
  // Validate that location has name
  if (!location.name) {
    console.error('Location missing name:', location);
    return;
  }
  
  // Add timestamp and order index for serial display
  const locationWithMetadata = {
    ...location,
    createdAt: location.createdAt || new Date().toISOString(),
    order: location.order || Date.now()
  };
  await saveData(LOCATION_STORE, locationWithMetadata);
  await syncLocationsToLocalStorage();
};

export const getAllLocations = async () => {
  const locations = await getAllData(LOCATION_STORE);
  // Sort by order (oldest first, newest last) - serial order
  return locations.sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
};

export const deleteLocation = async (name: string) => {
  await deleteData(LOCATION_STORE, name);
  await syncLocationsToLocalStorage();
};

// Teacher specific functions
export const saveTeacher = async (teacher: any) => {
  // Ensure teacher has an id field
  const teacherData = {
    ...teacher,
    id: teacher.id || `teacher_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  };
  await saveData(TEACHER_STORE, teacherData);
  await syncTeachersToLocalStorage();
};

export const getAllTeachers = async () => {
  return await getAllData(TEACHER_STORE);
};

export const deleteTeacher = async (id: string) => {
  await deleteData(TEACHER_STORE, id);
  await syncTeachersToLocalStorage();
};

// Payment specific functions
export const savePayment = async (payment: any): Promise<void> => {
  await saveData(PAYMENT_STORE, payment);
  await syncPaymentsToLocalStorage();
};

export const getAllPayments = async (): Promise<any[]> => {
  return await getAllData(PAYMENT_STORE);
};

export const getPaymentsByRegNo = async (regNo: string): Promise<any[]> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([PAYMENT_STORE], 'readonly');
    const store = transaction.objectStore(PAYMENT_STORE);
    const index = store.index('regNo');
    const request = index.getAll(regNo);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

export const deletePayment = async (id: number): Promise<void> => {
  await deleteData(PAYMENT_STORE, id);
  await syncPaymentsToLocalStorage();
};

export const deletePaymentsByRegNo = async (regNo: string): Promise<void> => {
  const payments = await getPaymentsByRegNo(regNo);
  const db = await initDB();
  
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([PAYMENT_STORE], 'readwrite');
    const store = transaction.objectStore(PAYMENT_STORE);
    
    let completed = 0;
    const total = payments.length;
    
    if (total === 0) {
      resolve();
      return;
    }
    
    payments.forEach(payment => {
      const request = store.delete(payment.id);
      request.onsuccess = () => {
        completed++;
        if (completed === total) {
          resolve();
        }
      };
      request.onerror = () => reject(request.error);
    });
  });
};

export const saveMultiplePayments = async (payments: any[]): Promise<void> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([PAYMENT_STORE], 'readwrite');
    const store = transaction.objectStore(PAYMENT_STORE);

    let completed = 0;
    const total = payments.length;

    payments.forEach(payment => {
      // Create a clean payment object with proper id handling
      const paymentData = { ...payment };
      
      // If id is undefined or null, delete it to let autoIncrement work
      if (paymentData.id === undefined || paymentData.id === null) {
        delete paymentData.id;
      }
      
      const request = store.put(paymentData);
      request.onsuccess = () => {
        completed++;
        if (completed === total) {
          resolve();
        }
      };
      request.onerror = () => {
        console.error('Error saving payment:', request.error, paymentData);
        reject(request.error);
      };
    });

    if (payments.length === 0) {
      resolve();
    }
  });
};

// Settings specific functions
export const saveSetting = (key: string, value: any) => saveData(SETTINGS_STORE, { key, value });
export const getSetting = async (key: string): Promise<any> => {
  const result = await getData(SETTINGS_STORE, key);
  return result ? result.value : null;
};

// Campaign Template specific functions — admin's own saved custom WhatsApp
// message templates (Campaign > Batch Messaging). Stored in their own store
// keyed by `id`, so import/export naturally upsert: a template with a matching
// id gets updated, a new id gets added — nothing is duplicated.
export const saveCampaignTemplate = async (template: any) => {
  await saveData(CAMPAIGN_TEMPLATE_STORE, template);
};

export const getAllCampaignTemplates = async () => {
  const templates = await getAllData(CAMPAIGN_TEMPLATE_STORE);
  return templates.sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
};

export const deleteCampaignTemplate = async (id: string) => {
  await deleteData(CAMPAIGN_TEMPLATE_STORE, id);
};

// License Key functions
export const saveLicenseKey = async (licenseData: any) => {
  return saveSetting('licenseKey', licenseData);
};

export const getLicenseKey = async (): Promise<any> => {
  return getSetting('licenseKey');
};

// Migration function from localStorage to IndexedDB
export const migrateFromLocalStorage = async (): Promise<void> => {
  try {
    // Check if migration is needed
    const migrated = localStorage.getItem('migrated_to_indexeddb');
    if (migrated === 'true') {
      // Even if migrated, ensure data is synced back to localStorage
      await syncAllDataToLocalStorage();
      return;
    }

    console.log('🔄 Starting migration from localStorage to IndexedDB...');

    // Migrate students
    const studentsData = localStorage.getItem('students');
    if (studentsData) {
      const students = JSON.parse(studentsData);
      console.log(`📦 Migrating ${students.length} students...`);
      const baseTime = Date.now() - (students.length * 1000); // Base timestamp
      for (let i = 0; i < students.length; i++) {
        const student = students[i];
        // Add order based on index to maintain serial order
        student.order = student.order || (baseTime + (i * 1000));
        student.createdAt = student.createdAt || new Date(baseTime + (i * 1000)).toISOString();
        await saveData(STUDENT_STORE, student);
      }
      console.log('✅ Students migrated');
    }

    // Migrate batches
    const batchesData = localStorage.getItem('batches');
    if (batchesData) {
      const batches = JSON.parse(batchesData);
      console.log(`📦 Migrating ${batches.length} batches...`);
      const baseTime = Date.now() - (batches.length * 1000); // Base timestamp
      for (let i = 0; i < batches.length; i++) {
        const batch = batches[i];
        // Add order based on index to maintain serial order
        batch.order = batch.order || (baseTime + (i * 1000));
        batch.createdAt = batch.createdAt || new Date(baseTime + (i * 1000)).toISOString();
        await saveData(BATCH_STORE, batch);
      }
      console.log('✅ Batches migrated');
    }

    // Migrate locations
    const locationsData = localStorage.getItem('locations');
    if (locationsData) {
      const locations = JSON.parse(locationsData);
      console.log(`📦 Migrating ${locations.length} locations...`);
      const baseTime = Date.now() - (locations.length * 1000); // Base timestamp
      for (let i = 0; i < locations.length; i++) {
        const location = locations[i];
        // Add order based on index to maintain serial order
        location.order = location.order || (baseTime + (i * 1000));
        location.createdAt = location.createdAt || new Date(baseTime + (i * 1000)).toISOString();
        await saveData(LOCATION_STORE, location);
      }
      console.log('✅ Locations migrated');
    }

    // Migrate teachers
    const teachersData = localStorage.getItem('teachers');
    if (teachersData) {
      const teachers = JSON.parse(teachersData);
      console.log(`📦 Migrating ${teachers.length} teachers...`);
      for (const teacher of teachers) {
        await saveTeacher(teacher);
      }
      console.log('✅ Teachers migrated');
    }

    // Migrate payments
    const paymentsData = localStorage.getItem('payments');
    if (paymentsData) {
      const payments = JSON.parse(paymentsData);
      console.log(`📦 Migrating ${payments.length} payments...`);
      await saveMultiplePayments(payments);
      console.log('✅ Payments migrated');
    }

    // Migrate admin credentials
    const adminUser = localStorage.getItem('adminUser');
    const adminPass = localStorage.getItem('adminPass');
    if (adminUser && adminPass) {
      await saveSetting('adminUser', adminUser);
      await saveSetting('adminPass', adminPass);
      console.log('✅ Admin credentials migrated');
    }

    // Mark migration as complete
    localStorage.setItem('migrated_to_indexeddb', 'true');
    console.log('✅ Migration from localStorage to IndexedDB completed successfully!');
    
    // Sync all data back to localStorage for backward compatibility
    await syncAllDataToLocalStorage();
  } catch (error) {
    console.error('❌ Error during migration:', error);
  }
};

// Bulk operations for better performance
export const saveMultipleStudents = async (students: any[]): Promise<void> => {
  invalidateStudentsLite();
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([STUDENT_STORE], 'readwrite');
    const store = transaction.objectStore(STUDENT_STORE);

    let completed = 0;
    const total = students.length;

    students.forEach(student => {
      // Validate that student has regNo
      if (!student.regNo) {
        console.error('Student missing regNo:', student);
        completed++;
        if (completed === total) {
          resolve();
        }
        return;
      }
      
      const request = store.put(student);
      request.onsuccess = () => {
        completed++;
        if (completed === total) {
          resolve();
        }
      };
      request.onerror = () => {
        console.error('Error saving student:', request.error, student);
        completed++;
        if (completed === total) {
          resolve();
        }
      };
    });

    if (students.length === 0) {
      resolve();
    }
  });
};

// Get students by index
export const getStudentsByStatus = async (status: string): Promise<any[]> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([STUDENT_STORE], 'readonly');
    const store = transaction.objectStore(STUDENT_STORE);
    const index = store.index('status');
    const request = index.getAll(status);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

// Export all data for backup
export const exportAllData = async (): Promise<any> => {
  return {
    students: await getAllStudents(),
    batches: await getAllBatches(),
    locations: await getAllLocations(),
    teachers: await getAllTeachers(),
    payments: await getAllPayments(),
    categories: await getAllCategories(),
    teacherPayments: await getAllTeacherPayments(),
    campaignTemplates: await getAllCampaignTemplates(),
    // Enquiry section — records + the admin's course/source lists + custom WhatsApp messages
    enquiries: await getAllEnquiries(),
    enquiryCourses: await getSetting('enquiryCourses'),
    enquirySources: await getSetting('enquirySources'),
    enquiryAddTemplate: await getSetting('enquiryAddTemplate'),
    enquiryListTemplate: await getSetting('enquiryListTemplate'),
    enquiryFollowUpTemplate: await getSetting('enquiryFollowUpTemplate'),
    enquiryQrTemplate: await getSetting('enquiryQrTemplate'),
    // Attendance add-ons — flexi class packages, staff panel (PIN + batch access), dues WhatsApp messages
    flexiPlans: await getSetting('flexiPlans'),
    attendanceStaff: await getSetting('attendanceStaff'),
    attendanceAdmissionDuesTemplate: await getSetting('attendanceAdmissionDuesTemplate'),
    attendanceMonthlyDuesTemplate: await getSetting('attendanceMonthlyDuesTemplate'),
    attendanceExpirySoonTemplate: await getSetting('attendanceExpirySoonTemplate'),
    attendanceExpiredTemplate: await getSetting('attendanceExpiredTemplate'),
    adminUser: await getSetting('adminUser'),
    adminPass: await getSetting('adminPass'),
    businessName: await getSetting('businessName'),
    // Business profile fields — so a restored backup brings back the full
    // identity of the business (shown on receipts, WhatsApp messages, etc.),
    // not just its name.
    businessPhone: await getSetting('businessPhone'),
    businessAddress: await getSetting('businessAddress'),
    businessLogo: await getSetting('businessLogo'),
    // Which optional fields are turned on in the Admission Form — part of
    // "har section" of the app's configuration, not just its records.
    enabledAdmissionFields: await getSetting('enabledAdmissionFields'),
    // Admission Form Layout (order / hide / required / rename / custom fields)
    admissionFormLayout: await getSetting('admissionFormLayout'),
  };
};

// ---------------------------------------------------------------------------
// COMPLETE JSON (Settings -> Data Export & Import)
// Everything the app keeps: all records + EVERY setting (QR Attendance, QR Enquiry, Online Admission,
// Google Review, Theme, Event Forms ... ) + the Events module stores.
// exportAllData() (used by Drive backup) is left exactly as it was; this one adds the extras on top.
// ---------------------------------------------------------------------------
const EVENT_STORES: Array<[string, string]> = [
  ['bookEvents', BOOK_EVENT_STORE], // Book Events module
  ['eventEvents', 'event_events'],
  ['eventTemplates', 'event_templates'],
  ['eventSubmissions', 'event_submissions'],
];
// Never copied between computers: the license (tied to the machine) and "last pushed" hashes
// (so a restored app simply re-sends its config to Google once, which is harmless).
const isSkippedSetting = (key: string) => key === 'licenseKey' || /(Hash|SyncState)$/.test(key);

export const exportEverything = async (): Promise<any> => {
  const base = await exportAllData();
  const settingsAll = ((await getAllData(SETTINGS_STORE)) || []).filter((r: any) => r && r.key && !isSkippedSetting(r.key));
  const extra: any = { settingsAll };
  for (const [name, store] of EVENT_STORES) extra[name] = await getAllData(store);
  return { ...base, ...extra };
};

const importExtras = async (data: any): Promise<void> => {
  // Every setting (upsert - same key is updated, nothing else is touched)
  if (Array.isArray(data.settingsAll)) {
    console.log(`📦 Importing ${data.settingsAll.length} settings...`);
    for (const row of data.settingsAll) {
      if (row && row.key && !isSkippedSetting(row.key)) await saveSetting(row.key, row.value);
    }
  }
  // Older backups (before Book Events was merged here) kept Book Events under the key "events"
  if (Array.isArray(data.events) && data.events.length && !Array.isArray(data.bookEvents)) {
    console.log(`📦 Importing ${data.events.length} Book Events (old backup format)...`);
    for (const item of data.events) await saveData(BOOK_EVENT_STORE, item);
  }
  // Events module (upsert by id)
  for (const [name, store] of EVENT_STORES) {
    const list = data[name];
    if (Array.isArray(list) && list.length) {
      console.log(`📦 Importing ${list.length} ${name}...`);
      for (const item of list) await saveData(store, item);
    }
  }
};

// Import all data from backup
export const importAllData = async (data: any): Promise<void> => {
  invalidateStudentsLite();
  console.log('📥 Starting IndexedDB import...');
  
  // Import students
  if (data.students && data.students.length > 0) {
    console.log(`📦 Importing ${data.students.length} students...`);
    await saveMultipleStudents(data.students);
  }
  
  // Import batches
  if (data.batches && data.batches.length > 0) {
    console.log(`📦 Importing ${data.batches.length} batches...`);
    for (const batch of data.batches) {
      await saveBatch(batch);
    }
  }
  
  // Import locations
  if (data.locations && data.locations.length > 0) {
    console.log(`📦 Importing ${data.locations.length} locations...`);
    for (const location of data.locations) {
      await saveLocation(location);
    }
  }
  
  // Import teachers
  if (data.teachers && data.teachers.length > 0) {
    console.log(`📦 Importing ${data.teachers.length} teachers...`);
    for (const teacher of data.teachers) {
      await saveTeacher(teacher);
    }
  }
  
  // Import payments
  if (data.payments && data.payments.length > 0) {
    console.log(`📦 Importing ${data.payments.length} payments...`);
    await saveMultiplePayments(data.payments);
  }

  // Import categories
  if (data.categories && data.categories.length > 0) {
    console.log(`📦 Importing ${data.categories.length} categories...`);
    for (const category of data.categories) {
      await saveCategory(category);
    }
  }

  // Import teacher payments
  if (data.teacherPayments && data.teacherPayments.length > 0) {
    console.log(`📦 Importing ${data.teacherPayments.length} teacher payments...`);
    for (const payment of data.teacherPayments) {
      await saveTeacherPayment(payment);
    }
  }

  // Import campaign templates — put-based upsert (same id updates in place,
  // a new id gets added), so nothing already present gets duplicated.
  if (data.campaignTemplates && data.campaignTemplates.length > 0) {
    console.log(`📦 Importing ${data.campaignTemplates.length} campaign templates...`);
    for (const template of data.campaignTemplates) {
      await saveCampaignTemplate(template);
    }
  }

  // Import enquiries (put-based upsert, same id updates in place)
  if (data.enquiries && data.enquiries.length > 0) {
    console.log(`📦 Importing ${data.enquiries.length} enquiries...`);
    for (const enquiry of data.enquiries) {
      await saveEnquiry(enquiry);
    }
  }
  for (const key of ['enquiryCourses', 'enquirySources', 'enquiryAddTemplate', 'enquiryListTemplate', 'enquiryFollowUpTemplate', 'enquiryQrTemplate', 'flexiPlans', 'attendanceStaff', 'attendanceAdmissionDuesTemplate', 'attendanceMonthlyDuesTemplate', 'attendanceExpirySoonTemplate', 'attendanceExpiredTemplate']) {
    if (data[key]) await saveSetting(key, data[key]);
  }

  // Import business name
  if (data.businessName) {
    await saveSetting('businessName', data.businessName);
  }

  // Import business profile (phone/address/logo) and admission form config
  if (data.businessPhone) {
    await saveSetting('businessPhone', data.businessPhone);
  }
  if (data.businessAddress) {
    await saveSetting('businessAddress', data.businessAddress);
  }
  if (data.businessLogo) {
    await saveSetting('businessLogo', data.businessLogo);
  }
  if (data.enabledAdmissionFields) {
    await saveSetting('enabledAdmissionFields', data.enabledAdmissionFields);
  }
  if (data.admissionFormLayout) {
    await saveSetting('admissionFormLayout', data.admissionFormLayout);
  }

  // Import admin credentials
  if (data.adminCredentials) {
    console.log('🔐 Importing admin credentials...');
    if (data.adminCredentials.email) {
      await saveSetting('adminUser', data.adminCredentials.email);
    }
    if (data.adminCredentials.password) {
      await saveSetting('adminPass', data.adminCredentials.password);
    }
  }
  
  // Legacy support for old format
  if (data.adminUser) {
    await saveSetting('adminUser', data.adminUser);
  }
  if (data.adminPass) {
    await saveSetting('adminPass', data.adminPass);
  }
  
  await importExtras(data);

  console.log('✅ IndexedDB import completed!');
};

// Sync students to localStorage
// localStorage is only a legacy fallback copy (IndexedDB is the real storage).
// Copying every student (with photos) on EVERY save made each admission/edit/
// delete slower the more students existed, and overflowed the ~5MB
// localStorage limit. So: skip it for big databases, store text-only data
// otherwise, and never let a failure here break the actual save.
const LOCAL_MIRROR_MAX_STUDENTS = 500;
const syncToLocalStorage = async () => {
  try {
    const db = await initDB();
    const total: number = await new Promise((resolve) => {
      const req = db.transaction([STUDENT_STORE], 'readonly').objectStore(STUDENT_STORE).count();
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(0);
    });
    if (total > LOCAL_MIRROR_MAX_STUDENTS) {
      localStorage.removeItem('students'); // avoid leaving a stale/outdated copy behind
      return;
    }
    const students = (await getAllStudents()).map(toLiteStudent);
    localStorage.setItem('students', JSON.stringify(students));
  } catch (error) {
    console.warn('localStorage mirror skipped:', error);
  }
};

// Sync batches to localStorage
const syncBatchesToLocalStorage = async () => {
  const batches = await getAllBatches();
  localStorage.setItem('batches', JSON.stringify(batches));
};

// Sync locations to localStorage
const syncLocationsToLocalStorage = async () => {
  const locations = await getAllLocations();
  localStorage.setItem('locations', JSON.stringify(locations));
};

// Sync teachers to localStorage
const syncTeachersToLocalStorage = async () => {
  const teachers = await getAllTeachers();
  localStorage.setItem('teachers', JSON.stringify(teachers));
};

// Sync payments to localStorage
const syncPaymentsToLocalStorage = async () => {
  const payments = await getAllPayments();
  localStorage.setItem('payments', JSON.stringify(payments));
};

// Sync all data to localStorage
const syncAllDataToLocalStorage = async () => {
  console.log('🔄 Syncing IndexedDB data to localStorage...');
  await syncToLocalStorage();
  await syncBatchesToLocalStorage();
  await syncLocationsToLocalStorage();
  await syncTeachersToLocalStorage();
  await syncPaymentsToLocalStorage();
  await syncCategoriesToLocalStorage();
  await syncTeacherPaymentsToLocalStorage();
  console.log('✅ Sync completed!');
};

// Force sync - useful for testing
export const forceSyncToLocalStorage = async () => {
  await syncAllDataToLocalStorage();
};

// Category specific functions
export const saveCategory = async (category: any) => {
  // Ensure category has an id field
  const categoryData = {
    ...category,
    id: category.id || `CAT-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    createdAt: category.createdAt || new Date().toISOString()
  };
  await saveData(CATEGORY_STORE, categoryData);
  await syncCategoriesToLocalStorage();
};

export const getAllCategories = async () => {
  return await getAllData(CATEGORY_STORE);
};

export const deleteCategory = async (id: string) => {
  await deleteData(CATEGORY_STORE, id);
  await syncCategoriesToLocalStorage();
};

// Sync categories to localStorage
const syncCategoriesToLocalStorage = async () => {
  const categories = await getAllCategories();
  localStorage.setItem('categories', JSON.stringify(categories));
};

// Teacher Payment specific functions
export const saveTeacherPayment = async (payment: any): Promise<void> => {
  await saveData(TEACHER_PAYMENT_STORE, payment);
  await syncTeacherPaymentsToLocalStorage();
};

export const getAllTeacherPayments = async (): Promise<any[]> => {
  return await getAllData(TEACHER_PAYMENT_STORE);
};

export const getTeacherPaymentsByTeacherId = async (teacherId: string): Promise<any[]> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([TEACHER_PAYMENT_STORE], 'readonly');
    const store = transaction.objectStore(TEACHER_PAYMENT_STORE);
    const index = store.index('teacherId');
    const request = index.getAll(teacherId);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

export const deleteTeacherPayment = async (id: number): Promise<void> => {
  await deleteData(TEACHER_PAYMENT_STORE, id);
  await syncTeacherPaymentsToLocalStorage();
};

// Sync teacher payments to localStorage
const syncTeacherPaymentsToLocalStorage = async () => {
  const teacherPayments = await getAllTeacherPayments();
  localStorage.setItem('teacherPayments', JSON.stringify(teacherPayments));
};


// ============================================================================
// BOOK EVENTS (standalone section - not linked to students / fees)
// ============================================================================
export const saveEvent = async (event: any): Promise<void> => {
  const data = {
    ...event,
    id: event.id || `EVT-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
  };
  await saveData(BOOK_EVENT_STORE, data);
};

export const getAllEvents = async (): Promise<any[]> => {
  return await getAllData(BOOK_EVENT_STORE);
};

export const deleteEvent = async (id: string): Promise<void> => {
  await deleteData(BOOK_EVENT_STORE, id);
};
