// Storage Adapter - Automatically uses IndexedDB with localStorage fallback
// This file provides a unified API for all data operations

import * as IndexedDBLib from './indexedDB';

// ============================================================================
// STUDENTS
// ============================================================================

export const getStudents = async (): Promise<any[]> => {
  try {
    // Lite = no photos (Dashboard/Login only read text fields). Much faster/lighter with thousands of students.
    const students = await IndexedDBLib.getStudentsLite();
    // Deactivated students should never appear outside the Deactivated Students section
    return students.filter((s: any) => !s.deactivated);
  } catch (error) {
    console.error('Error getting students from IndexedDB, falling back to localStorage:', error);
    const local = JSON.parse(localStorage.getItem('students') || '[]');
    return local.filter((s: any) => !s.deactivated);
  }
};

export const saveStudentData = async (student: any): Promise<void> => {
  await IndexedDBLib.saveStudent(student);
};

export const deleteStudentData = async (regNo: string): Promise<void> => {
  await IndexedDBLib.deleteStudent(regNo);
};

export const searchStudents = async (searchTerm: string): Promise<any | null> => {
  const students = await getStudents();
  const term = searchTerm.toLowerCase();
  
  return students.find((s: any) => 
    s.name.toLowerCase().includes(term) ||
    s.regNo.toLowerCase().includes(term) ||
    s.mobile.includes(searchTerm) ||
    s.alternateMobile?.includes(searchTerm) ||
    s.email?.toLowerCase().includes(term)
  ) || null;
};

// ============================================================================
// PAYMENTS
// ============================================================================

export const getPayments = async (): Promise<any[]> => {
  try {
    return await IndexedDBLib.getAllPayments();
  } catch (error) {
    console.error('Error getting payments from IndexedDB:', error);
    return JSON.parse(localStorage.getItem('payments') || '[]');
  }
};

export const getPaymentsByStudent = async (regNo: string): Promise<any[]> => {
  try {
    return await IndexedDBLib.getPaymentsByRegNo(regNo);
  } catch (error) {
    console.error('Error getting payments from IndexedDB:', error);
    const payments = JSON.parse(localStorage.getItem('payments') || '[]');
    return payments.filter((p: any) => p.regNo === regNo);
  }
};

export const savePaymentData = async (payment: any): Promise<void> => {
  await IndexedDBLib.savePayment(payment);
};

export const deletePaymentData = async (paymentId: number): Promise<void> => {
  await IndexedDBLib.deletePayment(paymentId);
};

export const deletePaymentsByStudent = async (regNo: string): Promise<void> => {
  await IndexedDBLib.deletePaymentsByRegNo(regNo);
};

// ============================================================================
// BATCHES
// ============================================================================

export const getBatches = async (): Promise<any[]> => {
  try {
    return await IndexedDBLib.getAllBatches();
  } catch (error) {
    console.error('Error getting batches from IndexedDB:', error);
    return JSON.parse(localStorage.getItem('batches') || '[]');
  }
};

export const saveBatchData = async (batch: any): Promise<void> => {
  await IndexedDBLib.saveBatch(batch);
};

export const deleteBatchData = async (batchTime: string): Promise<void> => {
  await IndexedDBLib.deleteBatch(batchTime);
};

// ============================================================================
// LOCATIONS
// ============================================================================

export const getLocations = async (): Promise<any[]> => {
  try {
    return await IndexedDBLib.getAllLocations();
  } catch (error) {
    console.error('Error getting locations from IndexedDB:', error);
    return JSON.parse(localStorage.getItem('locations') || '[]');
  }
};

export const saveLocationData = async (location: any): Promise<void> => {
  await IndexedDBLib.saveLocation(location);
};

export const deleteLocationData = async (name: string): Promise<void> => {
  await IndexedDBLib.deleteLocation(name);
};

// ============================================================================
// TEACHERS
// ============================================================================

export const getTeachers = async (): Promise<any[]> => {
  try {
    return await IndexedDBLib.getAllTeachers();
  } catch (error) {
    console.error('Error getting teachers from IndexedDB:', error);
    return JSON.parse(localStorage.getItem('teachers') || '[]');
  }
};

export const saveTeacherData = async (teacher: any): Promise<void> => {
  await IndexedDBLib.saveTeacher(teacher);
};

export const deleteTeacherData = async (id: string): Promise<void> => {
  await IndexedDBLib.deleteTeacher(id);
};

// ============================================================================
// ADMIN CREDENTIALS
// ============================================================================

export const getAdminCredentials = async (): Promise<{ email: string; password: string }> => {
  try {
    const email = await IndexedDBLib.getSetting('adminUser');
    const password = await IndexedDBLib.getSetting('adminPass');
    
    if (email && password) {
      return { email, password };
    }
    
    // Default credentials
    const defaultCreds = {
      email: 'admin@1234',
      password: 'admin@1234'
    };
    
    // Save default credentials
    await IndexedDBLib.saveSetting('adminUser', defaultCreds.email);
    await IndexedDBLib.saveSetting('adminPass', defaultCreds.password);
    
    return defaultCreds;
  } catch (error) {
    console.error('Error getting admin credentials:', error);
    const savedCreds = localStorage.getItem('adminCredentials');
    if (savedCreds) {
      return JSON.parse(savedCreds);
    }
    return {
      email: 'admin@1234',
      password: 'admin@1234'
    };
  }
};

export const saveAdminCredentials = async (email: string, password: string): Promise<void> => {
  await IndexedDBLib.saveSetting('adminUser', email);
  await IndexedDBLib.saveSetting('adminPass', password);
  // Also save to localStorage for backward compatibility
  localStorage.setItem('adminCredentials', JSON.stringify({ email, password }));
};

// ============================================================================
// BULK OPERATIONS
// ============================================================================

export const importAllData = async (data: any): Promise<void> => {
  await IndexedDBLib.importAllData(data);
};

export const exportAllData = async (): Promise<any> => {
  const students = await getStudents();
  const payments = await getPayments();
  const batches = await getBatches();
  const locations = await getLocations();
  const teachers = await getTeachers();
  const adminCreds = await getAdminCredentials();
  
  return {
    students,
    payments,
    batches,
    locations,
    teachers,
    adminCredentials: adminCreds,
    exportDate: new Date().toISOString(),
    version: '64.0',
    appName: 'Mayuri Dance & Fitness Academy - POS System'
  };
};

// ============================================================================
// MIGRATION
// ============================================================================

export const migrateData = async (): Promise<void> => {
  await IndexedDBLib.migrateFromLocalStorage();
};
