// Events — CMS side (same pattern as QR Enquiry / Online Admission / Google Review).
//
// Flow:  Settings -> Event Forms (toggle ON)  ->  sidebar me "Events" aata hai
//        Events -> Create me event banta hai  ->  CMS event ka form Google Sheet ("EvtEvents" tab) ko bhejta hai
//        Student link / QR se form bharta hai  ->  Google Sheet ke "EvtSubmissions" tab me row aati hai
//        CMS har ~10 sec me chhota "version" check karta hai; nayi row ho to turant le leta hai
//        aur apne LOCAL storage (IndexedDB) me save kar leta hai. CMS me jo dikhta hai wo local se hi dikhta hai.
//
// Google Sheet sirf beech ka rasta hai: wahan rows 7 din baad apne aap delete ho jati hain, lekin CMS me
// registration kabhi isse delete nahi hoti (sirf admin ke Delete dabane par).
//
// Ye Attendance wale Google Apps Script ka hi extra hissa hai (same web app URL, koi alag script nahi), isliye pehle
// Settings -> Management & Setup -> Attendance Setup me script connect hona chahiye.

import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { getSetting, saveSetting } from '../../lib/indexedDB';
import { getAttendanceConfig, isAttendanceConnected, scriptGet, scriptPost } from '../../lib/attendance';
import { safeColor, validBg } from './eventTemplates';
import {
  EventRecord, EventSubmission, getAllRemoteIds, getEventFormsEnabled, listEvents, listSubmissions,
  saveEventFormsEnabled, saveSubmission, newId, EVENT_FORMS_TOGGLED, EVENTS_CHANGED,
} from './eventsDb';

const KEY_CFG_HASH = 'eventsCfgHash';
const KEY_LAST_SEQ = 'eventsLastSeq';   // sheet ki kitni rows tak CMS le chuka hai
const KEY_SEQ_URL = 'eventsSeqUrl';      // kis web app link ka counter hai (link badle to counter naye sire se)

export const EVENT_SUBMISSIONS_UPDATED = 'eventSubmissionsUpdated'; // local storage me nayi online registration aayi
const POLL_MS = 10000;

// ---------- errors ----------

export function eventsError(e: any): string {
  const msg = String(e?.message || e || '');
  if (/evt[A-Z]\w*_|evtForm|evtSubmit|is not defined|unknown action/i.test(msg)) {
    return 'Google Script purani hai. Settings → Management & Setup → Attendance Setup se naya code copy karke Apps Script me paste karein aur dobara Deploy karein (script ek hi hai).';
  }
  return msg || 'Google Sheet se baat nahi ho payi.';
}

export type RelayStatus = 'not_connected' | 'script_old' | 'ok' | 'error';

/** Attendance script connected hai aur usme Events ka hissa hai ya nahi. */
export async function getRelayStatus(): Promise<RelayStatus> {
  if (!(await isAttendanceConnected())) return 'not_connected';
  try {
    const cfg = await getAttendanceConfig();
    await scriptGet(cfg.webAppUrl, cfg.adminKey, { action: 'evt_version' });
    return 'ok';
  } catch (e: any) {
    return /unknown action|is not defined|evt/i.test(String(e?.message || '')) ? 'script_old' : 'error';
  }
}

// ---------- on / off (Settings -> Event Forms) ----------

/** Toggle turant save hota hai (sidebar me Events aa jata / chala jata hai). Sheet ko batana (open / band) best-effort hai.
 *  OFF karne se koi data delete nahi hota - sirf section chhupta hai aur public links band hote hain. */
export async function setEventFormsEnabled(enabled: boolean): Promise<{ pushed: boolean; error?: string }> {
  await saveEventFormsEnabled(enabled);
  try {
    return { pushed: await pushEventsConfig(true) };
  } catch (e: any) {
    return { pushed: false, error: eventsError(e) };
  }
}

export function useEventFormsEnabled(): boolean {
  const [on, setOn] = useState(false);
  useEffect(() => {
    let alive = true;
    const load = () => getEventFormsEnabled().then((v) => { if (alive) setOn(v); });
    load();
    window.addEventListener(EVENT_FORMS_TOGGLED, load);
    return () => { alive = false; window.removeEventListener(EVENT_FORMS_TOGGLED, load); };
  }, []);
  return on;
}

// ---------- links ----------

export async function getPublicLink(eventId: string): Promise<string> {
  const cfg = await getAttendanceConfig();
  return cfg.webAppUrl ? `${cfg.webAppUrl}?page=event&id=${encodeURIComponent(eventId)}` : '';
}

export const eventCode = (ev: EventRecord) =>
  (ev.name.replace(/[^A-Za-z0-9]/g, '').slice(0, 3) + ev.id.replace(/[^A-Za-z0-9]/g, '').slice(-2)).toUpperCase();

/** Sirf wahi cheezein jo public form ko chahiye (koi admin / registration data nahi). */
export function toPublicJson(ev: EventRecord, offlineCount: number) {
  return {
    name: ev.name, date: ev.date, venue: ev.venue, description: ev.description, fee: ev.fee,
    max: ev.maxRegistrations || 0, offline: offlineCount, code: eventCode(ev), color: safeColor(ev.themeColor),
    titleFont: ev.titleFont || 'sans', titleBold: ev.titleBold !== false, titleAlign: ev.titleAlign || 'left', bg: validBg(ev.bgColor),
    fields: ev.formFields
      .filter((f) => !f.archived)
      .sort((a, b) => a.order - b.order)
      .map(({ key, label, type, required, options, placeholder, helpText }) => ({ key, label, type, required, options: options || [], placeholder: placeholder || '', helpText: helpText || '' })),
  };
}

// ---------- CMS -> Google Sheet (events + open / band) ----------

/** Saare events ek saath bhejta hai. Pehle jaisa ho to kuch nahi bhejta. */
export async function pushEventsConfig(force = false): Promise<boolean> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) return false;
  const enabled = await getEventFormsEnabled();
  const events: any[] = [];
  for (const ev of await listEvents()) {                // delete hue events nahi jate -> unka link band ho jata hai
    if (ev.externalFormUrl) continue;                   // external Google Form: iska data yahan nahi aata
    const offline = (await listSubmissions(ev.id)).filter((s) => s.source === 'offline').length;
    events.push({ id: ev.id, status: ev.status, json: toPublicJson(ev, offline) });
  }
  const hash = JSON.stringify([cfg.webAppUrl, enabled, events]);
  if (!force && (await getSetting(KEY_CFG_HASH)) === hash) return false;
  await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'evt_config', enabled, events }, 60000);
  await saveSetting(KEY_CFG_HASH, hash);
  return true;
}

/** UI se: event save / open / close / offline entry ke baad Sheet ko turant update karne ke liye. */
export const syncEventToRelay = (_ev?: EventRecord) => pushEventsConfig(true);
export const removeEventFromRelay = (_id?: string) => pushEventsConfig(true);

// ---------- Sheet -> local storage ----------

let syncing = false;

/** Sheet se nayi registrations leta hai aur LOCAL storage me save karta hai. Kitni nayi aayi wo wapas deta hai. */
export async function syncEventSubmissions(): Promise<number> {
  if (syncing) return 0;
  syncing = true;
  try {
    const cfg = await getAttendanceConfig();
    if (!cfg.webAppUrl) return 0;

    // Naya web app link = naya sheet = counter 0 se shuru
    if ((await getSetting(KEY_SEQ_URL)) !== cfg.webAppUrl) {
      await saveSetting(KEY_LAST_SEQ, 0);
      await saveSetting(KEY_SEQ_URL, cfg.webAppUrl);
    }
    let last = Number(await getSetting(KEY_LAST_SEQ)) || 0;

    // Bahut halka check: kuch naya hai ya nahi
    const v = await scriptGet(cfg.webAppUrl, cfg.adminKey, { action: 'evt_version' });
    const ver = Number(v.ver) || 0;
    if (ver === last) return 0;
    if (ver < last) last = 0; // sheet / script naya ho gaya -> sab dobara dekho (id se duplicate nahi banta)

    let added = 0;
    let firstEvent = '';
    const known = await getAllRemoteIds();
    const eventNames = new Map((await listEvents(true)).map((e) => [e.id, e.name] as const));

    for (let round = 0; round < 15; round++) {
      const d = await scriptGet(cfg.webAppUrl, cfg.adminKey, { action: 'evt_list', since: String(last) });
      const items: any[] = d.items || [];
      if (items.length === 0) {
        // Naye rows 7 din baad delete ho chuke: counter ko aage badha do taaki baar baar list na maange
        if (ver > last) { last = ver; await saveSetting(KEY_LAST_SEQ, last); }
        break;
      }
      for (const it of items) {
        const remoteId = String(it.id);
        // Jo event CMS me hai hi nahi (hamesha ke liye delete) uski registration nahi li jati, par counter aage badhta hai
        if (!known.has(remoteId) && eventNames.has(it.eventId)) {
          const sub: EventSubmission = {
            id: newId('sub'), event_id: it.eventId, data: it.data || {}, source: 'online',
            payment_status: 'unpaid', registration_id: String(it.regId), created_at: Number(it.ms) || Date.now(), remoteId,
          };
          await saveSubmission(sub);   // pehle local me save...
          known.add(remoteId);
          added++;
          if (!firstEvent) firstEvent = eventNames.get(it.eventId) || '';
        }
        last = Math.max(last, Number(it.seq) || 0);
      }
      await saveSetting(KEY_LAST_SEQ, last); // ...phir counter aage (beech me band ho to dobara le leta hai)
      if (!d.more) break;
    }

    if (added > 0) {
      window.dispatchEvent(new CustomEvent(EVENT_SUBMISSIONS_UPDATED, { detail: added }));
      toast.success(added === 1 ? `Nayi event registration: ${firstEvent}` : `${added} nayi event registrations aayi`);
    }
    return added;
  } finally {
    syncing = false;
  }
}

// ---------- background sync (AdminDashboard me ek baar mount hota hai) ----------
// 1) event badle / toggle badle to config Sheet ko bhejta hai
// 2) har ~10 sec me nayi registration check karta hai (toggle ON ho tabhi; app chhupi ho to ruk jata hai)

export function useEventsSync() {
  useEffect(() => {
    let stopped = false;
    let running = false;
    let cfgTimer: any = null;

    const pushSoon = () => {
      clearTimeout(cfgTimer);
      cfgTimer = setTimeout(async () => {
        try { if (await getEventFormsEnabled()) await pushEventsConfig(); } catch { /* agli baar phir koshish */ }
      }, 3000);
    };
    window.addEventListener(EVENTS_CHANGED, pushSoon);
    pushSoon();

    const tick = async () => {
      if (stopped || running || document.hidden) return;
      running = true;
      try {
        if (await getEventFormsEnabled()) await syncEventSubmissions();
      } catch { /* net slow / band: agli baar */ }
      running = false;
    };
    tick();
    const iv = setInterval(tick, POLL_MS);
    const onVisible = () => { if (!document.hidden) tick(); };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('online', tick);
    window.addEventListener(EVENT_FORMS_TOGGLED, tick);

    return () => {
      stopped = true;
      clearInterval(iv);
      clearTimeout(cfgTimer);
      window.removeEventListener(EVENTS_CHANGED, pushSoon);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('online', tick);
      window.removeEventListener(EVENT_FORMS_TOGGLED, tick);
    };
  }, []);
}
