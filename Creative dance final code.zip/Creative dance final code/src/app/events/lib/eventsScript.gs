/* =========================================================
 *  EVENTS  (Event form  ->  Google Sheet  ->  CMS)
 *  Ye hissa attendance script ke saath jud kar chalta hai (same script, same URL).
 *  Public link:  <web app url>?page=event&id=<eventId>   (link CMS ke Events section se milta hai)
 *
 *  Flow:
 *   1) CMS apne events (form fields, open / band, limit) Sheet ke "EvtEvents" tab me bhejta hai (evt_config).
 *   2) Student form bharta hai -> evtSubmit() -> "EvtSubmissions" tab me ek row + unique Registration ID.
 *   3) CMS har ~10 sec me evt_version dekhta hai (bahut chhota check). Number badla ho to evt_list se sirf
 *      nayi rows leta hai aur turant apne local storage (IndexedDB) me save kar leta hai.
 *   4) CMS ne jo ek baar le liya wo dobara nahi aata (har row ka seq number hota hai).
 *   5) Google Sheet me rows sirf 7 din rehti hain, phir apne aap delete ho jati hain (sheet khali rahe).
 *      CMS me event ka data kabhi isse delete nahi hota - wo sirf admin ke Delete dabane par hatta hai.
 *
 *  Koi photo / file nahi, isliye data chhota aur tez. Sab naye functions ka naam evt... se shuru hota hai,
 *  taaki attendance / admission / enquiry / review ke naam se na takraein.
 * ========================================================= */

var SHEET_EVT_EVENTS = 'EvtEvents';
var SHEET_EVT_SUBS = 'EvtSubmissions';
var EVT_EVENT_HEADERS = ['EventId', 'Json', 'Status', 'RegSeq', 'UpdatedMs'];
var EVT_SUB_HEADERS = ['SubId', 'Seq', 'Time', 'TimeMs', 'EventId', 'RegId', 'DataJson'];
var EVT_MAX_ROWS = 3000;          // 7 din me isse zyada aaye to nayi registration nahi leta (sheet bhaari na ho)
var EVT_RATE_PER_MIN = 40;        // ek event par ek minute me max submissions
var EVT_MIN_FILL_MS = 3000;       // isse jaldi submit = bot
var EVT_LIST_MAX = 200;           // CMS ko ek baar me itni rows
var EVT_MAX_LEN = 500;            // har field ki max length
var EVT_MAX_EVENTS = 200;
var EVT_MAX_JSON = 20000;         // ek event ke form ka max size
var EVT_HTML = __EVT_HTML__;

/* ---------------------------------------------------------
 *  SHEETS
 * --------------------------------------------------------- */
function evtEventsSheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(SHEET_EVT_EVENTS) || ensureSheet_(ss, SHEET_EVT_EVENTS, EVT_EVENT_HEADERS);
}
function evtSubsSheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(SHEET_EVT_SUBS) || ensureSheet_(ss, SHEET_EVT_SUBS, EVT_SUB_HEADERS);
}
function evtEnabled_() { return getProp_('evtEnabled', '0') === '1'; }

/* VERSION = sabse naye row ka seq number (CMS bina list mange pata kar leta hai kuch aaya ya nahi) */
function evtVer_() { return Number(getProp_('evtSeq', '0')); }
function evtNextSeq_() {
  var next = evtVer_() + 1;
  setProp_('evtSeq', String(next));
  return next;
}

// Event ka row (public form ke liye). Cache nahi: events kam hote hain aur seq sahi chahiye.
function evtFind_(id) {
  var sh = evtEventsSheet_();
  var last = sh.getLastRow();
  if (last < 2) return null;
  var vals = sh.getRange(2, 1, last - 1, EVT_EVENT_HEADERS.length).getValues();
  for (var i = 0; i < vals.length; i++) {
    if (String(vals[i][0]) === id) {
      var ev = {};
      try { ev = JSON.parse(String(vals[i][1])); } catch (e) {}
      return { row: i + 2, ev: ev, status: String(vals[i][2]), regSeq: Number(vals[i][3]) || 0 };
    }
  }
  return null;
}

/* ---------------------------------------------------------
 *  TEXT SAFAI + VALIDATION  (server par dobara poori check)
 * --------------------------------------------------------- */
function evtStr_(v, max) {
  var s = String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim();
  s = s.replace(/^[=+\-@]+/, '').trim();   // Sheet me formula na ban sake
  return s.slice(0, max || EVT_MAX_LEN);
}

function evtValidate_(fields, data) {
  var clean = {};
  data = data || {};
  for (var i = 0; i < fields.length; i++) {
    var f = fields[i];
    var v = data[f.key];
    var label = f.label || 'Field';
    if (f.type === 'yesno') {
      clean[f.key] = String(v == null ? '' : v).toLowerCase() === 'yes' ? 'Yes' : 'No';
      continue;
    }
    if (f.type === 'checkbox' || f.type === 'multiselect') {
      var arr = Array.isArray(v) ? v : (v ? [v] : []);
      var out = [];
      for (var j = 0; j < arr.length; j++) {
        var c = evtStr_(arr[j], 100);
        if (c && (f.options || []).indexOf(c) !== -1 && out.indexOf(c) === -1) out.push(c);
      }
      if (f.required && !out.length) return { ok: false, message: label + ' me kam se kam ek option chunein.' };
      clean[f.key] = out;
      continue;
    }
    var s = evtStr_(v);
    if (!s) {
      if (f.required) return { ok: false, message: label + ' zaroori hai.' };
      clean[f.key] = '';
      continue;
    }
    if ((f.type === 'number' || f.type === 'amount') && !/^-?\d+(\.\d+)?$/.test(s)) return { ok: false, message: label + ' me sirf number likhein.' };
    if (f.type === 'time' && !/^\d{2}:\d{2}$/.test(s)) return { ok: false, message: label + ' sahi time nahi hai.' };
    if (f.type === 'datetime' && !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(s)) return { ok: false, message: label + ' sahi date & time nahi hai.' };
    if (f.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s)) return { ok: false, message: label + ' sahi email nahi hai.' };
    if (f.type === 'phone') {
      var digits = s.replace(/\D/g, '');
      if (digits.length === 12 && digits.indexOf('91') === 0) digits = digits.slice(2);
      if (digits.length < 10 || digits.length > 15) return { ok: false, message: label + ' sahi mobile number nahi hai.' };
      s = digits;
    }
    if (f.type === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(s)) return { ok: false, message: label + ' sahi date nahi hai.' };
    if ((f.type === 'dropdown' || f.type === 'radio') && (f.options || []).indexOf(s) === -1) return { ok: false, message: label + ' me sahi option chunein.' };
    clean[f.key] = s;
  }
  return { ok: true, clean: clean };
}

/* ---------------------------------------------------------
 *  PUBLIC PAGE  (google.script.run se: evtForm, evtSubmit)
 *  Ye functions koi bhi chala sakta hai, isliye inme sirf public cheezein hain.
 * --------------------------------------------------------- */
function evtPage_(id) {
  var safe = String(id || '').replace(/[^A-Za-z0-9_\-]/g, '').slice(0, 60);
  var html = EVT_HTML.replace('__EVENT_ID__', function () { return safe; });
  return HtmlService.createHtmlOutput(html)
    .setTitle('Event Registration')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

// Form dikhane layak data. Admin ka ya dusre students ka koi data nahi.
function evtForm(id) {
  try {
    id = String(id || '').replace(/[^A-Za-z0-9_\-]/g, '').slice(0, 60);
    if (!evtEnabled_()) return { state: 'off' };
    var r = evtFind_(id);
    if (!r) return { state: 'missing' };
    var ev = r.ev;
    var state = 'open';
    if (r.status !== 'open') state = 'closed';
    else if (Number(ev.max) > 0 && (r.regSeq + (Number(ev.offline) || 0)) >= Number(ev.max)) state = 'full';
    var base = getConfigCached_();
    return {
      state: state,
      businessName: base.businessName,
      event: { id: id, name: ev.name, date: ev.date, venue: ev.venue, description: ev.description, fee: Number(ev.fee) || 0, fields: ev.fields || [], 
               color: /^#[0-9a-fA-F]{6}$/.test(String(ev.color || '')) ? ev.color : '#ea580c',
               titleFont: ['sans', 'serif', 'elegant', 'rounded', 'display', 'script', 'mono'].indexOf(ev.titleFont) !== -1 ? ev.titleFont : 'sans',
               titleBold: ev.titleBold !== false,
               titleAlign: ['left', 'center', 'right'].indexOf(ev.titleAlign) !== -1 ? ev.titleAlign : 'left',
               bg: /^#[0-9a-fA-F]{6}$/.test(String(ev.bg || '')) ? ev.bg : '' }
    };
  } catch (err) {
    return { state: 'error' };
  }
}

function evtSubmit(id, data, hp, elapsedMs) {
  try {
    id = String(id || '').replace(/[^A-Za-z0-9_\-]/g, '').slice(0, 60);
    if (hp) return { ok: false, message: 'Form submit nahi hua. Page refresh karke dobara try karein.' }; // honeypot
    if (Number(elapsedMs) < EVT_MIN_FILL_MS) return { ok: false, message: 'Form bahut jaldi submit hua. Dobara try karein.' };
    if (!data || typeof data !== 'object') return { ok: false, message: 'Request sahi nahi hai.' };
    if (!evtEnabled_()) return { ok: false, message: 'Registration abhi band hai.' };

    var lock = LockService.getScriptLock();
    if (!lock.tryLock(15000)) return { ok: false, message: 'Server busy hai. Dobara try karein.' };
    try {
      var r = evtFind_(id);
      if (!r) return { ok: false, message: 'Event nahi mila.' };
      if (r.status !== 'open') return { ok: false, message: 'Is event ki registration band ho chuki hai.' };
      var ev = r.ev;
      if (Number(ev.max) > 0 && (r.regSeq + (Number(ev.offline) || 0)) >= Number(ev.max)) return { ok: false, message: 'Registration full ho chuki hai.' };

      var cache = CacheService.getScriptCache();
      var minKey = 'evtrate_' + id + '_' + Math.floor(Date.now() / 60000);
      var n = Number(cache.get(minKey) || 0);
      if (n >= EVT_RATE_PER_MIN) return { ok: false, message: 'Abhi bahut zyada requests aa rahi hain. Thodi der baad try karein.' };
      cache.put(minKey, String(n + 1), 120);

      var v = evtValidate_(ev.fields || [], data);
      if (!v.ok) return v;
      var json = JSON.stringify(v.clean);

      var sh = evtSubsSheet_();
      var last = sh.getLastRow();
      if (last - 1 >= EVT_MAX_ROWS) return { ok: false, message: 'Abhi registration nahi li ja sakti. Organiser se sampark karein.' };

      var nowMs = Date.now();
      // Double tap: pichli 30 rows me isi event ka bilkul same data 10 min ke andar ho to wahi Registration ID wapas
      if (last >= 2) {
        var from = Math.max(2, last - 29);
        var recent = sh.getRange(from, 4, last - from + 1, 4).getValues(); // TimeMs, EventId, RegId, DataJson
        for (var i = 0; i < recent.length; i++) {
          if (String(recent[i][1]) === id && String(recent[i][3]) === json && nowMs - Number(recent[i][0]) < 10 * 60 * 1000) {
            return { ok: true, regId: String(recent[i][2]) };
          }
        }
      }

      var regSeq = r.regSeq + 1;
      var code = String(ev.code || 'REG').replace(/[^A-Za-z0-9]/g, '').slice(0, 6).toUpperCase() || 'REG';
      var regId = code + '-' + ('0000' + regSeq).slice(-4);
      var subId = 'EV-' + Utilities.formatDate(new Date(nowMs), TZ, 'yyMMddHHmmss') + '-' + Math.floor(1000 + Math.random() * 9000);
      var stamp = Utilities.formatDate(new Date(nowMs), TZ, "yyyy-MM-dd'T'HH:mm:ss");
      var seq = evtNextSeq_();
      evtEventsSheet_().getRange(r.row, 4).setValue(String(regSeq));
      sh.appendRow([subId, seq, stamp, nowMs, id, regId, json]);
      return { ok: true, regId: regId };
    } finally {
      try { lock.releaseLock(); } catch (x) {}
    }
  } catch (err) {
    return { ok: false, message: 'Kuch gadbad ho gayi. Dobara try karein.' };
  } finally {
    evtMaybeCleanup_();
  }
}

/* ---------------------------------------------------------
 *  CMS ACTIONS  (ADMIN_KEY ke saath - doGet / doPost me pehle hi check ho chuka hota hai)
 * --------------------------------------------------------- */
function evtGet_(p) {
  if (p.action === 'evt_version') return { success: true, ver: evtVer_(), enabled: evtEnabled_() };
  if (p.action === 'evt_list') return evtList_(Number(p.since) || 0);
  return { success: false, error: 'unknown action' };
}

function evtPost_(body) {
  if (body.action === 'evt_config') return evtSaveConfig_(body);
  return { success: false, error: 'unknown action' };
}

// CMS ke saare events ek saath: Sheet me wahi rehte hain jo CMS me hain (hataye gaye events yahan se bhi hat jate hain).
// Har event ka RegSeq (Registration ID counter) purana hi rehta hai.
function evtSaveConfig_(body) {
  var sh = evtEventsSheet_();
  var oldSeq = {};
  var last = sh.getLastRow();
  if (last >= 2) {
    var old = sh.getRange(2, 1, last - 1, 4).getValues();
    for (var i = 0; i < old.length; i++) oldSeq[String(old[i][0])] = Number(old[i][3]) || 0;
  }
  var rows = [];
  var list = body.events || [];
  var now = String(Date.now());
  for (var k = 0; k < list.length && rows.length < EVT_MAX_EVENTS; k++) {
    var e = list[k] || {};
    var id = String(e.id || '').replace(/[^A-Za-z0-9_\-]/g, '').slice(0, 60);
    if (!id) continue;
    var json = JSON.stringify(e.json || {});
    if (json.length > EVT_MAX_JSON) continue;
    rows.push([id, json, e.status === 'closed' ? 'closed' : 'open', String(oldSeq[id] || 0), now]);
  }
  if (last >= 2) sh.getRange(2, 1, last - 1, EVT_EVENT_HEADERS.length).clearContent();
  if (rows.length) sh.getRange(2, 1, rows.length, EVT_EVENT_HEADERS.length).setValues(rows);
  setProp_('evtEnabled', body.enabled === true ? '1' : '0');
  evtSubsSheet_(); // tab pehle se bana ho
  return { success: true, ver: evtVer_(), count: rows.length };
}

// "since" ke baad ki sirf nayi rows (seq ke hisaab se, purani pehle)
function evtList_(since) {
  var sh = evtSubsSheet_();
  var last = sh.getLastRow();
  var items = [];
  var more = false;
  if (last >= 2) {
    var rows = sh.getRange(2, 1, last - 1, EVT_SUB_HEADERS.length).getValues();
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      var seq = Number(r[1]) || 0;
      if (seq <= since) continue;
      var d = {};
      try { d = JSON.parse(String(r[6])); } catch (e) {}
      items.push({ id: String(r[0]), seq: seq, ms: Number(r[3]) || 0, eventId: String(r[4]), regId: String(r[5]), data: d });
    }
    items.sort(function (a, b) { return a.seq - b.seq; });
    if (items.length > EVT_LIST_MAX) { items = items.slice(0, EVT_LIST_MAX); more = true; }
  }
  return { success: true, ver: evtVer_(), items: items, more: more };
}

/* ---------------------------------------------------------
 *  7 DIN BAAD AUTO DELETE (sirf Google Sheet se; CMS ka data nahi chhuta)
 *  Roz raat attendance ki safai ke saath chalta hai (cleanupOldAttendance_ isse bulata hai).
 *  Timer na bhi ho to din ki pehli registration ke saath bhi safai ho jati hai.
 * --------------------------------------------------------- */
function evtCleanup_() {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_EVT_SUBS);
  if (!sh || sh.getLastRow() < 2) return 0;
  var cutoff = Date.now() - KEEP_DAYS * 86400000;
  var last = sh.getLastRow();
  var times = sh.getRange(2, 4, last - 1, 1).getValues();
  var removed = 0;
  // rows time ke hisaab se upar se neeche chalti hain, isliye purani rows hamesha upar milti hain
  var start = -1, runs = [];
  for (var i = 0; i < times.length; i++) {
    var old = Number(times[i][0]) > 0 && Number(times[i][0]) < cutoff;
    if (old && start < 0) start = i;
    if (!old && start >= 0) { runs.push([start, i - 1]); start = -1; }
  }
  if (start >= 0) runs.push([start, times.length - 1]);
  for (var r = runs.length - 1; r >= 0; r--) {
    var count = runs[r][1] - runs[r][0] + 1;
    // Sheet me kam se kam ek non-frozen row bachni chahiye, warna delete fail ho jata hai
    if (sh.getMaxRows() - count < 2) sh.insertRowsAfter(sh.getMaxRows(), 50);
    sh.deleteRows(runs[r][0] + 2, count);
    removed += count;
  }
  return removed;
}

function evtMaybeCleanup_() {
  try {
    var day = today_();
    if (getProp_('evtCleanDay', 'x') === day) return;
    setProp_('evtCleanDay', day);
    evtCleanup_();
  } catch (e) {}
}

/* ---------------------------------------------------------
 *  SIRF TEST KE LIYE (CMS jodne se pehle page check karna ho to)
 *  Function list se evtTestSetup chuno -> Run. Phir <web app url>?page=event&id=testevent kholo.
 *  CMS jab apna config bhejta hai to ye test config apne aap badal jata hai.
 * --------------------------------------------------------- */
function evtTestSetup() {
  evtSaveConfig_({
    enabled: true,
    events: [{ id: 'testevent', status: 'open', json: {
      name: 'Test Event', date: '2030-01-01', venue: 'Hall', description: 'Test', fee: 100, code: 'TST',
      fields: [
        { key: 'f_name', label: 'Full Name', type: 'text', required: true },
        { key: 'f_phone', label: 'Mobile', type: 'phone', required: true },
        { key: 'f_size', label: 'T-Shirt', type: 'radio', required: true, options: ['S', 'M', 'L'] }
      ]
    } }]
  });
  return 'OK - ab ?page=event&id=testevent kholo';
}
