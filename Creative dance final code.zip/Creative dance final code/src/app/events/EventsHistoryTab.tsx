import { useCallback, useEffect, useState } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { toast } from 'sonner';
import { Calendar, Copy, Download, FileText, Lock, LockOpen, MapPin, Pencil, Trash2, Users, History } from 'lucide-react';
import { ConfirmDialog } from './ConfirmDialog';
import { RecentlyDeleted } from './RecentlyDeleted';
import { SubmissionsView } from './SubmissionsView';
import { selectCls } from './FormBuilder';
import { EventRecord, exportAllEventsData, listEvents, listSubmissions, saveEvent, softDeleteEvent } from './lib/eventsDb';
import { EVENT_SUBMISSIONS_UPDATED, getPublicLink, removeEventFromRelay, syncEventToRelay } from './lib/eventSync';
import { allEventsPdf, blankFormPdf, recordPdf } from './lib/eventPdf';

type Counts = Record<string, { total: number; paid: number }>;
const todayStr = () => new Date().toISOString().slice(0, 10);

// Events -> Events History: all events (active + past) with search/filter and per-event actions.
export function EventsHistoryTab({ onEdit }: { onEdit: (ev: EventRecord) => void }) {
  const [events, setEvents] = useState<EventRecord[]>([]);
  const [counts, setCounts] = useState<Counts>({});
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<'all' | 'open' | 'closed' | 'past'>('all');
  const [viewing, setViewing] = useState<EventRecord | null>(null);
  const [del, setDel] = useState<EventRecord | null>(null);
  const [showDeleted, setShowDeleted] = useState(false);

  const load = useCallback(async () => {
    const list = await listEvents();
    const c: Counts = {};
    for (const e of list) { const s = await listSubmissions(e.id); c[e.id] = { total: s.length, paid: s.filter(x => x.payment_status === 'paid').length }; }
    setEvents(list); setCounts(c); setLoading(false);
  }, []);
  useEffect(() => {
    load();
    window.addEventListener(EVENT_SUBMISSIONS_UPDATED, load);
    return () => window.removeEventListener(EVENT_SUBMISSIONS_UPDATED, load);
  }, [load]);

  const shown = events.filter(e =>
    (!q.trim() || `${e.name} ${e.venue}`.toLowerCase().includes(q.toLowerCase())) &&
    (filter === 'all' || (filter === 'past' ? e.date < todayStr() : e.status === filter)));

  const copyLink = async (e: EventRecord) => {
    const link = e.externalFormUrl || (await getPublicLink(e.id));
    if (!link) return toast.error('Pehle Attendance Setup me Google script connect karein');
    try { await navigator.clipboard.writeText(link); toast.success('Link copy ho gaya'); } catch { toast.error('Copy nahi hua'); }
  };
  const toggleStatus = async (e: EventRecord) => {
    const next = { ...e, status: e.status === 'open' ? 'closed' as const : 'open' as const };
    await saveEvent(next);
    if (!e.externalFormUrl) syncEventToRelay(next).catch(() => toast.warning('Google script tak status nahi pahuncha (internet/connection check karein)'));
    toast.success(next.status === 'open' ? 'Registration open' : 'Registration band'); load();
  };
  const confirmDelete = async () => {
    if (!del) return;
    await softDeleteEvent(del); removeEventFromRelay(del.id).catch(() => {});
    setDel(null); toast.success('Event delete ho gaya (Recently Deleted me hai)'); load();
  };
  const pdf = async (fn: () => Promise<void>) => { try { await fn(); } catch (err: any) { toast.error(err?.message || 'PDF nahi bana'); } };
  // Saare events (search / filter se alag) ek hi PDF me
  const allPdf = async () => {
    if (events.length === 0) return toast.error('Abhi koi event nahi hai');
    await pdf(async () => allEventsPdf(await Promise.all(events.map(async ev => ({ ev, subs: await listSubmissions(ev.id) })))));
  };
  const exportAll = async () => {
    const data = await exportAllEventsData();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    a.download = `events-data-${todayStr()}.json`; a.click(); URL.revokeObjectURL(a.href);
  };

  if (viewing) return <SubmissionsView ev={viewing} onBack={() => { setViewing(null); load(); }} />;
  if (showDeleted) return (<div className="space-y-3"><Button variant="ghost" onClick={() => { setShowDeleted(false); load(); }}>← Back</Button><RecentlyDeleted onChanged={load} /></div>);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2 items-center">
        <Input className="max-w-xs" placeholder="Search events..." value={q} onChange={e => setQ(e.target.value)} />
        <select className={selectCls + ' max-w-[150px]'} value={filter} onChange={e => setFilter(e.target.value as any)}>
          <option value="all">All</option><option value="open">Open</option><option value="closed">Closed</option><option value="past">Past</option></select>
        <div className="flex-1" />
        <Button variant="outline" onClick={allPdf}><FileText className="w-4 h-4 mr-1" /> All Events PDF</Button>
        <Button variant="outline" onClick={() => setShowDeleted(true)}><History className="w-4 h-4 mr-1" /> Recently Deleted</Button>
        <Button variant="outline" onClick={exportAll}><Download className="w-4 h-4 mr-1" /> Export all events data</Button>
      </div>

      {loading ? <p className="text-sm text-gray-500">Loading...</p> : shown.length === 0 ? (
        <Card className="p-8 text-center text-gray-500">{events.length === 0 ? 'Abhi koi event nahi hai. "Create" tab se naya event banayein.' : 'Koi event match nahi hua.'}</Card>
      ) : shown.map(e => {
        const c = counts[e.id] || { total: 0, paid: 0 };
        return (
          <Card key={e.id} className="p-4 space-y-3">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-2"><h3>{e.name}</h3>
                  <Badge variant={e.status === 'open' ? 'default' : 'secondary'}>{e.status === 'open' ? 'Open' : 'Closed'}</Badge>
                  {e.date < todayStr() && <Badge variant="outline">Past</Badge>}
                  {e.externalFormUrl && <Badge variant="outline">External form</Badge>}</div>
                <div className="text-sm text-gray-600 flex flex-wrap gap-4 mt-1">
                  <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {e.date.split('-').reverse().join('-')}</span>
                  {e.venue && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {e.venue}</span>}
                  <span>{e.fee > 0 ? `\u20B9${e.fee}` : 'Free'}</span>
                  {!e.externalFormUrl && <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {c.total}{e.maxRegistrations ? ` / ${e.maxRegistrations}` : ''} registrations</span>}
                </div>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {!e.externalFormUrl && <Button size="sm" onClick={() => setViewing(e)}><Users className="w-3 h-3 mr-1" /> Submissions</Button>}
              <Button size="sm" variant="outline" onClick={() => onEdit(e)}><Pencil className="w-3 h-3 mr-1" /> Edit</Button>
              <Button size="sm" variant="outline" onClick={() => copyLink(e)}><Copy className="w-3 h-3 mr-1" /> Copy link</Button>
              {!e.externalFormUrl && <>
                <Button size="sm" variant="outline" onClick={() => toggleStatus(e)}>{e.status === 'open' ? <><Lock className="w-3 h-3 mr-1" /> Close</> : <><LockOpen className="w-3 h-3 mr-1" /> Open</>}</Button>
                <Button size="sm" variant="outline" onClick={() => pdf(async () => recordPdf(e, await listSubmissions(e.id)))}><FileText className="w-3 h-3 mr-1" /> Record PDF</Button>
                <Button size="sm" variant="outline" onClick={() => pdf(() => blankFormPdf(e))}><FileText className="w-3 h-3 mr-1" /> Blank Form PDF</Button></>}
              <Button size="sm" variant="ghost" onClick={() => setDel(e)}><Trash2 className="w-4 h-4 text-red-600" /></Button>
            </div>
          </Card>);
      })}

      <ConfirmDialog open={!!del} title="Are you sure you want to delete this event?" onCancel={() => setDel(null)} onConfirm={confirmDelete}>
        {del && <div className="space-y-1"><p><b>{del.name}</b></p><p>Registrations: <b>{counts[del.id]?.total ?? 0}</b></p>
          <p className="text-xs">Ye Recently Deleted me jayega, wahan se restore kar sakte hain. Public link turant band ho jayega.</p></div>}
      </ConfirmDialog>
    </div>
  );
}
