import { useCallback, useEffect, useState } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { toast } from 'sonner';
import { RotateCcw, Trash2 } from 'lucide-react';
import { ConfirmDialog } from './ConfirmDialog';
import { EventRecord, EventSubmission, listDeletedEvents, listDeletedSubmissions, listEvents, purgeEvent, purgeSubmission, restoreEvent, restoreSubmission } from './lib/eventsDb';
import { syncEventToRelay } from './lib/eventSync';

// Events -> Events History -> Recently Deleted (events + registrations). Visible only inside the Events module.
export function RecentlyDeleted({ onChanged }: { onChanged: () => void }) {
  const [events, setEvents] = useState<EventRecord[]>([]);
  const [subs, setSubs] = useState<EventSubmission[]>([]);
  const [names, setNames] = useState<Record<string, string>>({});
  const [purge, setPurge] = useState<{ kind: 'event' | 'sub'; id: string; label: string } | null>(null);

  const load = useCallback(async () => {
    const [de, ds, all] = await Promise.all([listDeletedEvents(), listDeletedSubmissions(), listEvents(true)]);
    setEvents(de); setSubs(ds); setNames(Object.fromEntries(all.map(e => [e.id, e.name])));
  }, []);
  useEffect(() => { load(); }, [load]);

  const restoreEv = async (e: EventRecord) => { await restoreEvent(e); syncEventToRelay({ ...e, deletedAt: null }).catch(() => {}); toast.success('Event restore ho gaya'); load(); onChanged(); };
  const restoreSub = async (s: EventSubmission) => { await restoreSubmission(s); toast.success('Entry restore ho gayi'); load(); onChanged(); };
  const doPurge = async () => {
    if (!purge) return;
    if (purge.kind === 'event') await purgeEvent(purge.id); else await purgeSubmission(purge.id);
    setPurge(null); toast.success('Hamesha ke liye delete ho gaya'); load(); onChanged();
  };

  return (
    <div className="space-y-4">
      <h3>Recently Deleted</h3>
      {events.length === 0 && subs.length === 0 && <p className="text-sm text-gray-500">Kuch bhi delete nahi hua hai.</p>}
      {events.map(e => (
        <Card key={e.id} className="p-3 flex items-center justify-between">
          <div><div className="font-medium">{e.name}</div><div className="text-xs text-gray-500">Event • deleted {new Date(e.deletedAt!).toLocaleDateString('en-GB')}</div></div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => restoreEv(e)}><RotateCcw className="w-3 h-3 mr-1" /> Restore</Button>
            <Button size="sm" variant="ghost" onClick={() => setPurge({ kind: 'event', id: e.id, label: e.name })}><Trash2 className="w-4 h-4 text-red-600" /></Button>
          </div>
        </Card>))}
      {subs.map(s => (
        <Card key={s.id} className="p-3 flex items-center justify-between">
          <div><div className="font-medium">{s.registration_id}</div><div className="text-xs text-gray-500">Registration • {names[s.event_id] || 'Event'} • {Object.values(s.data).slice(0, 2).map(v => String(v)).join(', ')}</div></div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => restoreSub(s)}><RotateCcw className="w-3 h-3 mr-1" /> Restore</Button>
            <Button size="sm" variant="ghost" onClick={() => setPurge({ kind: 'sub', id: s.id, label: s.registration_id })}><Trash2 className="w-4 h-4 text-red-600" /></Button>
          </div>
        </Card>))}
      <ConfirmDialog open={!!purge} title="Permanently delete?" confirmText="Delete forever" onCancel={() => setPurge(null)} onConfirm={doPurge}>
        {purge && <p><b>{purge.label}</b> hamesha ke liye hat jayega{purge.kind === 'event' ? ' (is event ki saari registrations bhi)' : ''}. Ye wapas nahi aayega.</p>}
      </ConfirmDialog>
    </div>
  );
}
