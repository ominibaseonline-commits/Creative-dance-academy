import { useEffect, useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Card } from '../components/ui/card';
import { AlertTriangle, CalendarDays, CheckCircle2 } from 'lucide-react';
import { TemplatesTab } from './TemplatesTab';
import { CreateEventTab } from './CreateEventTab';
import { EventsHistoryTab } from './EventsHistoryTab';
import type { EventField, EventRecord } from './lib/eventsDb';
import { getRelayStatus, RelayStatus } from './lib/eventSync';

// Events section (admin only, visible only when Settings -> Event Forms is ON).
// 3 tabs: Templates | Create | Events History. All event data stays inside src/app/events/*.
export function EventsPage() {
  const [tab, setTab] = useState('history');
  const [seed, setSeed] = useState<EventField[] | undefined>();
  const [editing, setEditing] = useState<EventRecord | null>(null);
  const [relay, setRelay] = useState<RelayStatus | 'checking'>('checking');
  const [historyKey, setHistoryKey] = useState(0);

  // On open: check that the shared Google script is connected and has the Events part
  // (event forms themselves are pushed to the Sheet by useEventsSync in the background)
  useEffect(() => { getRelayStatus().then(setRelay); }, []);

  const go = (t: string) => { setTab(t); if (t === 'history') setHistoryKey(k => k + 1); };

  return (
    <div className="p-6 space-y-4">
      <h1 className="flex items-center gap-2"><CalendarDays className="w-6 h-6 text-orange-600" /> Events</h1>

      {relay === 'ok' && <p className="text-xs text-green-700 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Google script connected - public form links live hain.</p>}
      {(relay === 'not_connected' || relay === 'script_old' || relay === 'error') && (
        <Card className="p-3 border-orange-300 bg-orange-50 text-sm flex gap-2">
          <AlertTriangle className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
          <div>
            {relay === 'not_connected' && <>System Disconnected: Go to <b>Settings → Management & Setup → Attendance Setup</b> and connect to enable the public form.</>}
            {relay === 'script_old' && <>Aapki Google script purani hai. <b>Settings → Management & Setup → Attendance Setup</b> me naya code <b>Copy Code</b> karke script me paste karein, phir <b>Deploy → Manage deployments → Edit → New version</b>.</>}
            {relay === 'error' && <>Google script se baat nahi ho pa rahi (internet ya deploy settings check karein). Baaki Events features offline bhi chalte hain.</>}
          </div>
        </Card>)}

      <Tabs value={tab} onValueChange={go} className="w-full">
        <TabsList className="flex flex-wrap w-full h-auto gap-1 p-1">
          <TabsTrigger value="templates" className="flex-auto h-auto px-4 py-2">Templates</TabsTrigger>
          <TabsTrigger value="create" className="flex-auto h-auto px-4 py-2">{editing ? 'Edit Event' : 'Create'}</TabsTrigger>
          <TabsTrigger value="history" className="flex-auto h-auto px-4 py-2">Events History</TabsTrigger>
        </TabsList>
        <TabsContent value="templates">
          <TemplatesTab onUse={fields => { setEditing(null); setSeed(fields); setTab('create'); }} />
        </TabsContent>
        <TabsContent value="create">
          <CreateEventTab seedFields={seed} editing={editing} onSaved={() => { setEditing(null); setSeed(undefined); go('history'); }} />
        </TabsContent>
        <TabsContent value="history">
          <EventsHistoryTab key={historyKey} onEdit={ev => { setEditing(ev); setTab('create'); }} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
