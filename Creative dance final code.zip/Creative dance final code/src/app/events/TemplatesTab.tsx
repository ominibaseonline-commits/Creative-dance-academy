import { useEffect, useState } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog';
import { toast } from 'sonner';
import { Trash2, Pencil, Play } from 'lucide-react';
import { FormBuilder } from './FormBuilder';
import { BUILTIN_TEMPLATES, cloneFields } from './lib/eventTemplates';
import { EventField, EventTemplate, listTemplates, saveTemplate, deleteTemplate, newId } from './lib/eventsDb';

interface Props { onUse: (fields: EventField[]) => void }

// Events -> Templates: 5 ready-made templates + the admin's own saved templates.
export function TemplatesTab({ onUse }: Props) {
  const [custom, setCustom] = useState<EventTemplate[]>([]);
  const [editing, setEditing] = useState<{ name: string; fields: EventField[] } | null>(null);
  const load = () => listTemplates().then(l => setCustom(l.sort((a, b) => b.createdAt - a.createdAt)));
  useEffect(() => { load(); }, []);

  const saveAsNew = async () => {
    if (!editing) return;
    if (!editing.name.trim()) return toast.error('Template ka naam likhein');
    if (!editing.fields.some(f => !f.archived && f.label.trim())) return toast.error('Kam se kam ek field chahiye');
    await saveTemplate({ id: newId('tpl'), name: editing.name.trim(), fields: cloneFields(editing.fields.filter(f => f.label.trim())), createdAt: Date.now() });
    toast.success('Template save ho gaya'); setEditing(null); load();
  };

  const Item = ({ name, desc, fields, onDelete }: { name: string; desc: string; fields: () => EventField[]; onDelete?: () => void }) => (
    <Card className="p-4 flex flex-col gap-2">
      <div className="font-medium">{name}</div>
      <p className="text-sm text-gray-500 flex-1">{desc}</p>
      <div className="flex gap-2 flex-wrap">
        <Button size="sm" onClick={() => onUse(cloneFields(fields()))}><Play className="w-3 h-3 mr-1" /> Use</Button>
        <Button size="sm" variant="outline" onClick={() => setEditing({ name: `${name} (copy)`, fields: cloneFields(fields()) })}><Pencil className="w-3 h-3 mr-1" /> Customize</Button>
        {onDelete && <Button size="sm" variant="ghost" onClick={onDelete}><Trash2 className="w-4 h-4 text-red-600" /></Button>}
      </div>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div>
        <h3 className="mb-2">Ready-made templates</h3>
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {BUILTIN_TEMPLATES.map(t => <Item key={t.id} name={t.name} desc={t.description} fields={t.build} />)}
        </div>
      </div>
      <div>
        <h3 className="mb-2">My templates</h3>
        {custom.length === 0 ? <p className="text-sm text-gray-500">Abhi koi custom template nahi hai. Kisi bhi template par "Customize" dabake naya bana sakte hain.</p> : (
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {custom.map(t => <Item key={t.id} name={t.name} desc={`${t.fields.filter(f => !f.archived).length} fields`} fields={() => t.fields}
              onDelete={async () => { await deleteTemplate(t.id); load(); }} />)}
          </div>
        )}
      </div>

      <Dialog open={!!editing} onOpenChange={o => !o && setEditing(null)}>
        <DialogContent className="max-w-[1100px] sm:max-w-[1100px] w-[95vw] max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Customize template</DialogTitle></DialogHeader>
          {editing && (<>
            <Input value={editing.name} onChange={e => setEditing({ ...editing, name: e.target.value })} placeholder="Template name" />
            <FormBuilder fields={editing.fields} onChange={fields => setEditing({ ...editing, fields })} title={editing.name || 'Template'} />
          </>)}
          <DialogFooter><Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button><Button onClick={saveAsNew}>Save as new template</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
