import { useEffect, useState } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { toast } from 'sonner';
import { Copy, CheckCircle2, AlertTriangle, FileText, Bold, AlignLeft, AlignCenter, AlignRight } from 'lucide-react';
import { FormBuilder } from './FormBuilder';
import { EventField, EventRecord, listSubmissions, saveEvent, newId } from './lib/eventsDb';
import { getPublicLink, syncEventToRelay } from './lib/eventSync';
import { BG_COLORS, DEFAULT_THEME, THEME_COLORS, TITLE_FONTS, essentialFields, safeColor, titleFontCss, validBg } from './lib/eventTemplates';
import { blankFormPdf } from './lib/eventPdf';

interface Props {
  seedFields?: EventField[];       // from a template
  editing?: EventRecord | null;    // edit mode (opened from Events History)
  onSaved: () => void;
}

const today = () => new Date().toISOString().slice(0, 10);

// Events -> Create (also used for Edit). Name/date/venue/description/fee, form builder, public link.
export function CreateEventTab({ seedFields, editing, onSaved }: Props) {
  const [name, setName] = useState('');
  const [date, setDate] = useState(today());
  const [venue, setVenue] = useState('');
  const [description, setDescription] = useState('');
  const [fee, setFee] = useState('0');
  const [max, setMax] = useState('');
  const [fields, setFields] = useState<EventField[]>([]);
  const [themeColor, setThemeColor] = useState(DEFAULT_THEME);
  const [titleFont, setTitleFont] = useState('sans');
  const [titleBold, setTitleBold] = useState(true);
  const [titleAlign, setTitleAlign] = useState<'left' | 'center' | 'right'>('left');
  const [bgColor, setBgColor] = useState('');
  const [locked, setLocked] = useState<Set<string>>(new Set());
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState<{ ev: EventRecord; link: string; relayOk: boolean } | null>(null);

  // (re)load when switching between "new", "template" and "edit"
  useEffect(() => {
    setDone(null);
    if (editing) {
      setName(editing.name); setDate(editing.date); setVenue(editing.venue); setDescription(editing.description);
      setFee(String(editing.fee)); setMax(editing.maxRegistrations ? String(editing.maxRegistrations) : '');
      setFields(editing.formFields);
      setThemeColor(safeColor(editing.themeColor));
      setTitleFont(editing.titleFont || 'sans'); setTitleBold(editing.titleBold !== false); setTitleAlign(editing.titleAlign || 'left'); setBgColor(validBg(editing.bgColor));
      listSubmissions(editing.id, true).then(s => setLocked(s.length ? new Set(editing.formFields.map(f => f.key)) : new Set()));
    } else {
      setName(''); setDate(today()); setVenue(''); setDescription(''); setFee('0'); setMax('');
      // Naya event zaroori columns (naam, mobile, email, age, gender, address, city) ke saath shuru hota hai
      setFields(seedFields || essentialFields()); setLocked(new Set()); setThemeColor(DEFAULT_THEME);
      setTitleFont('sans'); setTitleBold(true); setTitleAlign('left'); setBgColor('');
    }
  }, [editing, seedFields]);

  const save = async () => {
    if (!name.trim()) return toast.error('Event ka naam likhein');
    if (!date) return toast.error('Date chunein');
    const feeNum = Number(fee || 0);
    if (!Number.isFinite(feeNum) || feeNum < 0) return toast.error('Fee sahi nahi hai');
    const cleaned = fields.filter(f => f.archived || f.label.trim());
    const live = cleaned.filter(f => !f.archived);
    if (live.length === 0) return toast.error('Kam se kam ek form field add karein');
    for (const f of live) if (['dropdown', 'radio', 'checkbox', 'multiselect'].includes(f.type) && !(f.options || []).length) return toast.error(`"${f.label}" ke options likhein`);

    setSaving(true);
    const ev: EventRecord = {
      id: editing?.id || newId('evt'), name: name.trim(), date, venue: venue.trim(), description: description.trim(),
      fee: feeNum, maxRegistrations: Number(max) > 0 ? Number(max) : undefined, formFields: cleaned,
      externalFormUrl: undefined, themeColor: safeColor(themeColor),
      titleFont, titleBold, titleAlign, bgColor: validBg(bgColor) || undefined,
      status: editing?.status || 'open', deletedAt: null, createdAt: editing?.createdAt || Date.now(), updatedAt: Date.now(),
    };
    await saveEvent(ev);
    let relayOk = true;
    try { await syncEventToRelay(ev); } catch { relayOk = false; }
    const link = await getPublicLink(ev.id);
    setSaving(false); setDone({ ev, link, relayOk });
    toast.success(editing ? 'Event update ho gaya' : 'Event ban gaya');
  };

  const copy = async (t: string) => { try { await navigator.clipboard.writeText(t); toast.success('Link copy ho gaya'); } catch { toast.error('Copy nahi hua'); } };

  if (done) return (
    <Card className="p-6 space-y-3">
      <h3 className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-green-600" /> {done.ev.name} - saved</h3>
      {!done.relayOk && <p className="text-sm text-red-600 flex gap-2"><AlertTriangle className="w-4 h-4 shrink-0" /> Google script se connect nahi ho paya. Settings → Management & Setup → Attendance Setup me script connect/update karke event ko Edit→Save karein, tab link chalega.</p>}
      {done.link ? (
        <div className="flex gap-2"><Input readOnly value={done.link} /><Button onClick={() => copy(done.link)}><Copy className="w-4 h-4 mr-2" /> Copy</Button></div>
      ) : <p className="text-sm text-gray-500">Public link banane ke liye Attendance Setup me Google script connect karein.</p>}
      <div className="flex flex-wrap gap-2">
        {<Button variant="outline" onClick={() => blankFormPdf(done.ev).catch((e: any) => toast.error(e?.message || 'PDF nahi bana'))}><FileText className="w-4 h-4 mr-2" /> Blank Form PDF</Button>}
        <Button variant="outline" onClick={onSaved}>Events History dekhein</Button>
      </div>
    </Card>
  );

  return (
    <div className="space-y-4">
      <Card className="p-4 space-y-3">
        <h3>{editing ? 'Edit Event' : 'New Event'}</h3>
        <div className="grid gap-3 md:grid-cols-2">
          <div><Label>Event Name *</Label><Input value={name} onChange={e => setName(e.target.value)} /></div>
          <div><Label>Date *</Label><Input type="date" value={date} onChange={e => setDate(e.target.value)} /></div>
          <div><Label>Venue</Label><Input value={venue} onChange={e => setVenue(e.target.value)} /></div>
          <div><Label>Fee (₹) - 0 = Free</Label><Input type="number" min="0" value={fee} onChange={e => setFee(e.target.value)} /></div>
          <div><Label>Max registrations (optional)</Label><Input type="number" min="0" value={max} onChange={e => setMax(e.target.value)} placeholder="Khali = no limit" /></div>
        </div>
        <div><Label>Description</Label><Textarea rows={3} value={description} onChange={e => setDescription(e.target.value)} /></div>
      </Card>

      <Card className="p-4 space-y-3">
        <h4>Form ka rang</h4>
        <div className="flex flex-wrap items-center gap-2">
          {THEME_COLORS.map(c => (
            <button key={c.hex} type="button" title={c.name} onClick={() => setThemeColor(c.hex)}
              className={`w-8 h-8 rounded-full border-2 ${themeColor.toLowerCase() === c.hex ? 'border-black ring-2 ring-offset-1 ring-gray-400' : 'border-white shadow'}`}
              style={{ background: c.hex }} />))}
          <label className="flex items-center gap-2 text-sm ml-2">Custom
            <input type="color" value={safeColor(themeColor)} onChange={e => setThemeColor(e.target.value)} className="w-9 h-8 p-0 border rounded cursor-pointer" /></label>
        </div>
        <div className="rounded-lg p-3 text-white text-sm" style={{ background: safeColor(themeColor) }}>
          Preview — {name.trim() || 'Event name'} (public form aur PDF me yahi rang aayega)
        </div>
      </Card>

      <Card className="p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h4>Registration Form</h4>
          {locked.size === 0 && (
            <div className="flex gap-2">
              <Button type="button" size="sm" variant="outline" onClick={() => setFields(essentialFields())}>Zaroori columns load karein</Button>
              <Button type="button" size="sm" variant="outline" onClick={() => setFields([])}>Blank form</Button>
            </div>)}
        </div>
        <div className="rounded-xl border bg-gray-50 p-3 space-y-3">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-sm font-medium">Event name style</span>
            <select className="h-9 rounded-md border border-input bg-white px-2 text-sm" value={titleFont} onChange={e => setTitleFont(e.target.value)}
              style={{ fontFamily: titleFontCss(titleFont) }}>
              {TITLE_FONTS.map(f => <option key={f.key} value={f.key} style={{ fontFamily: f.css }}>{f.label}</option>)}
            </select>
            <Button type="button" size="sm" variant={titleBold ? 'default' : 'outline'} title="Bold" onClick={() => setTitleBold(!titleBold)}><Bold className="w-4 h-4" /></Button>
            <div className="flex gap-1">
              {([['left', AlignLeft, 'Left'], ['center', AlignCenter, 'Center'], ['right', AlignRight, 'Right']] as const).map(([v, I, t]) => (
                <Button key={v} type="button" size="sm" variant={titleAlign === v ? 'default' : 'outline'} title={t} onClick={() => setTitleAlign(v)}><I className="w-4 h-4" /></Button>))}
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-medium mr-1">Form background</span>
            {BG_COLORS.map(c => (
              <button key={c.hex} type="button" title={c.name} onClick={() => setBgColor(c.hex)}
                className={`w-8 h-8 rounded-full border-2 ${bgColor.toLowerCase() === c.hex ? 'border-black ring-2 ring-offset-1 ring-gray-400' : 'border-gray-300'}`}
                style={{ background: c.hex }} />))}
            <label className="flex items-center gap-2 text-sm ml-2">Custom
              <input type="color" value={validBg(bgColor) || '#ffffff'} onChange={e => setBgColor(e.target.value)} className="w-9 h-8 p-0 border rounded cursor-pointer" /></label>
            {bgColor && <Button type="button" size="sm" variant="outline" onClick={() => setBgColor('')}>Reset</Button>}
          </div>
        </div>
        <FormBuilder fields={fields} onChange={setFields} lockedKeys={locked} color={themeColor}
          titleStyle={{ font: titleFont, bold: titleBold, align: titleAlign }} bgColor={bgColor}
          title={name.trim() || 'Event name'}
          subtitle={[date && date.split('-').reverse().join('-'), venue.trim(), Number(fee) > 0 ? `Fee: \u20B9${Number(fee)}` : ''].filter(Boolean).join('  \u2022  ') || undefined} />
      </Card>
      <Button disabled={saving} onClick={save}>{saving ? 'Saving...' : editing ? 'Update Event' : 'Save & Generate Link'}</Button>
    </div>
  );
}
